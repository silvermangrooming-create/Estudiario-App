/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'motion/react';
import { WavyFabricCanvas } from './components/WavyFabricCanvas';
import { SplashScreen } from './components/SplashScreen';
import { Header } from './components/Header';
import { BibleRadarCard } from './components/BibleRadarCard';
import { FieldServiceBento } from './components/FieldServiceBento';
import { CoverflowLibrary } from './components/CoverflowLibrary';
import { MetamorphicWidget } from './components/MetamorphicWidget';
import {
  BottomNavigation,
  type NavTabType,
} from './components/BottomNavigation';
import { LibraryStudioModal } from './components/LibraryStudioModal';
import { BibleMatrixModal } from './components/BibleMatrixModal';
import { MinisterioModal } from './components/MinisterioModal';
import { CalendarModal } from './components/CalendarModal';
import { ServiceReportModal } from './components/ServiceReportModal';
import { SettingsModal } from './components/SettingsModal';
import { MentorshipStudioModal } from './components/MentorshipStudioModal';
import { INITIAL_NOTES, type NoteItem } from './data/notesData';

export default function App() {
  // Booting / Splash Screen state (2.4s initial)
  const [isBooting, setIsBooting] = useState(true);

  // User Profile & Settings
  const [userName, setUserName] = useState('Gabriel');
  const [monthlyGoal, setMonthlyGoal] = useState(50);
  const [geminiApiKey, setGeminiApiKey] = useState('');
  const [theme, setTheme] = useState<'light' | 'sunlight' | 'dark'>('light');

  // Field Service State
  const [hoursLogged, setHoursLogged] = useState(30);
  const [revisitasList, setRevisitasList] = useState(['Luis', 'Alberto']);
  const [cursosList, setCursosList] = useState([
    'Josué',
    'Carlos',
    'Andrés',
    'Mateo',
  ]);

  // Bible Reading State
  const [biblePercentage, setBiblePercentage] = useState(63);
  const [completedBooksCount, setCompletedBooksCount] = useState(41);
  const [currentBookName, setCurrentBookName] = useState('Amós');
  const [currentBookPercentage, setCurrentBookPercentage] = useState(32);
  const [currentChapter, setCurrentChapter] = useState(4);
  const [currentVerse, setCurrentVerse] = useState(1);
  const [isReadingMarkedToday, setIsReadingMarkedToday] = useState(false);

  // Library Notes State
  const [notes, setNotes] = useState<NoteItem[]>(INITIAL_NOTES);
  const [selectedNoteForModal, setSelectedNoteForModal] =
    useState<NoteItem | null>(null);

  // Widget Deployment
  const [isWidgetDeployed, setIsWidgetDeployed] = useState(false);

  // Navigation & Modals
  const [activeNavTab, setActiveNavTab] = useState<NavTabType>('home');
  const [isLibraryModalOpen, setIsLibraryModalOpen] = useState(false);
  const [isBibleMatrixOpen, setIsBibleMatrixOpen] = useState(false);
  const [isMinisterioModalOpen, setIsMinisterioModalOpen] = useState(false);
  const [ministerioInitialTab, setMinisterioInitialTab] = useState<
    'hours' | 'revisitas' | 'cursos'
  >('hours');
  const [isMentorshipModalOpen, setIsMentorshipModalOpen] = useState(false);
  const [mentorshipInitialTab, setMentorshipInitialTab] = useState<
    'revisitas' | 'cursos'
  >('revisitas');
  const [isCalendarModalOpen, setIsCalendarModalOpen] = useState(false);
  const [isServiceReportOpen, setIsServiceReportOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [libraryStartInSearch, setLibraryStartInSearch] = useState(false);

  // Global State for Student Pins connected from the Widget & Mentor Studio
  const [studentPins, setStudentPins] = useState<
    Record<string, { scripture: string; note: string }[]>
  >({
    Josué: [
      {
        scripture: 'Santiago 1:13',
        note: 'Usar para la introducción hoy: Dios nunca nos pone a prueba con cosas malas.',
      },
    ],
    Carlos: [
      {
        scripture: 'Juan 17:3',
        note: 'Repasar la vida eterna conociendo al Dios verdadero.',
      },
    ],
    Andrés: [
      {
        scripture: 'Mateo 28:19',
        note: 'Destacar hacer discípulos y el simbolismo del agua.',
      },
    ],
    Mateo: [
      {
        scripture: '2 Timoteo 3:16',
        note: 'Toda la Escritura es inspirada por Dios y útil para enseñar.',
      },
    ],
  });

  const handleAddStudentPin = (
    studentName: string,
    scripture: string,
    note: string
  ) => {
    setStudentPins((prev) => ({
      ...prev,
      [studentName]: [{ scripture, note }, ...(prev[studentName] || [])],
    }));
  };

  // Boot timer: 2.4 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsBooting(false);
    }, 2400);
    return () => clearTimeout(timer);
  }, []);

  // Sync Tailwind .dark class on <html> document element
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  // Theme Cycler: light -> sunlight -> dark -> light
  const handleCycleTheme = () => {
    setTheme((prev) => {
      if (prev === 'light') return 'sunlight';
      if (prev === 'sunlight') return 'dark';
      return 'light';
    });
  };

  // Replay Boot Animation
  const handleReplayBoot = () => {
    setIsBooting(true);
    setTimeout(() => {
      setIsBooting(false);
    }, 2400);
  };

  // Handlers for updating Bible bookmark
  const handleUpdateBookmark = (
    book: string,
    chapter: number,
    verse: number
  ) => {
    setCurrentBookName(book);
    setCurrentChapter(chapter);
    setCurrentVerse(verse);
    setIsReadingMarkedToday(true);

    // Calculate approximate book percentage
    const bookProgress = Math.min(100, Math.round((chapter / 9) * 100)) || 32;
    setCurrentBookPercentage(bookProgress);

    // Dynamic celebration / update to 64% if reading continues
    setBiblePercentage((prev) => Math.min(100, Math.max(prev, 63)));
  };

  // Handlers for Field Service
  const handleAddHours = (hours: number) => {
    setHoursLogged((prev) => parseFloat((prev + hours).toFixed(1)));
  };

  // Bottom Nav switcher
  const handleNavChange = (tab: NavTabType) => {
    setActiveNavTab(tab);
    if (tab === 'search') {
      setLibraryStartInSearch(true);
      setSelectedNoteForModal(null);
      setIsLibraryModalOpen(true);
    } else if (tab === 'home') {
      // Return to main dashboard
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (tab === 'ministerio') {
      setMinisterioInitialTab('hours');
      setIsMinisterioModalOpen(true);
    } else if (tab === 'biblia') {
      setIsBibleMatrixOpen(true);
    } else if (tab === 'settings') {
      setIsSettingsModalOpen(true);
    }
  };

  // Open Bento Card into appropriate Studio
  const handleOpenBentoCard = (cardType: 'hours' | 'revisitas' | 'cursos') => {
    if (cardType === 'hours') {
      setMinisterioInitialTab('hours');
      setIsMinisterioModalOpen(true);
    } else {
      setMentorshipInitialTab(cardType);
      setIsMentorshipModalOpen(true);
    }
  };

  // Save new or edited note
  const handleSaveNote = (savedNote: NoteItem) => {
    setNotes((prev) => {
      const idx = prev.findIndex((n) => n.id === savedNote.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = savedNote;
        return copy;
      }
      return [savedNote, ...prev];
    });
  };

  // Delete note
  const handleDeleteNote = (noteId: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== noteId));
  };

  // Quick note from widget
  const handleSaveQuickNote = (partial: Partial<NoteItem>) => {
    const newNote: NoteItem = {
      id: `note-${Date.now()}`,
      title: partial.title || 'Nota Rápida',
      category: partial.category || 'Estudio Personal',
      categoryColor: partial.categoryColor || '#1D5B57',
      accentHex: partial.categoryColor || '#1D5B57',
      date: new Date().toLocaleDateString('es-ES', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      }),
      content: partial.content || '',
      scriptures: partial.scriptures || [],
      keywords: ['nota rapida', 'estudio'],
    };
    handleSaveNote(newNote);
  };

  return (
    <div
      className={`w-full min-h-[100dvh] overflow-x-hidden overflow-y-auto relative selection:bg-[#EBB634]/30 ${
        theme === 'dark' ? 'text-[#FAF7F0]' : 'text-[#112625]'
      }`}
    >
      {/* Dynamic Booting Splash Screen */}
      <AnimatePresence>
        {isBooting && (
          <SplashScreen
            userName={userName}
            onFinish={() => setIsBooting(false)}
          />
        )}
      </AnimatePresence>

      {/* Living Refraction Canvas with Undulating Wavy Fabric Animations */}
      <WavyFabricCanvas theme={theme} />

      {/* Main Dashboard Container: Generous breathing room & Smooth Vertical Scrolling */}
      <main className="w-full max-w-md mx-auto px-5 pt-4 pb-44 flex flex-col gap-8 relative z-10">
        {/* Exact 3-Tier Header Layout */}
        <Header
          userName={userName}
          theme={theme}
          onCycleTheme={handleCycleTheme}
          onOpenAiAssistant={() => setIsWidgetDeployed(true)}
          onOpenServiceReport={() => setIsServiceReportOpen(true)}
          onOpenCalendar={() => setIsCalendarModalOpen(true)}
          onToggleWidget={() => setIsWidgetDeployed(!isWidgetDeployed)}
        />

        {/* 5. Bible Reading Radar Card (Hero Glass Container) */}
        <BibleRadarCard
          percentage={biblePercentage}
          completedBooksCount={completedBooksCount}
          currentBookName={currentBookName}
          currentBookPercentage={currentBookPercentage}
          currentChapter={currentChapter}
          currentVerse={currentVerse}
          isReadingMarkedToday={isReadingMarkedToday}
          onOpenBibleMatrix={() => setIsBibleMatrixOpen(true)}
        />

        {/* 6. "Servicio del campo" 3-Column Bento Cards (No internal buttons) */}
        <FieldServiceBento
          hoursLogged={hoursLogged}
          monthlyGoal={monthlyGoal}
          revisitas={revisitasList}
          cursos={cursosList}
          onOpenCard={handleOpenBentoCard}
        />

        {/* 7. "BIBLIOTECA" 12-Note Swipeable 3D Coverflow */}
        <CoverflowLibrary
          notes={notes}
          onOpenLibrary={() => {
            setLibraryStartInSearch(false);
            setSelectedNoteForModal(null);
            setIsLibraryModalOpen(true);
          }}
          onSelectNote={(note) => {
            setSelectedNoteForModal(note);
            setLibraryStartInSearch(false);
            setIsLibraryModalOpen(true);
          }}
        />
      </main>

      {/* 8. The Metamorphic Floating Logo Widget (3 Stages) */}
      <MetamorphicWidget
        isDeployed={isWidgetDeployed}
        onToggleDeploy={() => setIsWidgetDeployed(!isWidgetDeployed)}
        onUpdateBookmark={handleUpdateBookmark}
        onAddHours={handleAddHours}
        onSaveQuickNote={handleSaveQuickNote}
        onAddStudentPin={handleAddStudentPin}
        studentsList={cursosList}
        notesList={notes}
        geminiApiKey={geminiApiKey}
      />

      {/* 9. Official 5-Icon Bottom Floating Glass Navigation Dock */}
      <BottomNavigation
        activeTab={activeNavTab}
        onChangeTab={handleNavChange}
      />

      {/* MODAL OVERLAYS */}
      {/* 1. Full-Screen Glass Library & Note/Talk Studio Overlay */}
      <LibraryStudioModal
        isOpen={isLibraryModalOpen}
        onClose={() => {
          setIsLibraryModalOpen(false);
          setActiveNavTab('home');
        }}
        notes={notes}
        onSaveNote={handleSaveNote}
        onDeleteNote={handleDeleteNote}
        selectedNoteInitial={selectedNoteForModal}
        startInSearchMode={libraryStartInSearch}
      />

      {/* 2. 66-Book Canonical Bible Matrix Modal */}
      <BibleMatrixModal
        isOpen={isBibleMatrixOpen}
        onClose={() => {
          setIsBibleMatrixOpen(false);
          setActiveNavTab('home');
        }}
        currentBook={currentBookName}
        currentChapter={currentChapter}
        currentVerse={currentVerse}
        onUpdateBookmark={handleUpdateBookmark}
      />

      {/* 3. Ministerio & Preaching Studio Modal */}
      <MinisterioModal
        isOpen={isMinisterioModalOpen}
        onClose={() => {
          setIsMinisterioModalOpen(false);
          setActiveNavTab('home');
        }}
        hoursLogged={hoursLogged}
        monthlyGoal={monthlyGoal}
        onAddHours={handleAddHours}
        revisitasList={revisitasList}
        cursosList={cursosList}
        initialSubTab={ministerioInitialTab}
      />

      {/* 3B. Mentorship Studio Modal (Revisitas Pipeline & Student Profiles) */}
      <MentorshipStudioModal
        isOpen={isMentorshipModalOpen}
        onClose={() => setIsMentorshipModalOpen(false)}
        initialTab={mentorshipInitialTab}
        onAddHours={handleAddHours}
        studentPins={studentPins}
        onUpdateStats={(revCount, curCount) => {
          if (curCount > cursosList.length) {
            setCursosList((prev) => [...prev, 'Nuevo']);
          }
        }}
      />

      {/* 4. Smart Calendar & Responsibilities Modal */}
      <CalendarModal
        isOpen={isCalendarModalOpen}
        onClose={() => setIsCalendarModalOpen(false)}
        hoursLogged={hoursLogged}
        monthlyGoal={monthlyGoal}
      />

      {/* 5. Monthly Service Report Modal */}
      <ServiceReportModal
        isOpen={isServiceReportOpen}
        onClose={() => setIsServiceReportOpen(false)}
        userName={userName}
        hoursLogged={hoursLogged}
        cursosCount={cursosList.length}
        revisitasCount={revisitasList.length}
      />

      {/* 6. Settings & Preferences Modal */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => {
          setIsSettingsModalOpen(false);
          setActiveNavTab('home');
        }}
        userName={userName}
        onUpdateUserName={setUserName}
        monthlyGoal={monthlyGoal}
        onUpdateMonthlyGoal={setMonthlyGoal}
        geminiApiKey={geminiApiKey}
        onUpdateGeminiApiKey={setGeminiApiKey}
        theme={theme}
        onCycleTheme={handleCycleTheme}
        onReplayBoot={handleReplayBoot}
      />
    </div>
  );
}
