export interface NoteItem {
  id: string;
  title: string;
  category:
    | 'Estudio Personal'
    | 'Lectura de la Biblia'
    | 'Discurso Público'
    | 'Asamblea Regional'
    | 'Asamblea de Circuito'
    | 'Simposio'
    | 'Sección de Reunión Semanal'
    | 'Cursos y Ministerio'
    | 'Otro';
  categoryColor: string;
  accentHex: string;
  speaker?: string;
  congregation?: string;
  location?: string;
  songNumber?: string;
  eventNameDetail?: string;
  date: string;
  content: string;
  scriptures: string[];
  keywords: string[];
}

export const CATEGORY_PALETTE: Record<
  NoteItem['category'],
  {
    color: string;
    label: string;
    textClass: string;
    bgSoft: string;
    borderHex: string;
  }
> = {
  'Estudio Personal': {
    color: '#1D5B57',
    label: 'Estudio Personal',
    textClass: 'text-[#1D5B57]',
    bgSoft: 'rgba(29, 91, 87, 0.12)',
    borderHex: '#1D5B57',
  },
  'Lectura de la Biblia': {
    color: '#6BA38B',
    label: 'Lectura de la Biblia',
    textClass: 'text-[#3E7D65]',
    bgSoft: 'rgba(107, 163, 139, 0.15)',
    borderHex: '#6BA38B',
  },
  'Discurso Público': {
    color: '#EAB63E',
    label: 'Discurso Público',
    textClass: 'text-[#A07310]',
    bgSoft: 'rgba(234, 182, 62, 0.18)',
    borderHex: '#EAB63E',
  },
  'Asamblea Regional': {
    color: '#2B6CB0',
    label: 'Asamblea Regional',
    textClass: 'text-[#1E5289]',
    bgSoft: 'rgba(43, 108, 176, 0.14)',
    borderHex: '#2B6CB0',
  },
  'Asamblea de Circuito': {
    color: '#D96B43',
    label: 'Asamblea de Circuito',
    textClass: 'text-[#AA4925]',
    bgSoft: 'rgba(217, 107, 67, 0.14)',
    borderHex: '#D96B43',
  },
  Simposio: {
    color: '#6B5B95',
    label: 'Simposio',
    textClass: 'text-[#534479]',
    bgSoft: 'rgba(107, 91, 149, 0.14)',
    borderHex: '#6B5B95',
  },
  'Sección de Reunión Semanal': {
    color: '#2C8C82',
    label: 'Sección de Reunión Semanal',
    textClass: 'text-[#1A6860]',
    bgSoft: 'rgba(44, 140, 130, 0.14)',
    borderHex: '#2C8C82',
  },
  'Cursos y Ministerio': {
    color: '#C47A6A',
    label: 'Cursos y Ministerio',
    textClass: 'text-[#964E40]',
    bgSoft: 'rgba(196, 122, 106, 0.14)',
    borderHex: '#C47A6A',
  },
  Otro: {
    color: '#B89F65',
    label: 'Otro',
    textClass: 'text-[#877038]',
    bgSoft: 'rgba(184, 159, 101, 0.14)',
    borderHex: '#B89F65',
  },
};

export const SEMANTIC_HIGHLIGHTERS = [
  {
    id: 'oro',
    name: 'Oro Solar: Cualidades de Jehová',
    hex: '#F3C64F',
    textColor: '#634700',
  },
  {
    id: 'salvia',
    name: 'Salvia Viva: Aplicación Personal',
    hex: '#84C198',
    textColor: '#144626',
  },
  {
    id: 'cerceta',
    name: 'Cerceta Imperial: Punto Principal',
    hex: '#2D8C85',
    textColor: '#0B3632',
  },
  {
    id: 'coral',
    name: 'Coral Ministerio: Ministerio y Enseñanza',
    hex: '#E6826D',
    textColor: '#541D12',
  },
  {
    id: 'ambar',
    name: 'Ámbar Luz: Ilustraciones',
    hex: '#E5A93C',
    textColor: '#573800',
  },
  {
    id: 'zafiro',
    name: 'Zafiro Cielo: Contexto e Idioma',
    hex: '#4C84C4',
    textColor: '#0E2E54',
  },
  {
    id: 'amatista',
    name: 'Amatista Real: Profecía y Reino',
    hex: '#8E7DBE',
    textColor: '#2D1F4F',
  },
  {
    id: 'turquesa',
    name: 'Turquesa Menta: Ejemplos de Fe',
    hex: '#4BB5A5',
    textColor: '#0F443D',
  },
  {
    id: 'rubi',
    name: 'Rubí Alerta: Advertencias',
    hex: '#E25C5C',
    textColor: '#591313',
  },
  {
    id: 'indigo',
    name: 'Índigo Lavanda: Investigar Más',
    hex: '#6A6DB0',
    textColor: '#1B1E54',
  },
];

// FASE 6: Lienzo limpio de notas.
export const INITIAL_NOTES: NoteItem[] = [];
