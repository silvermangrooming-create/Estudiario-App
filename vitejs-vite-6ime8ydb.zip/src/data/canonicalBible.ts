export interface BibleBookInfo {
  id: number;
  code: string; // 2 digits: "01", "02", ... "66"
  name: string;
  shortName: string;
  category: 'Históricos' | 'Proféticos' | 'Poéticos' | 'Evangelios' | 'Cartas';
  chapters: number;
  testament: 'AT' | 'NT';
}

export const CANONICAL_BOOKS: BibleBookInfo[] = [
  // Antiguo Testamento - Históricos (Pentateuco y Libros Históricos)
  { id: 1, code: '01', name: 'Génesis', shortName: 'Gén', category: 'Históricos', chapters: 50, testament: 'AT' },
  { id: 2, code: '02', name: 'Éxodo', shortName: 'Éx', category: 'Históricos', chapters: 40, testament: 'AT' },
  { id: 3, code: '03', name: 'Levítico', shortName: 'Lev', category: 'Históricos', chapters: 27, testament: 'AT' },
  { id: 4, code: '04', name: 'Números', shortName: 'Núm', category: 'Históricos', chapters: 36, testament: 'AT' },
  { id: 5, code: '05', name: 'Deuteronomio', shortName: 'Deut', category: 'Históricos', chapters: 34, testament: 'AT' },
  { id: 6, code: '06', name: 'Josué', shortName: 'Jos', category: 'Históricos', chapters: 24, testament: 'AT' },
  { id: 7, code: '07', name: 'Jueces', shortName: 'Jue', category: 'Históricos', chapters: 21, testament: 'AT' },
  { id: 8, code: '08', name: 'Rut', shortName: 'Rut', category: 'Históricos', chapters: 4, testament: 'AT' },
  { id: 9, code: '09', name: '1 Samuel', shortName: '1 Sam', category: 'Históricos', chapters: 31, testament: 'AT' },
  { id: 10, code: '10', name: '2 Samuel', shortName: '2 Sam', category: 'Históricos', chapters: 24, testament: 'AT' },
  { id: 11, code: '11', name: '1 Reyes', shortName: '1 Rey', category: 'Históricos', chapters: 22, testament: 'AT' },
  { id: 12, code: '12', name: '2 Reyes', shortName: '2 Rey', category: 'Históricos', chapters: 25, testament: 'AT' },
  { id: 13, code: '13', name: '1 Crónicas', shortName: '1 Crón', category: 'Históricos', chapters: 29, testament: 'AT' },
  { id: 14, code: '14', name: '2 Crónicas', shortName: '2 Crón', category: 'Históricos', chapters: 36, testament: 'AT' },
  { id: 15, code: '15', name: 'Esdras', shortName: 'Esd', category: 'Históricos', chapters: 10, testament: 'AT' },
  { id: 16, code: '16', name: 'Nehemías', shortName: 'Neh', category: 'Históricos', chapters: 13, testament: 'AT' },
  { id: 17, code: '17', name: 'Ester', shortName: 'Est', category: 'Históricos', chapters: 10, testament: 'AT' },

  // Poéticos
  { id: 18, code: '18', name: 'Job', shortName: 'Job', category: 'Poéticos', chapters: 42, testament: 'AT' },
  { id: 19, code: '19', name: 'Salmos', shortName: 'Sal', category: 'Poéticos', chapters: 150, testament: 'AT' },
  { id: 20, code: '20', name: 'Proverbios', shortName: 'Prov', category: 'Poéticos', chapters: 31, testament: 'AT' },
  { id: 21, code: '21', name: 'Eclesiastés', shortName: 'Ecl', category: 'Poéticos', chapters: 12, testament: 'AT' },
  { id: 22, code: '22', name: 'El Cantar de los Cantares', shortName: 'Cant', category: 'Poéticos', chapters: 8, testament: 'AT' },

  // Proféticos
  { id: 23, code: '23', name: 'Isaías', shortName: 'Isa', category: 'Proféticos', chapters: 66, testament: 'AT' },
  { id: 24, code: '24', name: 'Jeremías', shortName: 'Jer', category: 'Proféticos', chapters: 52, testament: 'AT' },
  { id: 25, code: '25', name: 'Lamentaciones', shortName: 'Lam', category: 'Proféticos', chapters: 5, testament: 'AT' },
  { id: 26, code: '26', name: 'Ezequiel', shortName: 'Ezeq', category: 'Proféticos', chapters: 48, testament: 'AT' },
  { id: 27, code: '27', name: 'Daniel', shortName: 'Dan', category: 'Proféticos', chapters: 12, testament: 'AT' },
  { id: 28, code: '28', name: 'Oseas', shortName: 'Ose', category: 'Proféticos', chapters: 14, testament: 'AT' },
  { id: 29, code: '29', name: 'Joel', shortName: 'Joel', category: 'Proféticos', chapters: 3, testament: 'AT' },
  { id: 30, code: '30', name: 'Amós', shortName: 'Amós', category: 'Proféticos', chapters: 9, testament: 'AT' },
  { id: 31, code: '31', name: 'Abdías', shortName: 'Abd', category: 'Proféticos', chapters: 1, testament: 'AT' },
  { id: 32, code: '32', name: 'Jonás', shortName: 'Jon', category: 'Proféticos', chapters: 4, testament: 'AT' },
  { id: 33, code: '33', name: 'Miqueas', shortName: 'Miq', category: 'Proféticos', chapters: 7, testament: 'AT' },
  { id: 34, code: '34', name: 'Nahúm', shortName: 'Nah', category: 'Proféticos', chapters: 3, testament: 'AT' },
  { id: 35, code: '35', name: 'Habacuc', shortName: 'Hab', category: 'Proféticos', chapters: 3, testament: 'AT' },
  { id: 36, code: '36', name: 'Sofonías', shortName: 'Sof', category: 'Proféticos', chapters: 3, testament: 'AT' },
  { id: 37, code: '37', name: 'Ageo', shortName: 'Ageo', category: 'Proféticos', chapters: 2, testament: 'AT' },
  { id: 38, code: '38', name: 'Zacarías', shortName: 'Zac', category: 'Proféticos', chapters: 14, testament: 'AT' },
  { id: 39, code: '39', name: 'Malaquías', shortName: 'Mal', category: 'Proféticos', chapters: 4, testament: 'AT' },

  // Nuevo Testamento - Evangelios y Hechos
  { id: 40, code: '40', name: 'Mateo', shortName: 'Mat', category: 'Evangelios', chapters: 28, testament: 'NT' },
  { id: 41, code: '41', name: 'Marcos', shortName: 'Mar', category: 'Evangelios', chapters: 16, testament: 'NT' },
  { id: 42, code: '42', name: 'Lucas', shortName: 'Luc', category: 'Evangelios', chapters: 24, testament: 'NT' },
  { id: 43, code: '43', name: 'Juan', shortName: 'Juan', category: 'Evangelios', chapters: 21, testament: 'NT' },
  { id: 44, code: '44', name: 'Hechos', shortName: 'Hech', category: 'Evangelios', chapters: 28, testament: 'NT' },

  // Cartas y Revelación
  { id: 45, code: '45', name: 'Romanos', shortName: 'Rom', category: 'Cartas', chapters: 16, testament: 'NT' },
  { id: 46, code: '46', name: '1 Corintios', shortName: '1 Cor', category: 'Cartas', chapters: 16, testament: 'NT' },
  { id: 47, code: '47', name: '2 Corintios', shortName: '2 Cor', category: 'Cartas', chapters: 13, testament: 'NT' },
  { id: 48, code: '48', name: 'Gálatas', shortName: 'Gál', category: 'Cartas', chapters: 6, testament: 'NT' },
  { id: 49, code: '49', name: 'Efesios', shortName: 'Efes', category: 'Cartas', chapters: 6, testament: 'NT' },
  { id: 50, code: '50', name: 'Filipenses', shortName: 'Fil', category: 'Cartas', chapters: 4, testament: 'NT' },
  { id: 51, code: '51', name: 'Colosenses', shortName: 'Col', category: 'Cartas', chapters: 4, testament: 'NT' },
  { id: 52, code: '52', name: '1 Tesalonicenses', shortName: '1 Tes', category: 'Cartas', chapters: 5, testament: 'NT' },
  { id: 53, code: '53', name: '2 Tesalonicenses', shortName: '2 Tes', category: 'Cartas', chapters: 3, testament: 'NT' },
  { id: 54, code: '54', name: '1 Timoteo', shortName: '1 Tim', category: 'Cartas', chapters: 6, testament: 'NT' },
  { id: 55, code: '55', name: '2 Timoteo', shortName: '2 Tim', category: 'Cartas', chapters: 4, testament: 'NT' },
  { id: 56, code: '56', name: 'Tito', shortName: 'Tito', category: 'Cartas', chapters: 3, testament: 'NT' },
  { id: 57, code: '57', name: 'Filemón', shortName: 'Filem', category: 'Cartas', chapters: 1, testament: 'NT' },
  { id: 58, code: '58', name: 'Hebreos', shortName: 'Heb', category: 'Cartas', chapters: 13, testament: 'NT' },
  { id: 59, code: '59', name: 'Santiago', shortName: 'Sant', category: 'Cartas', chapters: 5, testament: 'NT' },
  { id: 60, code: '60', name: '1 Pedro', shortName: '1 Ped', category: 'Cartas', chapters: 5, testament: 'NT' },
  { id: 61, code: '61', name: '2 Pedro', shortName: '2 Ped', category: 'Cartas', chapters: 3, testament: 'NT' },
  { id: 62, code: '62', name: '1 Juan', shortName: '1 Juan', category: 'Cartas', chapters: 5, testament: 'NT' },
  { id: 63, code: '63', name: '2 Juan', shortName: '2 Juan', category: 'Cartas', chapters: 1, testament: 'NT' },
  { id: 64, code: '64', name: '3 Juan', shortName: '3 Juan', category: 'Cartas', chapters: 1, testament: 'NT' },
  { id: 65, code: '65', name: 'Judas', shortName: 'Jud', category: 'Cartas', chapters: 1, testament: 'NT' },
  { id: 66, code: '66', name: 'Apocalipsis', shortName: 'Apoc', category: 'Cartas', chapters: 22, testament: 'NT' },
];

/**
 * Generate official JW Library deep link:
 * https://www.jw.org/finder?srcid=jwlshare&wtlocale=S&prefer=lang&bible=BBCCCVVV&pub=nwtsty
 */
export function buildJwLibraryUrl(bookNumber: number, chapter: number = 1, verse: number = 0): string {
  const bb = String(bookNumber).padStart(2, '0');
  const ccc = String(chapter).padStart(3, '0');
  const vvv = String(verse).padStart(3, '0');
  const code = `${bb}${ccc}${vvv}`;
  return `https://www.jw.org/finder?srcid=jwlshare&wtlocale=S&prefer=lang&bible=${code}&pub=nwtsty`;
}

/**
 * Normalizes text by removing accents, tildes, and punctuation
 */
export function normalizeConcept(text: string): string {
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"']/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Finds scripture references inside a text and returns parsed info + JW Library link
 */
export interface ScriptureMatch {
  raw: string;
  bookName: string;
  bookNumber: number;
  chapter: number;
  verse: number;
  url: string;
}

export function parseScriptureReferences(text: string): ScriptureMatch[] {
  const matches: ScriptureMatch[] = [];
  
  // RegEx for Spanish scriptures: e.g. "Mateo 6:33", "Salmo 83:18", "Apocalipsis 21:3, 4", "Amós 3:2", "1 Corintios 13:4"
  const regex = /(?:[123]\s+)?[A-ZÁÉÍÓÚÑa-záéíóúñ]+\s+\d+(?::\d+(?:[,\-]\s*\d+)?)?/g;
  const potentialMatches = text.match(regex);
  if (!potentialMatches) return matches;

  for (const match of potentialMatches) {
    const parts = match.trim().split(/\s+/);
    let bookQuery = '';
    let chapVersePart = '';

    if (parts.length >= 3 && /^[123]$/.test(parts[0])) {
      bookQuery = `${parts[0]} ${parts[1]}`;
      chapVersePart = parts.slice(2).join(' ');
    } else if (parts.length >= 2) {
      bookQuery = parts[0];
      chapVersePart = parts.slice(1).join(' ');
    } else {
      continue;
    }

    const normQuery = normalizeConcept(bookQuery);
    const book = CANONICAL_BOOKS.find((b) => {
      const bNorm = normalizeConcept(b.name);
      const sNorm = normalizeConcept(b.shortName);
      return bNorm.startsWith(normQuery) || normQuery.startsWith(bNorm) || sNorm === normQuery;
    });

    if (book) {
      let chapter = 1;
      let verse = 0;
      if (chapVersePart) {
        const cvSplit = chapVersePart.split(':');
        chapter = parseInt(cvSplit[0], 10) || 1;
        if (cvSplit.length > 1) {
          verse = parseInt(cvSplit[1].replace(/[^\d].*/, ''), 10) || 0;
        }
      }
      matches.push({
        raw: match.trim(),
        bookName: book.name,
        bookNumber: book.id,
        chapter,
        verse,
        url: buildJwLibraryUrl(book.id, chapter, verse),
      });
    }
  }

  // De-duplicate matches
  const unique: ScriptureMatch[] = [];
  const seen = new Set<string>();
  for (const m of matches) {
    if (!seen.has(m.raw)) {
      seen.add(m.raw);
      unique.push(m);
    }
  }
  return unique;
}
