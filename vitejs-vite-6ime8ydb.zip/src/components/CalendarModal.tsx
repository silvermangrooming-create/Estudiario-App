import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Briefcase,
  Mic,
  BookOpen,
  Headphones,
  Sparkles,
  Users,
  ShieldCheck,
  Plus,
  Check,
  AlertCircle,
  Calendar as CalendarIcon,
  Bell,
  CloudRain,
} from 'lucide-react';

interface CalendarModalProps {
  isOpen: boolean;
  onClose: () => void;
  hoursLogged: number;
  monthlyGoal: number;
}

interface AssignmentItem {
  id: string;
  date: string;
  role: string;
  category: 'lectura' | 'discurso' | 'audiovideo' | 'limpieza' | 'acomodador';
  detail: string;
  reminderActive: boolean;
}

export const CalendarModal: React.FC<CalendarModalProps> = ({
  isOpen,
  onClose,
  hoursLogged,
  monthlyGoal,
}) => {
  // Main Segmented Tab: 'predicacion' | 'asignaciones'
  const [activeTab, setActiveTab] = useState<'predicacion' | 'asignaciones'>('predicacion');

  // TAB A: Weekly Preaching Setup (L, M, X, J, V, S, D)
  // 0: Mon, 1: Tue, 2: Wed, 3: Thu, 4: Fri, 5: Sat, 6: Sun
  const [selectedWeekdays, setSelectedWeekdays] = useState<number[]>([1, 3, 5, 6]); // Mar, Jue, Sáb, Dom by default

  // TAB A: The Weather/Conflict Shield (Imprevisto / Reprogramación)
  const [isTodayConflict, setIsTodayConflict] = useState(false);
  const [conflictNotice, setConflictNotice] = useState(false);

  // TAB B: Congregation Duties / Assignments
  const [assignments, setAssignments] = useState<AssignmentItem[]>([
    {
      id: 'asg-1',
      date: 'Domingo 18 de Octubre, 10:00 AM',
      role: 'Lectura de la Biblia',
      category: 'lectura',
      detail: 'Lectura semanal: Amós capítulos 1 y 2. Salón del Reino.',
      reminderActive: true,
    },
    {
      id: 'asg-2',
      date: 'Miércoles 21 de Octubre, 7:00 PM',
      role: 'Audio y Video',
      category: 'audiovideo',
      detail: 'Control de multimedia y transmisión zoom en reunión de entre semana.',
      reminderActive: true,
    },
    {
      id: 'asg-3',
      date: 'Sábado 24 de Octubre, 9:00 AM',
      role: 'Acomodador y Micrófonos',
      category: 'acomodador',
      detail: 'Pasillo central y conteo de asistencia presencial.',
      reminderActive: false,
    },
    {
      id: 'asg-4',
      date: 'Domingo 25 de Octubre, 11:30 AM',
      role: 'Discurso Público',
      category: 'discurso',
      detail: 'Discurso de 30 min: "¿Por qué confiar en las promesas divinas?".',
      reminderActive: true,
    },
    {
      id: 'asg-5',
      date: 'Sábado 31 de Octubre, 12:30 PM',
      role: 'Limpieza del Salón del Reino',
      category: 'limpieza',
      detail: 'Grupo de servicio #3: Aspirado y desinfección general.',
      reminderActive: false,
    },
  ]);

  // New Assignment Modal state
  const [showNewAssignmentForm, setShowNewAssignmentForm] = useState(false);
  const [newDate, setNewDate] = useState('Noviembre 2026');
  const [newRole, setNewRole] = useState('Lectura de la Biblia');
  const [newDetail, setNewDetail] = useState('');
  const [newCategory, setNewCategory] = useState<AssignmentItem['category']>('lectura');

  const weekdaysList = [
    { id: 0, label: 'L', name: 'Lunes' },
    { id: 1, label: 'M', name: 'Martes' },
    { id: 2, label: 'X', name: 'Miércoles' },
    { id: 3, label: 'J', name: 'Jueves' },
    { id: 4, label: 'V', name: 'Viernes' },
    { id: 5, label: 'S', name: 'Sábado' },
    { id: 6, label: 'D', name: 'Domingo' },
  ];

  // Dynamic Auto-Pacing Calculation
  // Total remaining hours to reach monthlyGoal
  const remainingHours = Math.max(0, monthlyGoal - hoursLogged);

  // Month days: Oct 16 to 31 (16 days remaining in current month)
  // Let's count how many remaining days fall on the selected weekdays
  const availableRemainingDaysCount = useMemo(() => {
    let count = 0;
    // Oct 16 is Friday (weekday index 4). Days 16 through 31:
    for (let day = 16; day <= 31; day++) {
      // 2026-10-16 is a Friday. JS getDay(): 0 Sun, 1 Mon, 2 Tue, 3 Wed, 4 Thu, 5 Fri, 6 Sat
      // Shift to 0 Mon -> 6 Sun
      const dateObj = new Date(2026, 9, day);
      const jsDay = dateObj.getDay();
      const mappedWeekday = jsDay === 0 ? 6 : jsDay - 1;

      if (selectedWeekdays.includes(mappedWeekday)) {
        // If today is marked with conflict, skip today from active days!
        if (day === 16 && isTodayConflict) {
          continue;
        }
        count++;
      }
    }
    return Math.max(1, count);
  }, [selectedWeekdays, isTodayConflict]);

  // Suggested Pace: remainingHours / availableRemainingDaysCount
  const suggestedDailyPace = useMemo(() => {
    return (remainingHours / availableRemainingDaysCount).toFixed(1);
  }, [remainingHours, availableRemainingDaysCount]);

  // Toggle Weekday
  const handleToggleWeekday = (id: number) => {
    setSelectedWeekdays((prev) =>
      prev.includes(id) ? prev.filter((d) => d !== id) : [...prev, id].sort((a, b) => a - b)
    );
  };

  // Weather/Conflict Shield Action
  const handleToggleConflict = () => {
    const nextState = !isTodayConflict;
    setIsTodayConflict(nextState);

    // Haptic pulse if supported on mobile
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate(50);
    }

    setConflictNotice(true);
    setTimeout(() => setConflictNotice(false), 3000);
  };

  // Toggle reminder for assignment
  const handleToggleReminder = (id: string) => {
    setAssignments((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, reminderActive: !item.reminderActive } : item
      )
    );
  };

  // Create new assignment
  const handleCreateAssignment = () => {
    if (!newDetail.trim()) return;
    const newItem: AssignmentItem = {
      id: `asg-${Date.now()}`,
      date: newDate,
      role: newRole,
      category: newCategory,
      detail: newDetail.trim(),
      reminderActive: true,
    };
    setAssignments((prev) => [newItem, ...prev]);
    setNewDetail('');
    setShowNewAssignmentForm(false);
  };

  const getRoleIcon = (cat: AssignmentItem['category']) => {
    switch (cat) {
      case 'lectura':
        return <BookOpen className="w-4 h-4 text-[#276160]" strokeWidth={1.75} />;
      case 'discurso':
        return <Mic className="w-4 h-4 text-[#EBB634]" strokeWidth={1.75} />;
      case 'audiovideo':
        return <Headphones className="w-4 h-4 text-[#276160]" strokeWidth={1.75} />;
      case 'limpieza':
        return <Sparkles className="w-4 h-4 text-[#6BA78D]" strokeWidth={1.75} />;
      case 'acomodador':
      default:
        return <Users className="w-4 h-4 text-[#276160]" strokeWidth={1.75} />;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/40 backdrop-blur-sm"
      />

      {/* Full-Screen Glass Modal Sliding Up From Bottom */}
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 28, stiffness: 300 }}
        className="fixed inset-0 z-50 bg-[#FAF7F0]/95 dark:bg-[#0B1716]/95 backdrop-blur-3xl overflow-y-auto px-5 py-8 flex flex-col justify-start"
      >
        <div className="w-full max-w-md mx-auto flex flex-col gap-6">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-black/[0.06] dark:border-white/10 pb-3">
            <div>
              <h2 className="text-sm font-extrabold text-[#112625] dark:text-[#F6F4EE] uppercase tracking-wider">
                CALENDARIO Y ASIGNACIONES
              </h2>
              <span className="text-[11px] font-medium text-[#276160] dark:text-[#A7C7C6]">
                Estudio Inteligente de Predicación y Congregación
              </span>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="Cerrar modal"
              className="w-9 h-9 rounded-full bg-white/80 dark:bg-white/10 border border-white/90 dark:border-white/20 shadow-sm flex items-center justify-center text-[#112625] dark:text-[#F6F4EE] active:scale-95 transition-transform cursor-pointer"
            >
              <X className="w-4 h-4" strokeWidth={1.75} />
            </button>
          </div>

          {/* Sleek Translucent Glass Segmented Control */}
          <div className="p-1 rounded-2xl bg-white/60 backdrop-blur-xl border border-white/80 shadow-sm flex items-center gap-1">
            <button
              type="button"
              onClick={() => setActiveTab('predicacion')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'predicacion'
                  ? 'bg-gradient-to-r from-[#EBB634] to-[#B78628] text-white shadow-md'
                  : 'text-[#112625]/70 hover:text-[#112625]'
              }`}
            >
              <Briefcase className="w-3.5 h-3.5" strokeWidth={1.75} />
              <span>Predicación</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('asignaciones')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'asignaciones'
                  ? 'bg-[#276160] text-white shadow-md'
                  : 'text-[#112625]/70 hover:text-[#112625]'
              }`}
            >
              <Mic className="w-3.5 h-3.5" strokeWidth={1.75} />
              <span>Asignaciones</span>
            </button>
          </div>

          {/* TAB A: PREDICACIÓN & AUTO-PACING */}
          {activeTab === 'predicacion' && (
            <div className="flex flex-col gap-5">
              {/* 1. Weekly Setup Card */}
              <div className="p-5 rounded-3xl bg-white/60 border border-white/80 shadow-sm flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold uppercase tracking-wider text-[#276160]">
                    Días Habituales de Salida
                  </span>
                  <span className="text-[11px] font-medium text-[#112625]/60">
                    {selectedWeekdays.length} días activos
                  </span>
                </div>
                <p className="text-[11px] text-[#112625]/75 leading-relaxed">
                  Toca los días en que predicas semanalmente para calibrar tu ritmo automático:
                </p>

                {/* 7 circular toggle buttons (L, M, X, J, V, S, D) */}
                <div className="flex items-center justify-between pt-1">
                  {weekdaysList.map((day) => {
                    const isSelected = selectedWeekdays.includes(day.id);
                    return (
                      <button
                        key={day.id}
                        type="button"
                        onClick={() => handleToggleWeekday(day.id)}
                        title={day.name}
                        className={`w-10 h-10 rounded-full text-xs font-extrabold transition-all flex items-center justify-center cursor-pointer shadow-sm ${
                          isSelected
                            ? 'bg-gradient-to-br from-[#EBB634] to-[#B78628] text-white ring-2 ring-[#EBB634]/40 scale-105'
                            : 'bg-white/80 border border-[#E5E0D5] text-[#112625]/65 hover:bg-white'
                        }`}
                      >
                        {day.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 2. Auto-Pacing Engine */}
              <div className="p-6 rounded-3xl bg-white/60 border border-white/80 shadow-sm flex flex-col gap-4 relative overflow-hidden">
                {/* Warm amber backdrop blur */}
                <div className="absolute top-0 right-0 w-36 h-36 bg-[#EBB634]/15 rounded-full blur-2xl pointer-events-none -z-10" />

                <div className="flex items-center justify-between border-b border-black/[0.05] pb-3">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#276160] block">
                      Horas Faltantes
                    </span>
                    <span className="text-base font-extrabold text-[#112625]">
                      {remainingHours}h
                    </span>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#276160] block">
                      Días Hábiles Seleccionados
                    </span>
                    <span className="text-base font-extrabold text-[#112625]">
                      {availableRemainingDaysCount}
                    </span>
                  </div>
                </div>

                {/* Large Glowing Readout */}
                <div className="flex flex-col items-center justify-center py-2 text-center">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#B78628]">
                    Ritmo Sugerido
                  </span>
                  <motion.div
                    key={`${suggestedDailyPace}-${isTodayConflict}`}
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="text-3xl font-black text-[#112625] tracking-tight mt-0.5 drop-shadow-sm"
                  >
                    {suggestedDailyPace} hrs / día
                  </motion.div>
                  <span className="text-[11px] text-[#276160]/80 mt-1 font-medium">
                    Calculado para alcanzar tu meta de {monthlyGoal} hrs en Octubre
                  </span>
                </div>
              </div>

              {/* 3. The "Weather/Conflict Shield" (Reprogramación) */}
              <div className="p-5 rounded-3xl bg-white/60 border border-white/80 shadow-sm flex flex-col gap-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-[#276160]" strokeWidth={1.75} />
                    <span className="text-xs font-extrabold uppercase tracking-wider text-[#276160]">
                      Escudo de Imprevistos & Reprogramación
                    </span>
                  </div>
                  {isTodayConflict && (
                    <span className="text-[10px] font-extrabold text-amber-700 bg-amber-100 px-2.5 py-0.5 rounded-full border border-amber-300">
                      Reprogramado
                    </span>
                  )}
                </div>

                {/* Today's scheduled block */}
                <div
                  className={`p-3.5 rounded-2xl border transition-all ${
                    isTodayConflict
                      ? 'bg-amber-50/60 border-amber-200 line-through opacity-60'
                      : 'bg-white/80 border-[#EBB634]/35'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-bold text-[#112625]">
                    <span>Hoy: Viernes 16 de Octubre</span>
                    <span className="font-semibold text-[#276160]">
                      Bloque 9:00 AM - 11:30 AM
                    </span>
                  </div>
                  <p className="text-[11px] text-[#112625]/75 mt-0.5 no-underline">
                    Predicación de casa en casa y revisitas programadas.
                  </p>
                </div>

                {/* Conflict Notice Toast */}
                <AnimatePresence>
                  {conflictNotice && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="text-xs font-semibold p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 flex items-center gap-2"
                    >
                      <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>
                        {isTodayConflict
                          ? 'Día cancelado. Tu ritmo diario fue recalculado automáticamente.'
                          : 'Día reincorporado a tu calendario de servicio.'}
                      </span>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Prominent 1-Tap Button: Imprevisto / No pude salir hoy */}
                <button
                  type="button"
                  onClick={handleToggleConflict}
                  className={`w-full py-3 px-4 rounded-2xl text-xs font-extrabold transition-all flex items-center justify-center gap-2 active:scale-95 shadow-sm cursor-pointer ${
                    isTodayConflict
                      ? 'bg-white border border-[#276160] text-[#276160]'
                      : 'bg-gradient-to-r from-amber-500 to-[#B78628] text-white hover:opacity-95'
                  }`}
                >
                  {isTodayConflict ? (
                    <span>Reactivar Bloque de Hoy</span>
                  ) : (
                    <>
                      <CloudRain className="w-4 h-4 text-white" strokeWidth={2} />
                      <span>Imprevisto / No pude salir hoy</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* TAB B: ASIGNACIONES & PRIVILEGIOS (CONGREGATION DUTIES) */}
          {activeTab === 'asignaciones' && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase tracking-wider text-[#276160]">
                  Línea de Tiempo de Asignaciones
                </span>
                <button
                  type="button"
                  onClick={() => setShowNewAssignmentForm(true)}
                  className="text-xs font-extrabold text-[#B78628] flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Nueva Asignación</span>
                </button>
              </div>

              {/* Vertical Timeline */}
              <div className="flex flex-col gap-3 relative">
                {assignments.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 rounded-3xl bg-white/60 border border-white/80 shadow-sm flex flex-col gap-2 relative transition-all hover:bg-white/75"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-white/80 shadow-xs flex items-center justify-center">
                          {getRoleIcon(item.category)}
                        </div>
                        <span className="text-xs font-extrabold text-[#112625]">
                          {item.role}
                        </span>
                      </div>
                      <span className="text-[10px] font-semibold text-[#B78628]">
                        {item.date.split(',')[0]}
                      </span>
                    </div>

                    <p className="text-[11px] text-[#112625]/80 leading-relaxed pl-1">
                      {item.detail}
                    </p>

                    <div className="pt-2 border-t border-black/[0.04] flex items-center justify-between">
                      <span className="text-[10px] font-medium text-[#112625]/60">
                        {item.date}
                      </span>

                      {/* Toggle switch for Aviso de Preparación (3 días antes) */}
                      <button
                        type="button"
                        onClick={() => handleToggleReminder(item.id)}
                        className={`text-[10px] font-bold px-3 py-1 rounded-full border transition-all flex items-center gap-1.5 cursor-pointer ${
                          item.reminderActive
                            ? 'bg-[#EBB634]/20 border-[#EBB634] text-[#8C6308]'
                            : 'bg-black/[0.03] border-transparent text-[#112625]/50'
                        }`}
                      >
                        <Bell className="w-3 h-3 text-[#B78628]" strokeWidth={2} />
                        <span>Aviso de Preparación (3 días antes)</span>
                        <div
                          className={`w-3 h-3 rounded-full flex items-center justify-center text-white ${
                            item.reminderActive ? 'bg-[#B78628]' : 'bg-black/20'
                          }`}
                        >
                          {item.reminderActive && <Check className="w-2 h-2" strokeWidth={3} />}
                        </div>
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Floating + Nueva Asignación Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewAssignmentForm(true)}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#276160] to-[#1A4B4A] text-white text-xs font-extrabold shadow-md flex items-center justify-center gap-1.5 active:scale-95 transition-transform cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Nueva Asignación</span>
                </button>
              </div>

              {/* Mini Modal Form for New Assignment */}
              <AnimatePresence>
                {showNewAssignmentForm && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="p-4 rounded-3xl bg-white/95 border border-[#EBB634]/40 shadow-xl flex flex-col gap-3 mt-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-extrabold uppercase tracking-wider text-[#276160]">
                        Agregar Asignación de Congregación
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowNewAssignmentForm(false)}
                        className="p-1 rounded-full text-black/50 hover:text-black"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex flex-col gap-1">
                      <label className="text-[10px] font-bold text-[#112625]/70">Tipo de Asignación</label>
                      <select
                        value={newRole}
                        onChange={(e) => {
                          setNewRole(e.target.value);
                          if (e.target.value.includes('Lectura')) setNewCategory('lectura');
                          else if (e.target.value.includes('Discurso')) setNewCategory('discurso');
                          else if (e.target.value.includes('Audio')) setNewCategory('audiovideo');
                          else if (e.target.value.includes('Limpieza')) setNewCategory('limpieza');
                          else setNewCategory('acomodador');
                        }}
                        className="w-full py-2 px-3 rounded-xl bg-[#FAF7F0] border border-black/10 text-xs font-semibold"
                      >
                        <option value="Lectura de la Biblia">Lectura de la Biblia</option>
                        <option value="Discurso Público">Discurso Público</option>
                        <option value="Audio y Video">Audio y Video</option>
                        <option value="Limpieza del Salón del Reino">Limpieza del Salón del Reino</option>
                        <option value="Acomodador y Micrófonos">Acomodador y Micrófonos</option>
                      </select>
                    </div>

                    <div className="flex flex-col gap-1">
                      <label className="text-[10px] font-bold text-[#112625]/70">Fecha y Hora</label>
                      <input
                        type="text"
                        value={newDate}
                        onChange={(e) => setNewDate(e.target.value)}
                        placeholder="ej. Domingo 1 de Noviembre, 10:00 AM"
                        className="w-full py-2 px-3 rounded-xl bg-[#FAF7F0] border border-black/10 text-xs font-semibold"
                      />
                    </div>

                    <div className="flex flex-col gap-1">
                      <label className="text-[10px] font-bold text-[#112625]/70">Detalles o Notas</label>
                      <input
                        type="text"
                        value={newDetail}
                        onChange={(e) => setNewDetail(e.target.value)}
                        placeholder="ej. Capítulo a leer o bosquejo asignado..."
                        className="w-full py-2 px-3 rounded-xl bg-[#FAF7F0] border border-black/10 text-xs"
                      />
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setShowNewAssignmentForm(false)}
                        className="px-3 py-1.5 rounded-xl bg-black/5 text-xs font-semibold text-[#112625]"
                      >
                        Cancelar
                      </button>
                      <button
                        type="button"
                        onClick={handleCreateAssignment}
                        className="px-4 py-1.5 rounded-xl bg-[#276160] text-white text-xs font-extrabold shadow-sm"
                      >
                        Guardar
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
