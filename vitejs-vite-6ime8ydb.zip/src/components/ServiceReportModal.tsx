import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Send, Copy, Check } from 'lucide-react';

interface ServiceReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  userName: string;
  hoursLogged: number;
  cursosCount: number;
  revisitasCount: number;
}

export const ServiceReportModal: React.FC<ServiceReportModalProps> = ({
  isOpen,
  onClose,
  userName,
  hoursLogged,
  cursosCount,
  revisitasCount,
}) => {
  const [copied, setCopied] = useState(false);
  const [additionalNotes, setAdditionalNotes] = useState('Mes activo como precursor.');

  const reportText = `INFORME DEL SERVICIO DEL CAMPO
Publicador: ${userName}
Mes: Octubre 2026
Participó en el ministerio: Sí
Horas realizadas: ${hoursLogged}
Cursos bíblicos diferentes dirigidos: ${cursosCount}
Revisitas: ${revisitasCount}
Comentarios: ${additionalNotes}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(reportText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/45 backdrop-blur-md overflow-hidden">
      <motion.div
        initial={{ opacity: 0, y: 35, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 25, scale: 0.98 }}
        transition={{ type: 'spring', damping: 25, stiffness: 280 }}
        className="w-full h-full sm:h-auto sm:max-w-md bg-[#FAF7F0]/95 backdrop-blur-3xl sm:rounded-[36px] flex flex-col shadow-2xl border border-white overflow-hidden relative"
      >
        {/* Header */}
        <div className="p-4 border-b border-black/[0.06] bg-white/70 backdrop-blur-xl flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#276160]/10 flex items-center justify-center">
              <Send className="w-4 h-4 text-[#276160]" strokeWidth={1.75} />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-[#112625] uppercase tracking-wider">
                Informe Mensual de Servicio
              </h3>
              <span className="text-[11px] font-medium text-[#276160]">
                Octubre 2026 · {userName}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-black/5 hover:bg-black/10 flex items-center justify-center text-[#112625] active:scale-95 transition-transform"
          >
            <X className="w-4 h-4" strokeWidth={1.75} />
          </button>
        </div>

        {/* Report Content */}
        <div className="p-5 flex flex-col gap-4">
          <div className="p-4 rounded-2xl bg-white/80 border border-black/[0.06] shadow-sm flex flex-col gap-2 font-mono text-xs text-[#112625] leading-relaxed">
            <div className="flex justify-between border-b border-black/[0.05] pb-1.5 font-sans font-bold text-[#276160]">
              <span>Publicador:</span>
              <span>{userName}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-sans text-[#112625]/70">Mes:</span>
              <span className="font-bold">Octubre 2026</span>
            </div>
            <div className="flex justify-between">
              <span className="font-sans text-[#112625]/70">¿Participó en el ministerio?:</span>
              <span className="font-bold text-[#276160]">Sí</span>
            </div>
            <div className="flex justify-between">
              <span className="font-sans text-[#112625]/70">Horas:</span>
              <span className="font-bold text-base text-[#112625]">{hoursLogged}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-sans text-[#112625]/70">Cursos bíblicos:</span>
              <span className="font-bold">{cursosCount}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-sans text-[#112625]/70">Revisitas:</span>
              <span className="font-bold">{revisitasCount}</span>
            </div>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold uppercase tracking-wider text-[#112625]/70">
              Comentarios adicionales para el Secretario:
            </label>
            <input
              type="text"
              value={additionalNotes}
              onChange={(e) => setAdditionalNotes(e.target.value)}
              className="w-full py-2 px-3 rounded-xl bg-white border border-[#EBB634]/35 text-xs text-[#112625]"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 pt-2">
            <button
              type="button"
              onClick={handleCopy}
              className="flex-1 py-2.5 px-4 rounded-xl bg-[#276160] text-white text-xs font-bold flex items-center justify-center gap-1.5 active:scale-95 transition-transform cursor-pointer shadow-sm"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? '¡Copiado al Portapapeles!' : 'Copiar Informe'}</span>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
