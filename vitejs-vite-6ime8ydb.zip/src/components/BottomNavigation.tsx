import React from 'react';
import { motion } from 'motion/react';
import { Search, Home, Briefcase, Book, Settings } from 'lucide-react';

export type NavTabType = 'search' | 'home' | 'ministerio' | 'biblia' | 'settings';

interface BottomNavigationProps {
  activeTab: NavTabType;
  onChangeTab: (tab: NavTabType) => void;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  activeTab,
  onChangeTab,
}) => {
  return (
    <nav
      aria-label="Navegación principal"
      className="fixed bottom-4 inset-x-5 max-w-md mx-auto z-40 h-16 rounded-full bg-white/80 dark:bg-[#0B1716]/85 backdrop-blur-2xl border border-white dark:border-white/20 shadow-[0_12px_35px_rgba(235,182,52,0.25)] flex items-center justify-around px-3 select-none"
    >
      {/* 1. Search (Opens Library Overlay focused on Smart Search) */}
      <button
        type="button"
        onClick={() => onChangeTab('search')}
        aria-label="Buscar en biblioteca"
        title="Búsqueda Inteligente"
        className="p-2.5 rounded-full text-[#112625]/70 dark:text-[#F6F4EE]/70 hover:text-[#276160] dark:hover:text-[#EBB634] active:scale-95 transition-all cursor-pointer"
      >
        <Search className="w-5 h-5" strokeWidth={1.75} />
      </button>

      {/* 2. Home inside active pill (Hoy — Main Dashboard) */}
      <button
        type="button"
        onClick={() => onChangeTab('home')}
        aria-label="Inicio hoy"
        title="Hoy"
        className={`flex items-center gap-1.5 py-2 px-4 rounded-full transition-all cursor-pointer ${
          activeTab === 'home'
            ? 'bg-gradient-to-r from-[#EBB634] to-[#B78628] text-white shadow-[0_4px_12px_rgba(235,182,52,0.35)]'
            : 'text-[#112625]/70 dark:text-[#F6F4EE]/70 hover:text-[#276160] dark:hover:text-[#EBB634]'
        }`}
      >
        <Home className="w-4 h-4" strokeWidth={1.75} />
        {activeTab === 'home' && (
          <span className="text-xs font-bold tracking-tight">Hoy</span>
        )}
      </button>

      {/* 3. Briefcase (Ministerio — Full Preaching, Revisitas & Cursos Studio) */}
      <button
        type="button"
        onClick={() => onChangeTab('ministerio')}
        aria-label="Ministerio y Servicio"
        title="Ministerio del Campo"
        className={`p-2.5 rounded-full transition-all cursor-pointer ${
          activeTab === 'ministerio'
            ? 'text-[#276160] dark:text-[#EBB634] font-bold scale-110'
            : 'text-[#112625]/70 dark:text-[#F6F4EE]/70 hover:text-[#276160] dark:hover:text-[#EBB634] active:scale-95'
        }`}
      >
        <Briefcase className="w-5 h-5" strokeWidth={1.75} />
      </button>

      {/* 4. Book (Biblia — Full 66-Book Reading Matrix & Bookmark Studio) */}
      <button
        type="button"
        onClick={() => onChangeTab('biblia')}
        aria-label="Biblia y Lectura"
        title="Matriz de los 66 Libros de la Biblia"
        className={`p-2.5 rounded-full transition-all cursor-pointer ${
          activeTab === 'biblia'
            ? 'text-[#276160] dark:text-[#EBB634] font-bold scale-110'
            : 'text-[#112625]/70 dark:text-[#F6F4EE]/70 hover:text-[#276160] dark:hover:text-[#EBB634] active:scale-95'
        }`}
      >
        <Book className="w-5 h-5" strokeWidth={1.75} />
      </button>

      {/* 5. Settings (Ajustes — User Name, Goal, API Key, Replay) */}
      <button
        type="button"
        onClick={() => onChangeTab('settings')}
        aria-label="Ajustes y configuración"
        title="Ajustes"
        className={`p-2.5 rounded-full transition-all cursor-pointer ${
          activeTab === 'settings'
            ? 'text-[#276160] dark:text-[#EBB634] font-bold scale-110'
            : 'text-[#112625]/70 dark:text-[#F6F4EE]/70 hover:text-[#276160] dark:hover:text-[#EBB634] active:scale-95'
        }`}
      >
        <Settings className="w-5 h-5" strokeWidth={1.75} />
      </button>
    </nav>
  );
};
