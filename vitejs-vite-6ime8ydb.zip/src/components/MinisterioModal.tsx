import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Clock,
  Users,
  BookOpen,
  Plus,
  Check,
  MapPin,
  ArrowDownToLine,
  Sparkles,
  TrendingUp,
  Vault,
  Star,
} from 'lucide-react';

interface MinisterioModalProps {
  isOpen: boolean;
  onClose: () => void;
  hoursLogged: number;
  monthlyGoal: number;
  onAddHours: (hrs: number) => void;
  revisitasList: string[];
  cursosList: string[];
  initialSubTab?: 'hours' | 'revisitas' | 'cursos';
}

export const MinisterioModal: React.FC<MinisterioModalProps> = ({
  isOpen,
  onClose,
  hoursLogged,
  monthlyGoal: initialMonthlyGoal,
  onAddHours,
  revisitasList: initialRevisitas,
  cursosList: initialCursos,
  initialSubTab = 'hours',
}) => {
  const [subTab, setSubTab] = useState<'hours' | 'revisitas' | 'cursos'>(initialSubTab);

  // Sync tab if opened from specific bento card
  React.useEffect(() => {
    if (initialSubTab) {
      setSubTab(initialSubTab);
    }
  }, [initialSubTab]);

  // Campaign Mode State: 'normal' (50h) | 'campana30' (30h) | 'campana15' (15h)
  const [isCampaignMode, setIsCampaignMode] = useState(false);
  const [campaignTarget, setCampaignTarget] = useState<30 | 15>(30);

  // Active Target based on Campaign Toggle
  const activeTargetGoal = isCampaignMode ? campaignTarget : initialMonthlyGoal;

  // El Banco de Minutos State (45 minutes by default)
  const [bankedMinutes, setBankedMinutes] = useState(45);
  const [transferCelebration, setTransferCelebration] = useState(false);

  // Revisitas details state
  const [revisitas, setRevisitas] = useState([
    {
      id: 'rev-1',
      name: 'Luis',
      address: 'Calle Los Pinos #14, Apto 2B',
      topic: 'El propósito del sufrimiento humano (2 Cor. 1:3, 4)',
      date: '15 de Octubre',
      nextVisit: 'Viernes 23 de Octubre',
      status: 'Interesado',
    },
    {
      id: 'rev-2',
      name: 'Alberto',
      address: 'Av. Libertador, Edif. Manantial 4A',
      topic: 'La creación frente a la evolución (Salmo 104)',
      date: '11 de Octubre',
      nextVisit: 'Domingo 25 de Octubre',
      status: 'Pregunta pendiente',
    },
  ]);

  // Cursos details state
  const [cursos, setCursos] = useState([
    {
      id: 'cur-1',
      name: 'Josué',
      book: 'Disfrute de la vida para siempre',
      lesson: 'Lección 14: Cómo orar a Dios',
      day: 'Martes 6:00 PM',
      notes: 'Muy receptivo, prepara sus párrafos.',
    },
    {
      id: 'cur-2',
      name: 'Carlos',
      book: 'Disfrute de la vida para siempre',
      lesson: 'Lección 09: ¿Quién es Jesús?',
      day: 'Jueves 7:30 PM',
      notes: 'Asistió a su primera reunión el domingo.',
    },
    {
      id: 'cur-3',
      name: 'Andrés',
      book: 'Disfrute de la vida para siempre',
      lesson: 'Lección 22: El bautismo cristiano',
      day: 'Sábado 4:00 PM',
      notes: 'Pensando en ser publicador no bautizado.',
    },
    {
      id: 'cur-4',
      name: 'Mateo',
      book: 'Disfrute de la vida para siempre',
      lesson: 'Lección 04: ¿Quién es el autor de la Biblia?',
      day: 'Lunes 5:30 PM',
      notes: 'Joven estudiante universitario.',
    },
  ]);

  const [newPersonName, setNewPersonName] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  // Calculations
  const remainingHours = Math.max(0, activeTargetGoal - hoursLogged);
  const daysInMonth = 31;
  const currentDay = 16;
  const daysRemaining = daysInMonth - currentDay;
  const requiredDailyAverage = (remainingHours / Math.max(1, daysRemaining)).toFixed(1);

  // Monthly Horizon Pace Chart Coordinates (Day 1 to 31, Hours 0 to activeTargetGoal)
  // Ideal pace line: from (0,0) to (31, activeTargetGoal)
  // Current month logged path up to Day 16:
  // e.g. Day 1: 1.5, Day 5: 9.0, Day 10: 18.0, Day 16: hoursLogged (30)
  const chartWidth = 320;
  const chartHeight = 130;
  const paddingX = 25;
  const paddingY = 15;
  const innerW = chartWidth - paddingX * 2;
  const innerH = chartHeight - paddingY * 2;

  // Map day (0..31) to X
  const getX = (day: number) => paddingX + (day / 31) * innerW;
  // Map hours (0..max) to Y
  const maxChartHours = Math.max(activeTargetGoal, hoursLogged, 50);
  const getY = (hrs: number) => chartHeight - paddingY - (hrs / maxChartHours) * innerH;

  // Interpolated logged curve up to day 16
  const p0 = { x: getX(0), y: getY(0) };
  const p1 = { x: getX(5), y: getY(9.5) };
  const p2 = { x: getX(10), y: getY(18.5) };
  const pCurrent = { x: getX(16), y: getY(hoursLogged) };

  // Spline path string
  const loggedSplineD = `M ${p0.x},${p0.y} Q ${getX(4)},${getY(6)} ${p1.x},${p1.y} T ${p2.x},${p2.y} T ${pCurrent.x},${pCurrent.y}`;
  const loggedAreaD = `${loggedSplineD} L ${pCurrent.x},${chartHeight - paddingY} L ${p0.x},${chartHeight - paddingY} Z`;

  // Straight ideal diagonal line from day 0 to day 31
  const idealX1 = getX(0);
  const idealY1 = getY(0);
  const idealX2 = getX(31);
  const idealY2 = getY(activeTargetGoal);

  // Year in Service (Sept - Ago) - 6 months bar chart
  const serviceYearData = [
    { month: 'May', hours: 52 },
    { month: 'Jun', hours: 48 },
    { month: 'Jul', hours: 50 },
    { month: 'Ago', hours: 54 },
    { month: 'Sep', hours: 51 },
    { month: 'Oct', hours: hoursLogged, isCurrent: true },
  ];

  // Transfer minutes from the Bank to the current month
  const handleTransferMinutes = () => {
    if (bankedMinutes <= 0) return;
    const hoursFraction = parseFloat((bankedMinutes / 60).toFixed(2));
    onAddHours(hoursFraction);
    setBankedMinutes(0);
    setTransferCelebration(true);

    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate(60);
    }

    setTimeout(() => {
      setTransferCelebration(false);
    }, 2800);
  };

  const handleAddNew = () => {
    if (!newPersonName.trim()) return;
    if (subTab === 'revisitas') {
      setRevisitas((prev) => [
        ...prev,
        {
          id: `rev-${Date.now()}`,
          name: newPersonName.trim(),
          address: 'Por registrar',
          topic: 'Primera conversación bíblica',
          date: 'Hoy',
          nextVisit: 'Próxima semana',
          status: 'Nuevo',
        },
      ]);
    } else {
      setCursos((prev) => [
        ...prev,
        {
          id: `cur-${Date.now()}`,
          name: newPersonName.trim(),
          book: 'Disfrute de la vida para siempre',
          lesson: 'Lección 01',
          day: 'Por coordinar',
          notes: 'Nuevo curso bíblico iniciado.',
        },
      ]);
    }
    setNewPersonName('');
    setShowAddForm(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/40 backdrop-blur-sm"
      />

      {/* Full-Screen Glass Modal Sliding Up From Bottom */}
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 28, stiffness: 300 }}
        className="fixed inset-0 z-50 bg-[#FAF7F0]/95 backdrop-blur-3xl overflow-y-auto px-5 py-8 flex flex-col justify-start"
      >
        <div className="w-full max-w-md mx-auto flex flex-col gap-6">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-black/[0.06] pb-3">
            <div>
              <h2 className="text-sm font-extrabold text-[#112625] uppercase tracking-wider">
                ESTUDIO DEL MINISTERIO DEL CAMPO
              </h2>
              <span className="text-[11px] font-medium text-[#276160]">
                Analítica Avanzada, Ritmo & Gestión Teocrática
              </span>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="Cerrar modal"
              className="w-9 h-9 rounded-full bg-white/80 border border-white/90 shadow-sm flex items-center justify-center text-[#112625] active:scale-95 transition-transform cursor-pointer"
            >
              <X className="w-4 h-4" strokeWidth={1.75} />
            </button>
          </div>

          {/* Sub Tabs: Horas, Revisitas, Cursos */}
          <div className="p-1 rounded-2xl bg-white/60 backdrop-blur-xl border border-white/80 shadow-sm flex items-center gap-1">
            <button
              type="button"
              onClick={() => setSubTab('hours')}
              className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                subTab === 'hours'
                  ? 'bg-gradient-to-r from-[#EBB634] to-[#B78628] text-white shadow-md'
                  : 'text-[#112625]/70 hover:bg-white/50'
              }`}
            >
              <Clock className="w-3.5 h-3.5" strokeWidth={1.75} />
              <span>Horas ({hoursLogged}h)</span>
            </button>

            <button
              type="button"
              onClick={() => setSubTab('revisitas')}
              className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                subTab === 'revisitas'
                  ? 'bg-[#276160] text-white shadow-md'
                  : 'text-[#112625]/70 hover:bg-white/50'
              }`}
            >
              <Users className="w-3.5 h-3.5" strokeWidth={1.75} />
              <span>Revisitas ({revisitas.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setSubTab('cursos')}
              className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                subTab === 'cursos'
                  ? 'bg-[#276160] text-white shadow-md'
                  : 'text-[#112625]/70 hover:bg-white/50'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" strokeWidth={1.75} />
              <span>Cursos ({cursos.length})</span>
            </button>
          </div>

          {/* TAB 1: HOURS & DEEP ANALYTICS */}
          {subTab === 'hours' && (
            <div className="flex flex-col gap-5">
              {/* Total Hours Hero Glass Card */}
              <div className="p-6 rounded-3xl bg-white/60 border border-white/80 shadow-sm flex flex-col gap-4 relative overflow-hidden">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#276160] block">
                      Horas Acumuladas en Octubre
                    </span>
                    <div className="text-4xl font-black text-[#112625] tracking-tight mt-0.5">
                      {hoursLogged} <span className="text-lg font-bold text-[#B78628]">hrs</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#276160] block">
                      Meta Activa
                    </span>
                    <span className="text-xl font-extrabold text-[#112625]">
                      {activeTargetGoal} hrs
                    </span>
                  </div>
                </div>

                {/* Progress bar towards active target */}
                <div className="w-full h-3 rounded-full bg-[#E8E4DA]/70 overflow-hidden relative">
                  <motion.div
                    className="h-full rounded-full bg-gradient-to-r from-[#EBB634] to-[#276160]"
                    initial={{ width: 0 }}
                    animate={{
                      width: `${Math.min(100, (hoursLogged / activeTargetGoal) * 100)}%`,
                    }}
                    transition={{ duration: 0.8, ease: 'easeOut' }}
                  />
                </div>

                {/* Stats Breakdown Row */}
                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-black/[0.05] text-center">
                  <div>
                    <span className="text-[10px] text-[#112625]/60 block">Completado</span>
                    <span className="text-xs font-extrabold text-[#112625]">
                      {Math.round((hoursLogged / activeTargetGoal) * 100)}%
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#112625]/60 block">Faltantes</span>
                    <span className="text-xs font-extrabold text-[#B78628]">
                      -{remainingHours} hrs
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#112625]/60 block">Ritmo Diario</span>
                    <span className="text-xs font-extrabold text-[#276160]">
                      {requiredDailyAverage} h/d
                    </span>
                  </div>
                </div>

                {/* CAMPAIGN MODE TOGGLE: Mes de Campaña Especial */}
                <div className="mt-2 pt-3 border-t border-black/[0.06] flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-xs font-extrabold text-[#112625] flex items-center gap-1.5">
                      <Star className="w-3.5 h-3.5 text-[#B78628] fill-[#EBB634]" />
                      <span>Mes de Campaña Especial</span>
                    </span>
                    <span className="text-[10px] text-[#276160]">
                      {isCampaignMode
                        ? `Meta ajustada a ${campaignTarget}h (Precursor Auxiliar)`
                        : 'Meta regular de 50h (Precursor Regular)'}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {isCampaignMode && (
                      <div className="flex items-center rounded-xl bg-white/80 p-0.5 border border-[#EBB634]/40">
                        <button
                          type="button"
                          onClick={() => setCampaignTarget(30)}
                          className={`text-[10px] font-extrabold px-2 py-0.5 rounded-lg transition-all ${
                            campaignTarget === 30
                              ? 'bg-[#EBB634] text-white shadow-xs'
                              : 'text-[#112625]/60'
                          }`}
                        >
                          30h
                        </button>
                        <button
                          type="button"
                          onClick={() => setCampaignTarget(15)}
                          className={`text-[10px] font-extrabold px-2 py-0.5 rounded-lg transition-all ${
                            campaignTarget === 15
                              ? 'bg-[#EBB634] text-white shadow-xs'
                              : 'text-[#112625]/60'
                          }`}
                        >
                          15h
                        </button>
                      </div>
                    )}

                    {/* Toggle Switch */}
                    <button
                      type="button"
                      onClick={() => setIsCampaignMode(!isCampaignMode)}
                      className={`w-11 h-6 rounded-full transition-colors relative flex items-center p-0.5 cursor-pointer ${
                        isCampaignMode ? 'bg-[#EBB634]' : 'bg-black/15'
                      }`}
                    >
                      <motion.div
                        className="w-5 h-5 rounded-full bg-white shadow-sm"
                        animate={{ x: isCampaignMode ? 20 : 0 }}
                        transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                      />
                    </button>
                  </div>
                </div>
              </div>

              {/* Quick Log Chips (+15m, +30m, +1h, +2h) */}
              <div className="p-4 rounded-3xl bg-white/60 border border-white/80 shadow-sm flex flex-col gap-2.5">
                <span className="text-xs font-extrabold uppercase tracking-wider text-[#112625]/80">
                  Añadir horas de predicación
                </span>
                <div className="grid grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => onAddHours(0.25)}
                    className="py-2.5 rounded-2xl bg-white/80 border border-[#EBB634]/40 text-xs font-extrabold text-[#B78628] hover:bg-[#EBB634]/15 active:scale-95 shadow-sm transition-all cursor-pointer"
                  >
                    +15 min
                  </button>
                  <button
                    type="button"
                    onClick={() => onAddHours(0.5)}
                    className="py-2.5 rounded-2xl bg-white/80 border border-[#EBB634]/40 text-xs font-extrabold text-[#B78628] hover:bg-[#EBB634]/15 active:scale-95 shadow-sm transition-all cursor-pointer"
                  >
                    +30 min
                  </button>
                  <button
                    type="button"
                    onClick={() => onAddHours(1)}
                    className="py-2.5 rounded-2xl bg-white/80 border border-[#EBB634]/40 text-xs font-extrabold text-[#B78628] hover:bg-[#EBB634]/15 active:scale-95 shadow-sm transition-all cursor-pointer"
                  >
                    +1 hora
                  </button>
                  <button
                    type="button"
                    onClick={() => onAddHours(2)}
                    className="py-2.5 rounded-2xl bg-gradient-to-r from-[#EBB634] to-[#B78628] text-white text-xs font-extrabold active:scale-95 shadow-sm transition-all cursor-pointer"
                  >
                    +2 horas
                  </button>
                </div>
              </div>

              {/* THE HORIZON PACE CHART (Current Month) */}
              <div className="p-5 rounded-3xl bg-white/60 border border-white/80 shadow-sm flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-[#276160]" strokeWidth={1.75} />
                    <span className="text-xs font-extrabold uppercase tracking-wider text-[#276160]">
                      Horizonte de Ritmo Mensual
                    </span>
                  </div>
                  <span className="text-[10px] font-bold text-[#B78628]">
                    Día {currentDay} de {daysInMonth}
                  </span>
                </div>

                <p className="text-[11px] text-[#112625]/75 leading-relaxed">
                  Comparativa de horas registradas vs. ritmo lineal ideal hacia {activeTargetGoal} hrs:
                </p>

                {/* Wide SVG Spline Horizon Chart */}
                <div className="w-full h-36 bg-white/70 rounded-2xl p-2 border border-black/[0.04] relative flex items-center justify-center overflow-hidden">
                  <svg
                    viewBox={`0 0 ${chartWidth} ${chartHeight}`}
                    className="w-full h-full overflow-visible"
                  >
                    <defs>
                      <linearGradient id="horizonGoldFill" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#EBB634" stopOpacity="0.35" />
                        <stop offset="100%" stopColor="#EBB634" stopOpacity="0.02" />
                      </linearGradient>

                      <linearGradient id="horizonStrokeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#276160" />
                        <stop offset="60%" stopColor="#EBB634" />
                        <stop offset="100%" stopColor="#B78628" />
                      </linearGradient>
                    </defs>

                    {/* Horizontal Grid lines */}
                    <line
                      x1={paddingX}
                      y1={chartHeight - paddingY}
                      x2={chartWidth - paddingX}
                      y2={chartHeight - paddingY}
                      stroke="#E5E0D5"
                      strokeWidth="1"
                    />
                    <line
                      x1={paddingX}
                      y1={getY(activeTargetGoal / 2)}
                      x2={chartWidth - paddingX}
                      y2={getY(activeTargetGoal / 2)}
                      stroke="#E5E0D5"
                      strokeDasharray="3 3"
                      strokeWidth="0.8"
                    />
                    <line
                      x1={paddingX}
                      y1={getY(activeTargetGoal)}
                      x2={chartWidth - paddingX}
                      y2={getY(activeTargetGoal)}
                      stroke="#276160"
                      strokeDasharray="4 4"
                      strokeWidth="0.8"
                      strokeOpacity="0.4"
                    />

                    {/* Area under the logged curve */}
                    <path d={loggedAreaD} fill="url(#horizonGoldFill)" />

                    {/* Ideal Straight Diagonal Line */}
                    <line
                      x1={idealX1}
                      y1={idealY1}
                      x2={idealX2}
                      y2={idealY2}
                      stroke="#276160"
                      strokeWidth="1.5"
                      strokeDasharray="4 3"
                      strokeOpacity="0.5"
                    />

                    {/* Logged Spline Curve */}
                    <path
                      d={loggedSplineD}
                      fill="none"
                      stroke="url(#horizonStrokeGrad)"
                      strokeWidth="2.8"
                      strokeLinecap="round"
                    />

                    {/* Current Day Glowing Marker */}
                    <circle cx={pCurrent.x} cy={pCurrent.y} r="5" fill="#EBB634" />
                    <circle
                      cx={pCurrent.x}
                      cy={pCurrent.y}
                      r="9"
                      fill="#EBB634"
                      opacity="0.25"
                      className="animate-ping"
                    />

                    {/* Axis Labels */}
                    <text
                      x={paddingX}
                      y={chartHeight - 4}
                      fontSize="9"
                      fill="#112625"
                      opacity="0.6"
                      fontWeight="bold"
                    >
                      Día 1
                    </text>
                    <text
                      x={pCurrent.x - 14}
                      y={chartHeight - 4}
                      fontSize="9"
                      fill="#276160"
                      fontWeight="bold"
                    >
                      Hoy (16)
                    </text>
                    <text
                      x={chartWidth - paddingX - 24}
                      y={chartHeight - 4}
                      fontSize="9"
                      fill="#112625"
                      opacity="0.6"
                      fontWeight="bold"
                    >
                      Día 31
                    </text>

                    {/* Y-axis Labels */}
                    <text
                      x={paddingX + 2}
                      y={getY(activeTargetGoal) - 4}
                      fontSize="8"
                      fill="#276160"
                      fontWeight="bold"
                    >
                      Meta {activeTargetGoal}h
                    </text>
                  </svg>
                </div>

                {/* Legend */}
                <div className="flex items-center justify-between text-[10px] font-semibold text-[#112625]/75 px-1">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-1 bg-[#EBB634] rounded-full" />
                    <span>Tus Horas ({hoursLogged}h)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-0.5 border-t border-dashed border-[#276160]" />
                    <span>Ritmo Ideal ({(activeTargetGoal * (16 / 31)).toFixed(1)}h a la fecha)</span>
                  </div>
                </div>
              </div>

              {/* YEARLY VIEW & THE MINUTE BANK (Bottom Section) */}
              {/* 1. Año de Servicio (Sept - Ago) */}
              <div className="p-5 rounded-3xl bg-white/60 border border-white/80 shadow-sm flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold uppercase tracking-wider text-[#276160]">
                    Año de Servicio (Sept - Ago)
                  </span>
                  <span className="text-[10px] font-bold text-[#112625]/60">
                    Últimos 6 meses
                  </span>
                </div>

                {/* Horizontal Scrollable Mini Bar Chart */}
                <div className="flex items-end justify-between gap-2 pt-2 px-1">
                  {serviceYearData.map((item) => {
                    const barHeightPercent = Math.min(100, (item.hours / 60) * 100);
                    return (
                      <div key={item.month} className="flex-1 flex flex-col items-center gap-1.5">
                        <span className="text-[10px] font-bold text-[#112625]">
                          {item.hours}h
                        </span>
                        <div className="w-full h-20 bg-black/[0.04] rounded-xl flex items-end p-1">
                          <motion.div
                            initial={{ height: 0 }}
                            animate={{ height: `${barHeightPercent}%` }}
                            transition={{ duration: 0.8, ease: 'easeOut' }}
                            className={`w-full rounded-lg ${
                              item.isCurrent
                                ? 'bg-gradient-to-t from-[#EBB634] to-[#F6D365] shadow-xs'
                                : 'bg-[#276160]/75'
                            }`}
                          />
                        </div>
                        <span
                          className={`text-[10px] font-extrabold ${
                            item.isCurrent ? 'text-[#B78628]' : 'text-[#112625]/65'
                          }`}
                        >
                          {item.month}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 2. El Banco de Minutos (Glowing Glass Vault Card) */}
              <div className="p-5 rounded-3xl bg-gradient-to-br from-white/80 via-white/60 to-[#EBB634]/15 border border-white/90 shadow-md flex flex-col gap-3 relative overflow-hidden">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-[#EBB634]/25 flex items-center justify-center">
                      <Vault className="w-4 h-4 text-[#B78628]" strokeWidth={1.75} />
                    </div>
                    <div>
                      <span className="text-xs font-black uppercase tracking-wider text-[#112625] block">
                        El Banco de Minutos
                      </span>
                      <span className="text-[10px] text-[#276160]">
                        Reserva de tiempo no redondeado de meses anteriores
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between py-2 border-y border-black/[0.05]">
                  <div>
                    <span className="text-2xl font-black text-[#112625]">
                      {bankedMinutes}{' '}
                      <span className="text-sm font-bold text-[#B78628]">Minutos Ahorrados</span>
                    </span>
                    <span className="text-[10px] text-[#112625]/60 block">
                      Equivalente a {(bankedMinutes / 60).toFixed(2)} horas listas para sumar
                    </span>
                  </div>
                </div>

                {/* Transfer Button */}
                <button
                  type="button"
                  onClick={handleTransferMinutes}
                  disabled={bankedMinutes === 0}
                  className={`w-full py-3 px-4 rounded-2xl text-xs font-extrabold transition-all flex items-center justify-center gap-2 active:scale-95 shadow-sm cursor-pointer ${
                    bankedMinutes > 0
                      ? 'bg-gradient-to-r from-[#276160] to-[#1A4B4A] text-white hover:opacity-95'
                      : 'bg-black/5 text-[#112625]/40 cursor-not-allowed'
                  }`}
                >
                  <ArrowDownToLine className="w-4 h-4" strokeWidth={2} />
                  <span>
                    {bankedMinutes > 0
                      ? 'Transferir al mes actual (+45m)'
                      : 'Bóveda vacía (Transferido)'}
                  </span>
                </button>

                {/* Celebration feedback toast */}
                <AnimatePresence>
                  {transferCelebration && (
                    <motion.div
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 5 }}
                      className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center justify-center gap-1.5"
                    >
                      <Sparkles className="w-4 h-4 text-emerald-600" />
                      <span>¡45 minutos transferidos exitosamente a tu informe de Octubre!</span>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          )}

          {/* TAB 2: REVISITAS */}
          {subTab === 'revisitas' && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase tracking-wider text-[#276160]">
                  Personas que muestran interés ({revisitas.length})
                </span>
                <button
                  type="button"
                  onClick={() => setShowAddForm(!showAddForm)}
                  className="text-xs font-extrabold text-[#B78628] flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Añadir Revisita</span>
                </button>
              </div>

              {showAddForm && (
                <div className="p-3.5 rounded-2xl bg-white/90 border border-[#EBB634]/40 shadow-sm flex flex-col gap-2">
                  <input
                    type="text"
                    value={newPersonName}
                    onChange={(e) => setNewPersonName(e.target.value)}
                    placeholder="Nombre de la nueva revisita..."
                    className="w-full py-2 px-3 rounded-xl bg-[#FAF7F0] text-xs font-semibold"
                  />
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowAddForm(false)}
                      className="px-3 py-1 rounded-lg text-xs font-bold text-black/60"
                    >
                      Cancelar
                    </button>
                    <button
                      type="button"
                      onClick={handleAddNew}
                      className="px-4 py-1.5 rounded-xl bg-[#276160] text-white text-xs font-bold"
                    >
                      Añadir
                    </button>
                  </div>
                </div>
              )}

              {revisitas.map((rev) => (
                <div
                  key={rev.id}
                  className="p-4 rounded-3xl bg-white/60 border border-white/80 shadow-sm flex flex-col gap-2"
                >
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-extrabold text-[#112625]">{rev.name}</h4>
                    <span className="text-[10px] font-bold text-[#276160] bg-[#276160]/10 px-2.5 py-0.5 rounded-full">
                      {rev.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 text-[11px] text-[#112625]/70">
                    <MapPin className="w-3.5 h-3.5 text-[#B78628] shrink-0" />
                    <span>{rev.address}</span>
                  </div>
                  <p className="text-[11px] text-[#112625]/85 italic">"{rev.topic}"</p>
                  <div className="flex items-center justify-between pt-2 border-t border-black/[0.04] text-[10px] text-[#112625]/60">
                    <span>Última visita: {rev.date}</span>
                    <span className="font-semibold text-[#B78628]">
                      Próxima: {rev.nextVisit}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 3: CURSOS BÍBLICOS */}
          {subTab === 'cursos' && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase tracking-wider text-[#276160]">
                  Cursos de la Biblia Activos ({cursos.length})
                </span>
                <button
                  type="button"
                  onClick={() => setShowAddForm(!showAddForm)}
                  className="text-xs font-extrabold text-[#B78628] flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Añadir Estudiante</span>
                </button>
              </div>

              {showAddForm && (
                <div className="p-3.5 rounded-2xl bg-white/90 border border-[#276160]/40 shadow-sm flex flex-col gap-2">
                  <input
                    type="text"
                    value={newPersonName}
                    onChange={(e) => setNewPersonName(e.target.value)}
                    placeholder="Nombre del nuevo estudiante..."
                    className="w-full py-2 px-3 rounded-xl bg-[#FAF7F0] text-xs font-semibold"
                  />
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowAddForm(false)}
                      className="px-3 py-1 rounded-lg text-xs font-bold text-black/60"
                    >
                      Cancelar
                    </button>
                    <button
                      type="button"
                      onClick={handleAddNew}
                      className="px-4 py-1.5 rounded-xl bg-[#276160] text-white text-xs font-bold"
                    >
                      Añadir
                    </button>
                  </div>
                </div>
              )}

              {cursos.map((c) => (
                <div
                  key={c.id}
                  className="p-4 rounded-3xl bg-white/60 border border-white/80 shadow-sm flex flex-col gap-2"
                >
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-extrabold text-[#112625]">{c.name}</h4>
                    <span className="text-[10px] font-semibold text-[#276160]">{c.day}</span>
                  </div>
                  <div className="text-[11px] font-bold text-[#B78628]">{c.lesson}</div>
                  <p className="text-[11px] text-[#112625]/75 leading-relaxed">{c.notes}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
