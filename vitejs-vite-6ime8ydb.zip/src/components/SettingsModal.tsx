import React from 'react';
import { motion } from 'motion/react';
import { X, Settings, Key, User, Target, Sun, RotateCcw, Check } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  userName: string;
  onUpdateUserName: (name: string) => void;
  monthlyGoal: number;
  onUpdateMonthlyGoal: (goal: number) => void;
  geminiApiKey: string;
  onUpdateGeminiApiKey: (key: string) => void;
  theme: 'light' | 'sunlight' | 'dark';
  onCycleTheme: () => void;
  onReplayBoot: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  userName,
  onUpdateUserName,
  monthlyGoal,
  onUpdateMonthlyGoal,
  geminiApiKey,
  onUpdateGeminiApiKey,
  theme,
  onCycleTheme,
  onReplayBoot,
}) => {
  const [tempName, setTempName] = React.useState(userName);
  const [tempGoal, setTempGoal] = React.useState(monthlyGoal);
  const [tempApiKey, setTempApiKey] = React.useState(geminiApiKey);
  const [savedSuccess, setSavedSuccess] = React.useState(false);

  React.useEffect(() => {
    setTempName(userName);
    setTempGoal(monthlyGoal);
    setTempApiKey(geminiApiKey);
  }, [userName, monthlyGoal, geminiApiKey, isOpen]);

  const handleSave = () => {
    onUpdateUserName(tempName);
    onUpdateMonthlyGoal(tempGoal);
    onUpdateGeminiApiKey(tempApiKey);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 900);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/45 backdrop-blur-md overflow-hidden">
      <motion.div
        initial={{ opacity: 0, y: 35, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 25, scale: 0.98 }}
        transition={{ type: 'spring', damping: 25, stiffness: 280 }}
        className="w-full h-full sm:h-auto sm:max-w-md bg-[#FAF7F0]/95 backdrop-blur-3xl sm:rounded-[36px] flex flex-col shadow-2xl border border-white overflow-hidden relative"
      >
        {/* Header */}
        <div className="p-4 border-b border-black/[0.06] bg-white/70 backdrop-blur-xl flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#276160]/10 flex items-center justify-center">
              <Settings className="w-4 h-4 text-[#276160]" strokeWidth={1.75} />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-[#112625] uppercase tracking-wider">
                Ajustes y Preferencias
              </h3>
              <span className="text-[11px] font-medium text-[#276160]">
                Estudiario Teocrático
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-black/5 hover:bg-black/10 flex items-center justify-center text-[#112625] active:scale-95 transition-transform"
          >
            <X className="w-4 h-4" strokeWidth={1.75} />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex flex-col gap-4 overflow-y-auto">
          {/* User Name */}
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold uppercase tracking-wider text-[#112625]/70 flex items-center gap-1">
              <User className="w-3.5 h-3.5 text-[#276160]" />
              <span>Nombre de usuario</span>
            </label>
            <input
              type="text"
              value={tempName}
              onChange={(e) => setTempName(e.target.value)}
              placeholder="Gabriel Sequea"
              className="w-full py-2 px-3 rounded-xl bg-white border border-[#EBB634]/35 text-xs font-bold text-[#112625] focus:outline-none"
            />
          </div>

          {/* Monthly Goal */}
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold uppercase tracking-wider text-[#112625]/70 flex items-center gap-1">
              <Target className="w-3.5 h-3.5 text-[#276160]" />
              <span>Meta mensual de horas</span>
            </label>
            <input
              type="number"
              min="1"
              max="200"
              value={tempGoal}
              onChange={(e) => setTempGoal(parseInt(e.target.value, 10) || 50)}
              className="w-full py-2 px-3 rounded-xl bg-white border border-[#EBB634]/35 text-xs font-bold text-[#112625] focus:outline-none"
            />
          </div>

          {/* Gemini API Key */}
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold uppercase tracking-wider text-[#112625]/70 flex items-center gap-1">
              <Key className="w-3.5 h-3.5 text-[#276160]" />
              <span>Gemini API Key (Opcional para Asistente wol.jw.org)</span>
            </label>
            <input
              type="password"
              value={tempApiKey}
              onChange={(e) => setTempApiKey(e.target.value)}
              placeholder="Ingresa tu clave de Google Gemini..."
              className="w-full py-2 px-3 rounded-xl bg-white border border-[#EBB634]/35 text-xs text-[#112625] focus:outline-none"
            />
          </div>

          {/* Theme switch */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-white/70 border border-black/[0.05]">
            <div className="flex items-center gap-2">
              <Sun className="w-4 h-4 text-[#D49B27]" />
              <div>
                <span className="text-xs font-bold text-[#112625] block leading-tight">
                  Tema Visual
                </span>
                <span className="text-[10px] text-[#276160] capitalize">
                  {theme === 'light' ? 'Luz Natural (Alabastro Cálido)' : theme === 'sunlight' ? 'Luz Solar Alto Contraste' : 'Modo Noche'}
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={onCycleTheme}
              className="px-3 py-1.5 rounded-xl bg-[#276160]/10 text-xs font-bold text-[#276160] active:scale-95"
            >
              Cambiar
            </button>
          </div>

          {/* Replay Boot Animation */}
          <button
            type="button"
            onClick={() => {
              onClose();
              onReplayBoot();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-white/90 border border-[#EBB634]/40 text-xs font-bold text-[#B78628] flex items-center justify-center gap-2 active:scale-95 transition-transform"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Repetir Animación de Inicio</span>
          </button>

          {/* Save Button */}
          <button
            type="button"
            onClick={handleSave}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#EBB634] to-[#B78628] text-white text-xs font-extrabold shadow-md flex items-center justify-center gap-1.5 active:scale-95 transition-transform cursor-pointer"
          >
            {savedSuccess ? <Check className="w-4 h-4" /> : null}
            <span>{savedSuccess ? '¡Ajustes Guardados!' : 'Guardar Ajustes'}</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
};
