import React from 'react';
import { motion } from 'motion/react';
import { Sun, Sparkles, Send, Calendar, Moon } from 'lucide-react';
import { EstudiarioLogo } from './EstudiarioLogo';

interface HeaderProps {
  userName?: string;
  theme: 'light' | 'sunlight' | 'dark';
  onCycleTheme: () => void;
  onOpenAiAssistant: () => void;
  onOpenServiceReport: () => void;
  onOpenCalendar: () => void;
  onToggleWidget: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  userName = 'Gabriel',
  theme,
  onCycleTheme,
  onOpenAiAssistant,
  onOpenServiceReport,
  onOpenCalendar,
  onToggleWidget,
}) => {
  return (
    <header className="w-full flex flex-col pt-1">
      {/* ROW 1 — Top Utility Bar (Pinned to the Upper Right) */}
      <div className="flex items-center justify-end gap-2.5 w-full pt-1">
        <span className="text-xs font-semibold tracking-wider text-[#276160] dark:text-[#A7C7C6] mr-1 select-none">
          Viernes 16/10
        </span>

        {/* 4 circular glass buttons */}
        <button
          type="button"
          onClick={onCycleTheme}
          aria-label="Cambiar tema de luz"
          title={`Tema actual: ${theme}`}
          className="w-9 h-9 rounded-full bg-white/70 dark:bg-white/15 backdrop-blur-xl border border-white/80 dark:border-white/20 shadow-[0_4px_14px_rgba(235,182,52,0.2)] flex items-center justify-center active:scale-95 transition-transform cursor-pointer"
        >
          {theme === 'dark' ? (
            <Moon className="w-4 h-4 text-[#EBB634]" strokeWidth={1.75} />
          ) : (
            <Sun className="w-4 h-4 text-[#D49B27]" strokeWidth={1.75} />
          )}
        </button>

        <button
          type="button"
          onClick={onOpenAiAssistant}
          aria-label="Abrir Asistente Teocrático IA"
          title="Asistente Teocrático IA"
          className="w-9 h-9 rounded-full bg-white/70 dark:bg-white/15 backdrop-blur-xl border border-white/80 dark:border-white/20 shadow-[0_4px_14px_rgba(235,182,52,0.2)] flex items-center justify-center active:scale-95 transition-transform cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-[#D49B27] dark:text-[#EBB634]" strokeWidth={1.75} />
        </button>

        <button
          type="button"
          onClick={onOpenServiceReport}
          aria-label="Abrir Informe Mensual de Servicio"
          title="Informe Mensual de Servicio"
          className="w-9 h-9 rounded-full bg-white/70 dark:bg-white/15 backdrop-blur-xl border border-white/80 dark:border-white/20 shadow-[0_4px_14px_rgba(235,182,52,0.2)] flex items-center justify-center active:scale-95 transition-transform cursor-pointer"
        >
          <Send className="w-4 h-4 text-[#276160] dark:text-[#A7C7C6]" strokeWidth={1.75} />
        </button>

        <button
          type="button"
          onClick={onOpenCalendar}
          aria-label="Abrir Calendario y Asignaciones"
          title="Calendario y Asignaciones"
          className="w-9 h-9 rounded-full bg-white/70 dark:bg-white/15 backdrop-blur-xl border border-white/80 dark:border-white/20 shadow-[0_4px_14px_rgba(235,182,52,0.2)] flex items-center justify-center active:scale-95 transition-transform cursor-pointer"
        >
          <Calendar className="w-4 h-4 text-[#276160] dark:text-[#A7C7C6]" strokeWidth={1.75} />
        </button>
      </div>

      {/* ROW 2 — Free-Floating Logo + Unbroken Greeting */}
      <div className="flex items-center gap-4 w-full mt-1">
        <motion.div
          layoutId="brand-emblem"
          transition={{ type: "spring", stiffness: 200, damping: 25, mass: 0.8 }}
          onClick={onToggleWidget}
          title="Toca para desplegar herramientas"
          className="shrink-0 cursor-pointer active:scale-95 transition-transform"
        >
          <EstudiarioLogo className="w-16 h-16 drop-shadow-[0_6px_16px_rgba(235,182,52,0.35)]" />
        </motion.div>
        <h1 className="text-[32px] font-extrabold tracking-tight text-[#112625] dark:text-[#F6F4EE] whitespace-nowrap leading-none select-none">
          Hola, {userName}
        </h1>
      </div>

      {/* ROW 3 — Single Horizontal Lead-In Right Above the Bible Card */}
      <p className="text-sm font-semibold text-[#276160] dark:text-[#A7C7C6] tracking-tight pl-1 -mb-5 select-none mt-2">
        revisemos tu progreso
      </p>
    </header>
  );
};
