import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  RefreshCcw,
  BookOpen,
  MapPin,
  Calendar,
  ArrowRightCircle,
  Share2,
  Pin,
  CheckCircle2,
  Check,
  Plus,
  Minus,
  Sparkles,
  Clock,
} from 'lucide-react';

interface RevisitaItem {
  id: string;
  name: string;
  address: string;
  pendingTopic: string;
  lastScripture: string;
  preferredTime: string;
  notes?: string;
}

interface CursoItem {
  id: string;
  name: string;
  publication: string;
  lessonNumber: number;
  totalLessons: number;
  currentParagraph: number;
  nextSchedule: string;
  companionNote: string;
  pinnedIdea?: {
    id: string;
    scripture: string;
    note: string;
  };
}

interface MentorshipStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'revisitas' | 'cursos';
  onAddHours: (hours: number) => void;
  onUpdateStats?: (revisitasCount: number, cursosCount: number) => void;
  studentPins?: Record<string, { scripture: string; note: string }[]>;
}

export const MentorshipStudioModal: React.FC<MentorshipStudioModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'revisitas',
  onAddHours,
  onUpdateStats,
  studentPins,
}) => {
  const [activeTab, setActiveTab] = useState<'revisitas' | 'cursos'>(initialTab);

  // Sync initialTab when opened
  React.useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  // Revisitas Pipeline State
  const [revisitas, setRevisitas] = useState<RevisitaItem[]>([
    {
      id: 'rev-1',
      name: 'Luis',
      address: 'Calle Los Pinos #14, Apto 2B',
      pendingTopic: '¿Qué propósito tiene Dios para la Tierra?',
      lastScripture: 'Salmo 37:29',
      preferredTime: 'Mejor día: Sábados PM',
      notes: 'Mostró interés en folleto Buenas Noticias. Familia receptiva.',
    },
    {
      id: 'rev-2',
      name: 'Alberto',
      address: 'Av. Libertador, Edif. Manantial 4A',
      pendingTopic: '¿Por qué permite Dios el sufrimiento humano?',
      lastScripture: '2 Corintios 1:3, 4',
      preferredTime: 'Mejor día: Domingos después de reunión',
      notes: 'Su tío falleció recientemente. Agradeció las palabras de consuelo.',
    },
  ]);

  // Cursos Bíblicos State
  const [cursos, setCursos] = useState<CursoItem[]>([
    {
      id: 'cur-1',
      name: 'Josué',
      publication: '¡Disfrute de la vida para siempre!',
      lessonNumber: 12,
      totalLessons: 60,
      currentParagraph: 6,
      nextSchedule: 'Jueves, 4:00 PM',
      companionNote:
        'Lección 12: ¿Cómo orar a Dios? Salmo 65:2 y la importancia de orar con sinceridad.',
      pinnedIdea: {
        id: 'pin-1',
        scripture: 'Santiago 1:13',
        note: 'Usar para la introducción hoy: Dios nunca nos pone a prueba con cosas malas.',
      },
    },
    {
      id: 'cur-2',
      name: 'Carlos',
      publication: '¡Disfrute de la vida para siempre!',
      lessonNumber: 9,
      totalLessons: 60,
      currentParagraph: 4,
      nextSchedule: 'Viernes, 6:00 PM',
      companionNote:
        'Lección 09: ¿Quién es Jesús? Enfoque en Juan 3:16 y el rescate.',
      pinnedIdea: {
        id: 'pin-2',
        scripture: 'Juan 17:3',
        note: 'Repasar la vida eterna conociendo al Dios verdadero.',
      },
    },
    {
      id: 'cur-3',
      name: 'Andrés',
      publication: '¡Disfrute de la vida para siempre!',
      lessonNumber: 22,
      totalLessons: 60,
      currentParagraph: 8,
      nextSchedule: 'Sábado, 4:00 PM',
      companionNote:
        'Lección 22: El bautismo cristiano. Hablar sobre la dedicación personal.',
      pinnedIdea: {
        id: 'pin-3',
        scripture: 'Mateo 28:19',
        note: 'Destacar hacer discípulos y el simbolismo del agua.',
      },
    },
    {
      id: 'cur-4',
      name: 'Mateo',
      publication: '¡Disfrute de la vida para siempre!',
      lessonNumber: 4,
      totalLessons: 60,
      currentParagraph: 5,
      nextSchedule: 'Lunes, 5:30 PM',
      companionNote:
        'Lección 04: ¿Quién es el autor de la Biblia? 2 Timoteo 3:16.',
    },
  ]);

  // Promotion Notification & Action Toast
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  // Companion Mode Share Modal / Feedback
  const [companionShareCopied, setCompanionShareCopied] = useState<string | null>(null);

  // 3-Tap Wrap-Up Sheet State (Finalizar Clase)
  const [selectedStudentForWrapUp, setSelectedStudentForWrapUp] = useState<CursoItem | null>(null);
  const [wrapUpDurationMinutes, setWrapUpDurationMinutes] = useState(60); // default 1h
  const [wrapUpNextParagraph, setWrapUpNextParagraph] = useState(7);
  const [wrapUpNextSchedule, setWrapUpNextSchedule] = useState('Jueves, 4:00 PM');
  const [wrapUpSuccessNotice, setWrapUpSuccessNotice] = useState(false);

  // Promote Revisita to Curso
  const handlePromoteToCurso = (revisita: RevisitaItem) => {
    setRevisitas((prev) => prev.filter((r) => r.id !== revisita.id));

    const newCurso: CursoItem = {
      id: `cur-${Date.now()}`,
      name: revisita.name,
      publication: '¡Disfrute de la vida para siempre!',
      lessonNumber: 1,
      totalLessons: 60,
      currentParagraph: 1,
      nextSchedule: revisita.preferredTime || 'Próxima semana',
      companionNote: `Nuevo curso iniciado con ${revisita.name}. Último tema visto: ${revisita.pendingTopic}.`,
      pinnedIdea: {
        id: `pin-${Date.now()}`,
        scripture: revisita.lastScripture,
        note: 'Texto clave de la última visita para repasar en la primera lección.',
      },
    };

    setCursos((prev) => [newCurso, ...prev]);

    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate(50);
    }

    setActionNotice(`${revisita.name} ha sido promovido exitosamente a Curso Bíblico.`);
    onUpdateStats?.(revisitas.length - 1, cursos.length + 1);

    setTimeout(() => {
      setActiveTab('cursos');
      setActionNotice(null);
    }, 1500);
  };

  // Companion Mode (WhatsApp Summary generator)
  const handleShareCompanionMode = (student: CursoItem) => {
    const text = `¡Hola hermano! Te comparto los detalles para acompañarme al curso con ${student.name}:
Publicación: ${student.publication}
Lección actual: Lección ${student.lessonNumber}, Párrafo ${student.currentParagraph}
Próxima cita: ${student.nextSchedule}
Nota de preparación: "${student.companionNote}"
${student.pinnedIdea ? `Idea clave: ${student.pinnedIdea.scripture} - ${student.pinnedIdea.note}` : ''}`;

    if (navigator?.clipboard) {
      navigator.clipboard.writeText(text);
    }
    setCompanionShareCopied(student.id);
    setTimeout(() => setCompanionShareCopied(null), 2500);
  };

  // Open 3-Tap Wrap-Up Sheet
  const handleOpenWrapUp = (student: CursoItem) => {
    setSelectedStudentForWrapUp(student);
    setWrapUpDurationMinutes(60); // 1h 00m
    setWrapUpNextParagraph(student.currentParagraph + 1);
    setWrapUpNextSchedule(student.nextSchedule || 'Jueves, 4:00 PM');
  };

  // Confirm Wrap-Up & Add hours to Dashboard
  const handleConfirmWrapUp = () => {
    if (!selectedStudentForWrapUp) return;

    const hoursFraction = parseFloat((wrapUpDurationMinutes / 60).toFixed(2));
    onAddHours(hoursFraction);

    setCursos((prev) =>
      prev.map((c) =>
        c.id === selectedStudentForWrapUp.id
          ? {
              ...c,
              currentParagraph: wrapUpNextParagraph,
              nextSchedule: wrapUpNextSchedule,
            }
          : c
      )
    );

    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate(60);
    }

    setWrapUpSuccessNotice(true);
    setTimeout(() => {
      setWrapUpSuccessNotice(false);
      setSelectedStudentForWrapUp(null);
    }, 1200);
  };

  const formatDuration = (mins: number) => {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return `${h}h ${String(m).padStart(2, '0')}m`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Translucent Backdrop letting background waves shine */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/20 backdrop-blur-xs"
      />

      {/* Full-Screen Pure Glass Modal Sliding Up From Bottom */}
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 28, stiffness: 300 }}
        className="fixed inset-0 z-50 bg-[#FAF7F0]/80 dark:bg-[#0B1716]/90 backdrop-blur-3xl overflow-y-auto px-5 py-8 flex flex-col justify-start"
      >
        <div className="w-full max-w-md mx-auto flex flex-col gap-6">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-black/[0.06] dark:border-white/10 pb-3">
            <div>
              <h2 className="text-sm font-extrabold text-[#112625] dark:text-[#F6F4EE] uppercase tracking-wider">
                ESTUDIO DE MENTORÍA
              </h2>
              <span className="text-[11px] font-medium text-[#276160] dark:text-[#A7C7C6]">
                Canalización de Revisitas y Cursos Bíblicos
              </span>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="Cerrar modal"
              className="w-9 h-9 rounded-full bg-white/40 dark:bg-white/10 backdrop-blur-xl border border-white/90 dark:border-white/20 shadow-[0_4px_15px_rgba(235,182,52,0.15)] flex items-center justify-center text-[#112625] dark:text-[#F6F4EE] active:scale-95 transition-transform cursor-pointer"
            >
              <X className="w-4 h-4" strokeWidth={1.75} />
            </button>
          </div>

          {/* Top Segmented Control (NO SOLID BUTTONS: Backlit Glass Only, Zero Emojis) */}
          <div className="p-1 rounded-2xl bg-white/40 backdrop-blur-2xl border border-white/80 shadow-[0_4px_20px_rgba(235,182,52,0.15)] flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setActiveTab('revisitas')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === 'revisitas'
                  ? 'bg-white/60 backdrop-blur-xl border border-white/90 shadow-[0_4px_15px_rgba(235,182,52,0.25)] text-[#122B2A]'
                  : 'text-[#122B2A]/70 hover:bg-white/20'
              }`}
            >
              <RefreshCcw className="w-3.5 h-3.5 text-[#B78628]" strokeWidth={1.75} />
              <span>Revisitas ({revisitas.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('cursos')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === 'cursos'
                  ? 'bg-white/60 backdrop-blur-xl border border-white/90 shadow-[0_4px_15px_rgba(39,97,96,0.25)] text-[#122B2A]'
                  : 'text-[#122B2A]/70 hover:bg-white/20'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 text-[#276160]" strokeWidth={1.75} />
              <span>Cursos Bíblicos ({cursos.length})</span>
            </button>
          </div>

          {/* Action Notification Toast */}
          <AnimatePresence>
            {actionNotice && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="p-3 rounded-2xl bg-white/70 backdrop-blur-xl border border-emerald-300 text-emerald-900 text-xs font-bold flex items-center gap-2 shadow-sm"
              >
                <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{actionNotice}</span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* ========================================================
              TAB A: REVISITAS PIPELINE
              ======================================================== */}
          {activeTab === 'revisitas' && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-extrabold uppercase tracking-wider text-[#276160]">
                  Personas en Proceso de Cultivo ({revisitas.length})
                </span>
                <span className="text-[11px] font-medium text-[#112625]/60">
                  Canal de Conversión a Cursos
                </span>
              </div>

              {revisitas.length === 0 ? (
                <div className="p-8 rounded-3xl bg-white/40 backdrop-blur-2xl border border-white/80 text-center flex flex-col items-center gap-2">
                  <RefreshCcw className="w-8 h-8 text-[#276160]/40" />
                  <p className="text-xs font-semibold text-[#112625]/70">
                    No tienes revisitas pendientes.
                  </p>
                </div>
              ) : (
                revisitas.map((rev) => (
                  <motion.div
                    key={rev.id}
                    layout
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="bg-white/60 backdrop-blur-2xl border border-white/90 p-5 rounded-3xl shadow-[0_8px_25px_rgba(235,182,52,0.12)] flex flex-col gap-3.5 hover:bg-white/75 transition-all"
                  >
                    {/* Header: Name & MapPin button */}
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-bold text-[#112625] leading-none">
                        {rev.name}
                      </h3>
                      <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-white/40 border border-white/60 text-[11px] text-[#276160] font-medium">
                        <MapPin className="w-3.5 h-3.5 text-[#B78628] shrink-0" strokeWidth={1.75} />
                        <span className="truncate max-w-[160px]">{rev.address}</span>
                      </div>
                    </div>

                    {/* Data Grid (2 columns) */}
                    <div className="grid grid-cols-2 gap-3 p-3 rounded-2xl bg-white/40 border border-white/70">
                      <div className="flex flex-col gap-0.5">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-[#276160]">
                          Tema Pendiente:
                        </span>
                        <p className="text-xs font-semibold text-[#112625] leading-snug line-clamp-2">
                          "{rev.pendingTopic}"
                        </p>
                      </div>

                      <div className="flex flex-col gap-0.5 border-l border-black/[0.06] pl-3">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-[#276160]">
                          Último texto leído:
                        </span>
                        <p className="text-xs font-extrabold text-[#B78628] leading-snug">
                          {rev.lastScripture}
                        </p>
                      </div>
                    </div>

                    {/* Action Row (Bottom) */}
                    <div className="flex items-center justify-between pt-1">
                      {/* Subtle Calendar chip */}
                      <div className="flex items-center gap-1.5 text-[11px] font-medium text-[#112625]/75">
                        <Calendar className="w-3.5 h-3.5 text-[#276160]" strokeWidth={1.75} />
                        <span>{rev.preferredTime}</span>
                      </div>

                      {/* NO SOLID BUTTON: Backlit Glass <ArrowRightCircle /> Promover a Curso */}
                      <button
                        type="button"
                        onClick={() => handlePromoteToCurso(rev)}
                        className="py-2 px-3.5 rounded-2xl bg-white/20 backdrop-blur-xl border border-white/80 shadow-[0_4px_15px_rgba(235,182,52,0.2)] text-[#122B2A] text-xs font-extrabold flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer hover:bg-white/40"
                      >
                        <ArrowRightCircle className="w-4 h-4 text-[#276160]" strokeWidth={1.75} />
                        <span>Promover a Curso</span>
                      </button>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          )}

          {/* ========================================================
              TAB B: CURSOS BÍBLICOS (STUDENT PROFILES)
              ======================================================== */}
          {activeTab === 'cursos' && (
            <div className="flex flex-col gap-5">
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-extrabold uppercase tracking-wider text-[#276160]">
                  Estudiantes Activos ({cursos.length})
                </span>
                <span className="text-[11px] font-medium text-[#112625]/60">
                  Progreso Sistemático
                </span>
              </div>

              {cursos.map((student) => {
                const completionPercent = Math.round(
                  (student.lessonNumber / student.totalLessons) * 100
                );

                return (
                  <motion.div
                    key={student.id}
                    layout
                    className="bg-white/60 backdrop-blur-2xl border border-white/90 p-5 rounded-3xl shadow-[0_8px_25px_rgba(235,182,52,0.12)] flex flex-col gap-4 hover:bg-white/75 transition-all"
                  >
                    {/* Header: Name and <Share2 /> Modo Acompañante */}
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-bold text-[#112625] leading-none">
                          {student.name}
                        </h3>
                        <span className="text-[10px] text-[#276160] font-medium mt-1 block">
                          Cita: {student.nextSchedule}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleShareCompanionMode(student)}
                        className={`text-xs font-bold px-3 py-1.5 rounded-xl border transition-all flex items-center gap-1.5 cursor-pointer shadow-xs ${
                          companionShareCopied === student.id
                            ? 'bg-emerald-50/80 border-emerald-300 text-emerald-800'
                            : 'bg-white/40 backdrop-blur-xl border-white/80 text-[#966708] hover:bg-white/60 shadow-[0_2px_10px_rgba(235,182,52,0.15)]'
                        }`}
                      >
                        {companionShareCopied === student.id ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600" strokeWidth={2} />
                            <span>¡Copiado para WhatsApp!</span>
                          </>
                        ) : (
                          <>
                            <Share2 className="w-3.5 h-3.5 text-[#B78628]" strokeWidth={1.75} />
                            <span>Modo Acompañante</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Progress Tracker */}
                    <div className="p-3.5 rounded-2xl bg-white/40 border border-white/70 flex flex-col gap-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-[#112625]">
                          {student.publication} • Lección {student.lessonNumber}
                        </span>
                        <span className="text-[10px] font-extrabold text-[#276160]">
                          {completionPercent}%
                        </span>
                      </div>

                      {/* Subtext */}
                      <span className="text-[11px] font-semibold text-[#B78628]">
                        Párrafo {student.currentParagraph}
                      </span>

                      {/* Sleek Glowing Progress Bar */}
                      <div className="w-full h-2.5 rounded-full bg-[#E8E4DA]/70 overflow-hidden relative">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${completionPercent}%` }}
                          transition={{ duration: 0.9, ease: 'easeOut' }}
                          className="h-full rounded-full bg-gradient-to-r from-[#EBB634] to-[#276160] shadow-[0_0_8px_rgba(235,182,52,0.4)]"
                        />
                      </div>
                    </div>

                    {/* Bandeja de Pines (Widget Pins) - STRICT ZERO EMOJIS */}
                    {(() => {
                      const dynamicPins = studentPins && studentPins[student.name];
                      const pinsToRender =
                        dynamicPins && dynamicPins.length > 0
                          ? dynamicPins
                          : student.pinnedIdea
                          ? [student.pinnedIdea]
                          : [];

                      return pinsToRender.map((pin, pIdx) => (
                        <div
                          key={pIdx}
                          className="bg-[#EBB634]/10 dark:bg-[#EBB634]/15 backdrop-blur-xl rounded-2xl p-3 border border-[#EBB634]/25 flex flex-col gap-1"
                        >
                          <div className="flex items-center gap-1.5 text-xs font-bold text-[#966708] dark:text-[#EBB634]">
                            <Pin className="w-4 h-4 text-[#B78628] dark:text-[#EBB634] shrink-0" strokeWidth={1.75} />
                            <span>Texto Guardado: {pin.scripture}</span>
                          </div>
                          <p className="text-[11px] text-[#112625]/80 dark:text-[#F6F4EE]/85 pl-5 leading-relaxed">
                            {pin.note}
                          </p>
                        </div>
                      ));
                    })()}

                    {/* NO SOLID BUTTON: Backlit Glass <CheckCircle2 /> Finalizar Clase de Hoy */}
                    <button
                      type="button"
                      onClick={() => handleOpenWrapUp(student)}
                      className="w-full py-3.5 px-4 rounded-2xl bg-white/20 backdrop-blur-xl border border-white/80 shadow-[0_4px_15px_rgba(235,182,52,0.2)] text-[#122B2A] text-xs font-black flex items-center justify-center gap-2 active:scale-98 transition-all cursor-pointer hover:bg-white/40"
                    >
                      <CheckCircle2 className="w-4 h-4 text-[#276160]" strokeWidth={1.75} />
                      <span>Finalizar Clase de Hoy</span>
                    </button>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </motion.div>

      {/* ========================================================
          4. THE 3-TAP WRAP-UP SHEET (FINALIZAR CLASE)
          Slide up compact glass confirmation sheet
          ======================================================== */}
      <AnimatePresence>
        {selectedStudentForWrapUp && (
          <div className="fixed inset-0 z-[60] flex items-end justify-center pointer-events-auto">
            {/* Sheet backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedStudentForWrapUp(null)}
              className="fixed inset-0 bg-black/25 backdrop-blur-xs"
            />

            {/* Sliding sheet */}
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 26, stiffness: 280 }}
              className="relative w-full max-w-md bg-white/85 backdrop-blur-3xl rounded-t-[40px] p-6 shadow-[0_-20px_40px_rgba(235,182,52,0.18)] z-[60] flex flex-col gap-5 border-t border-white"
            >
              {/* Sheet handle & title */}
              <div className="flex flex-col items-center gap-1.5 pb-1 border-b border-black/[0.05]">
                <div className="w-12 h-1 rounded-full bg-black/20" />
                <div className="flex items-center justify-between w-full pt-1">
                  <h3 className="text-sm font-extrabold text-[#112625] uppercase tracking-wider">
                    Finalizar Clase con {selectedStudentForWrapUp.name}
                  </h3>
                  <button
                    type="button"
                    onClick={() => setSelectedStudentForWrapUp(null)}
                    className="p-1 rounded-full text-black/40 hover:text-black cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* 3 Quick Inputs */}
              <div className="flex flex-col gap-3">
                {/* 1. Duración: [ - ] 1h 00m [ + ] */}
                <div className="flex items-center justify-between p-3.5 rounded-2xl bg-white/60 border border-white/80 shadow-xs">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-[#B78628]" strokeWidth={1.75} />
                    <span className="text-xs font-bold text-[#112625]">Duración</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setWrapUpDurationMinutes((m) => Math.max(15, m - 15))}
                      className="w-8 h-8 rounded-full bg-white/80 border border-white/90 shadow-xs flex items-center justify-center text-[#112625] active:scale-95 cursor-pointer"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>

                    <span className="text-xs font-extrabold text-[#112625] w-16 text-center">
                      {formatDuration(wrapUpDurationMinutes)}
                    </span>

                    <button
                      type="button"
                      onClick={() => setWrapUpDurationMinutes((m) => Math.min(240, m + 15))}
                      className="w-8 h-8 rounded-full bg-white/80 border border-white/90 shadow-xs flex items-center justify-center text-[#112625] active:scale-95 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* 2. Próximo Párrafo: [ - ] Párrafo 7 [ + ] */}
                <div className="flex items-center justify-between p-3.5 rounded-2xl bg-white/60 border border-white/80 shadow-xs">
                  <div className="flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-[#276160]" strokeWidth={1.75} />
                    <span className="text-xs font-bold text-[#112625]">Próximo Párrafo</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setWrapUpNextParagraph((p) => Math.max(1, p - 1))}
                      className="w-8 h-8 rounded-full bg-white/80 border border-white/90 shadow-xs flex items-center justify-center text-[#112625] active:scale-95 cursor-pointer"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>

                    <span className="text-xs font-extrabold text-[#276160] w-20 text-center">
                      Párrafo {wrapUpNextParagraph}
                    </span>

                    <button
                      type="button"
                      onClick={() => setWrapUpNextParagraph((p) => p + 1)}
                      className="w-8 h-8 rounded-full bg-white/80 border border-white/90 shadow-xs flex items-center justify-center text-[#112625] active:scale-95 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* 3. Próxima Cita: <Calendar /> Jueves, 4:00 PM */}
                <div className="flex items-center justify-between p-3.5 rounded-2xl bg-white/60 border border-white/80 shadow-xs">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-[#B78628]" strokeWidth={1.75} />
                    <span className="text-xs font-bold text-[#112625]">Próxima Cita</span>
                  </div>

                  <input
                    type="text"
                    value={wrapUpNextSchedule}
                    onChange={(e) => setWrapUpNextSchedule(e.target.value)}
                    className="py-1 px-3 rounded-xl bg-white/80 border border-white/90 text-xs font-semibold text-[#112625] text-right focus:outline-none"
                  />
                </div>
              </div>

              {/* NO SOLID BUTTON: Backlit Glass Confirmation Button */}
              <button
                type="button"
                onClick={handleConfirmWrapUp}
                className="w-full py-3.5 rounded-2xl bg-white/20 backdrop-blur-xl border border-white/80 shadow-[0_4px_15px_rgba(235,182,52,0.2)] text-[#122B2A] text-xs font-black flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer hover:bg-white/40"
              >
                <Check className="w-4 h-4 text-[#276160]" strokeWidth={2.5} />
                <span>Guardar y Sumar al Informe (+{formatDuration(wrapUpDurationMinutes)})</span>
              </button>

              {/* Success celebration indicator */}
              <AnimatePresence>
                {wrapUpSuccessNotice && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 5 }}
                    className="p-2.5 rounded-xl bg-white/80 backdrop-blur-xl border border-emerald-300 text-emerald-900 text-xs font-bold flex items-center justify-center gap-1.5"
                  >
                    <Sparkles className="w-4 h-4 text-emerald-600" />
                    <span>¡Tiempo registrado y sumado al tablero de 30 hrs!</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
