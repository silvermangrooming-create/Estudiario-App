import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Search,
  Plus,
  Target,
  Sparkles,
  MapPin,
  ExternalLink,
  Bold,
  Underline,
  BookOpen,
  Trash2,
  Check,
  Calendar,
  User,
  Users,
} from 'lucide-react';
import {
  type NoteItem,
  CATEGORY_PALETTE,
  SEMANTIC_HIGHLIGHTERS,
} from '../data/notesData';
import {
  normalizeConcept,
  parseScriptureReferences,
} from '../data/canonicalBible';

interface LibraryStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  notes: NoteItem[];
  onSaveNote: (note: NoteItem) => void;
  onDeleteNote: (id: string) => void;
  selectedNoteInitial?: NoteItem | null;
  startInSearchMode?: boolean;
}

export const LibraryStudioModal: React.FC<LibraryStudioModalProps> = ({
  isOpen,
  onClose,
  notes,
  onSaveNote,
  onDeleteNote,
  selectedNoteInitial = null,
  startInSearchMode = false,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'notes' | 'editor'>('notes');
  const [activeHighlighterTooltip, setActiveHighlighterTooltip] = useState<
    string | null
  >(null);

  // FASE 6: Corrección definitiva de acentos y red de seguridad anticaídas
  const [editingNote, setEditingNote] = useState<Partial<NoteItem>>({
    id: '',
    title: '',
    category: 'Discurso Público',
    categoryColor: CATEGORY_PALETTE['Discurso Público']?.color || '#EAB63E',
    speaker: '',
    congregation: '',
    location: '',
    songNumber: '',
    eventNameDetail: '',
    date: new Date().toLocaleDateString('es-ES', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }),
    content: '',
    scriptures: [],
    keywords: [],
  });

  const [saveSuccessNotice, setSaveSuccessNotice] = useState(false);

  React.useEffect(() => {
    if (selectedNoteInitial) {
      setEditingNote(selectedNoteInitial);
      setActiveTab('editor');
    } else if (startInSearchMode) {
      setActiveTab('notes');
    }
  }, [selectedNoteInitial, startInSearchMode]);

  const { exactMatches, possibleMatches } = useMemo(() => {
    if (!searchQuery.trim()) {
      return { exactMatches: notes, possibleMatches: [] };
    }
    const normQuery = normalizeConcept(searchQuery);
    const exact: NoteItem[] = [];
    const possible: NoteItem[] = [];

    const synonyms: Record<string, string[]> = {
      'no rendirse': [
        'aguante',
        'perseverancia',
        'isaias 40:31',
        'pruebas',
        'fuerza',
        'desanimo',
      ],
      aguante: [
        'no rendirse',
        'perseverancia',
        'paciencia',
        'fidelidad',
        'job',
      ],
      perseverancia: ['aguante', 'no rendirse', 'carrera', 'paciencia'],
      amor: ['bondad', '1 corintios 13', 'carino', 'hermandad'],
      predicacion: [
        'ministerio',
        'campo',
        'revisitas',
        'cursos',
        'horas',
        'servicio',
      ],
      sufrimiento: ['dolor', 'duelo', 'consuelo', '2 corintios 1', 'lagrimas'],
      esperanza: ['paraiso', 'resurreccion', 'apocalipsis 21', 'futuro'],
      humildad: ['orgullo', 'modestia', 'proverbios 16', 'mansedumbre'],
    };

    const relatedKeywords: string[] = [];
    for (const [conceptKey, synList] of Object.entries(synonyms)) {
      if (normQuery.includes(conceptKey) || conceptKey.includes(normQuery)) {
        relatedKeywords.push(...synList);
      }
    }

    for (const note of notes) {
      const normTitle = normalizeConcept(note.title);
      const normContent = normalizeConcept(note.content);
      const normSpeaker = normalizeConcept(note.speaker || '');
      const normKeywords = note.keywords.map(normalizeConcept);
      const normScriptures = note.scriptures.map(normalizeConcept);

      const isExact =
        normTitle.includes(normQuery) ||
        normContent.includes(normQuery) ||
        normSpeaker.includes(normQuery) ||
        normScriptures.some((s) => s.includes(normQuery)) ||
        normKeywords.some((k) => k === normQuery);

      if (isExact) {
        exact.push(note);
      } else {
        const matchesSynonym =
          relatedKeywords.length > 0 &&
          (normKeywords.some((k) =>
            relatedKeywords.some((rk) => k.includes(rk))
          ) ||
            normContent.split(' ').some((w) => relatedKeywords.includes(w)));
        const partialMatch =
          normQuery.length > 2 &&
          (normTitle.split(' ').some((w) => w.startsWith(normQuery)) ||
            normKeywords.some((k) => k.startsWith(normQuery)));

        if (matchesSynonym || partialMatch) {
          possible.push(note);
        }
      }
    }
    return { exactMatches: exact, possibleMatches: possible };
  }, [notes, searchQuery]);

  const detectedScriptures = useMemo(() => {
    const parsed = parseScriptureReferences(editingNote.content || '');
    if (
      parsed.length === 0 &&
      (!editingNote.content || editingNote.content.length < 5)
    ) {
      return parseScriptureReferences('Santiago 1:13');
    }
    return parsed;
  }, [editingNote.content]);

  const handleCategoryChange = (cat: NoteItem['category']) => {
    const pal = CATEGORY_PALETTE[cat] || CATEGORY_PALETTE['Otro'];
    setEditingNote((prev) => ({
      ...prev,
      category: cat,
      categoryColor: pal.color,
      accentHex: pal.color,
    }));
  };

  const handleAutoGps = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const coords = `${pos.coords.latitude.toFixed(
            4
          )}, ${pos.coords.longitude.toFixed(4)}`;
          setEditingNote((prev) => ({
            ...prev,
            location: `Salón del Reino Central (${coords})`,
          }));
        },
        () => {
          setEditingNote((prev) => ({
            ...prev,
            location: 'Salón del Reino Central, Av. Principal',
          }));
        },
        { timeout: 4000 }
      );
    } else {
      setEditingNote((prev) => ({
        ...prev,
        location: 'Salón del Reino Central',
      }));
    }
  };

  const handleSave = () => {
    if (!editingNote.title?.trim()) return;
    const pal =
      CATEGORY_PALETTE[editingNote.category as NoteItem['category']] ||
      CATEGORY_PALETTE['Otro'];
    const scripList = detectedScriptures.map((m) => m.raw);

    const saved: NoteItem = {
      id: editingNote.id || `note-${Date.now()}`,
      title: editingNote.title.trim(),
      category:
        (editingNote.category as NoteItem['category']) || 'Discurso Público',
      categoryColor: editingNote.categoryColor || pal.color,
      accentHex: editingNote.categoryColor || pal.color,
      speaker: editingNote.speaker?.trim(),
      congregation: editingNote.congregation?.trim(),
      location: editingNote.location?.trim(),
      songNumber: editingNote.songNumber?.trim(),
      eventNameDetail: editingNote.eventNameDetail?.trim(),
      date:
        editingNote.date ||
        new Date().toLocaleDateString('es-ES', {
          day: 'numeric',
          month: 'long',
          year: 'numeric',
        }),
      content: editingNote.content || '',
      scriptures:
        scripList.length > 0
          ? scripList
          : editingNote.scriptures || ['Santiago 1:13'],
      keywords: editingNote.keywords || [
        normalizeConcept(editingNote.title),
        normalizeConcept(editingNote.category || ''),
      ],
    };

    onSaveNote(saved);
    setSaveSuccessNotice(true);
    setTimeout(() => {
      setSaveSuccessNotice(false);
      setActiveTab('notes');
    }, 800);
  };

  const handleNewNote = () => {
    setEditingNote({
      id: `note-${Date.now()}`,
      title: '',
      category: 'Discurso Público',
      categoryColor: CATEGORY_PALETTE['Discurso Público']?.color || '#EAB63E',
      speaker: '',
      congregation: '',
      location: '',
      songNumber: '',
      eventNameDetail: '',
      date: new Date().toLocaleDateString('es-ES', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      }),
      content:
        'Santiago 1:13 nos recuerda que Dios jamás tienta con cosas malas a nadie...',
      scriptures: ['Santiago 1:13'],
      keywords: [],
    });
    setActiveTab('editor');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/20 backdrop-blur-xs"
      />

      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 28, stiffness: 300 }}
        className="fixed inset-0 z-50 bg-[#FAF7F0]/85 backdrop-blur-3xl overflow-y-auto px-5 py-8 flex flex-col justify-start"
      >
        <div className="w-full max-w-md mx-auto flex flex-col gap-6">
          <div className="flex items-center justify-between border-b border-black/[0.06] pb-3">
            <div>
              <h2 className="text-sm font-extrabold text-[#112625] uppercase tracking-wider">
                BIBLIOTECA Y ESTUDIO
              </h2>
              <span className="text-[11px] font-medium text-[#276160]">
                Fichas de Discurso, Asambleas & Notas
              </span>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Cerrar modal"
              className="w-9 h-9 rounded-full bg-white/40 backdrop-blur-xl border border-white/90 shadow-[0_4px_15px_rgba(235,182,52,0.15)] flex items-center justify-center text-[#112625] active:scale-95 transition-transform cursor-pointer"
            >
              <X className="w-4 h-4" strokeWidth={1.75} />
            </button>
          </div>

          <div className="relative">
            <div className="flex items-center gap-2.5 bg-white/60 backdrop-blur-xl rounded-full p-3 border border-white/80 shadow-sm">
              <Search
                className="w-4 h-4 text-[#276160] ml-1 shrink-0"
                strokeWidth={1.75}
              />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar por concepto (ej. no rendirse, amós, amor)..."
                className="w-full bg-transparent text-xs font-semibold text-[#112625] placeholder:text-[#112625]/45 focus:outline-none"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="p-1 text-black/40 hover:text-black mr-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          <div className="p-1 rounded-2xl bg-white/40 backdrop-blur-2xl border border-white/80 shadow-[0_4px_20px_rgba(235,182,52,0.15)] flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setActiveTab('notes')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === 'notes'
                  ? 'bg-white/60 backdrop-blur-xl border border-white/90 shadow-[0_4px_15px_rgba(235,182,52,0.25)] text-[#122B2A]'
                  : 'text-[#122B2A]/70 hover:bg-white/20'
              }`}
            >
              <BookOpen
                className="w-3.5 h-3.5 text-[#276160]"
                strokeWidth={1.75}
              />
              <span>Notas ({notes.length})</span>
            </button>
            <button
              type="button"
              onClick={handleNewNote}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === 'editor' && !editingNote.title
                  ? 'bg-white/60 backdrop-blur-xl border border-white/90 shadow-[0_4px_15px_rgba(235,182,52,0.25)] text-[#122B2A]'
                  : 'text-[#122B2A]/70 hover:bg-white/20'
              }`}
            >
              <Plus className="w-3.5 h-3.5 text-[#B78628]" strokeWidth={1.75} />
              <span>+ Nueva Ficha</span>
            </button>
          </div>

          {activeTab === 'notes' && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-1.5 px-1 text-[11px] font-bold text-[#276160] uppercase tracking-wider">
                <Target
                  className="w-3.5 h-3.5 text-[#276160]"
                  strokeWidth={1.75}
                />
                <span>Coincidencia Exacta ({exactMatches.length})</span>
              </div>

              {exactMatches.length === 0 ? (
                <div className="p-8 rounded-3xl bg-white/40 backdrop-blur-2xl border border-white/80 text-center flex flex-col items-center gap-2">
                  <BookOpen className="w-8 h-8 text-[#276160]/40" />
                  <p className="text-xs font-semibold text-[#112625]/70">
                    No hay coincidencias directas para esta búsqueda.
                  </p>
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  {exactMatches.map((n) => (
                    <motion.div
                      key={n.id}
                      layout
                      onClick={() => {
                        setEditingNote(n);
                        setActiveTab('editor');
                      }}
                      className="p-4 rounded-3xl bg-white/60 backdrop-blur-2xl border border-white/90 shadow-[0_6px_20px_rgba(235,182,52,0.12)] flex flex-col gap-2 hover:bg-white/75 transition-all cursor-pointer active:scale-[0.99]"
                      style={{ borderLeft: `5px solid ${n.categoryColor}` }}
                    >
                      <div className="flex items-center justify-between">
                        <span
                          className="text-[10px] font-bold uppercase tracking-wider"
                          style={{ color: n.categoryColor }}
                        >
                          {n.category}
                        </span>
                        <span className="text-[10px] text-[#112625]/50">
                          {n.date}
                        </span>
                      </div>
                      <h4 className="text-sm font-bold text-[#112625] leading-snug">
                        {n.title}
                      </h4>
                      <p className="text-[11px] text-[#112625]/75 line-clamp-2 leading-relaxed">
                        {n.content}
                      </p>
                      {n.scriptures.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {n.scriptures.slice(0, 3).map((s) => (
                            <span
                              key={s}
                              className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-white/60 border border-white/80 text-[#276160]"
                            >
                              {s}
                            </span>
                          ))}
                        </div>
                      )}
                    </motion.div>
                  ))}
                </div>
              )}

              {searchQuery.trim() && possibleMatches.length > 0 && (
                <div className="flex flex-col gap-3 mt-2">
                  <div className="flex items-center gap-1.5 px-1 text-[11px] font-bold text-[#EAB63E] uppercase tracking-wider">
                    <Sparkles
                      className="w-3.5 h-3.5 text-[#B78628]"
                      strokeWidth={1.75}
                    />
                    <span>
                      Posibles Coincidencias ({possibleMatches.length})
                    </span>
                  </div>
                  <div className="flex flex-col gap-3">
                    {possibleMatches.map((n) => (
                      <motion.div
                        key={n.id}
                        layout
                        onClick={() => {
                          setEditingNote(n);
                          setActiveTab('editor');
                        }}
                        className="p-4 rounded-3xl bg-white/40 backdrop-blur-xl border border-dashed border-[#EBB634]/60 shadow-xs flex flex-col gap-1.5 hover:bg-white/60 transition-all cursor-pointer"
                        style={{ borderLeft: `4px solid ${n.categoryColor}` }}
                      >
                        <div className="flex items-center justify-between">
                          <span
                            className="text-[10px] font-bold uppercase tracking-wider"
                            style={{ color: n.categoryColor }}
                          >
                            {n.category}
                          </span>
                          <span className="text-[10px] text-[#112625]/50">
                            {n.date}
                          </span>
                        </div>
                        <h4 className="text-xs font-bold text-[#112625] leading-snug">
                          {n.title}
                        </h4>
                        <p className="text-[11px] text-[#112625]/70 line-clamp-2">
                          {n.content}
                        </p>
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'editor' && (
            <div className="flex flex-col gap-5">
              <div
                className="p-5 rounded-3xl bg-white/60 backdrop-blur-2xl border transition-colors duration-500 shadow-[0_6px_25px_rgba(235,182,52,0.15)] flex flex-col gap-4 relative overflow-hidden"
                style={{
                  borderColor: `${editingNote.categoryColor || '#276160'}60`,
                }}
              >
                <div
                  className="absolute -top-10 -right-10 w-40 h-40 rounded-full blur-2xl opacity-20 pointer-events-none -z-10"
                  style={{
                    backgroundColor: editingNote.categoryColor || '#EBB634',
                  }}
                />

                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-[#112625]/70">
                    Tipo de Evento
                  </label>
                  <select
                    value={editingNote.category}
                    onChange={(e) =>
                      handleCategoryChange(
                        e.target.value as NoteItem['category']
                      )
                    }
                    className="w-full py-2 px-3 rounded-xl bg-white/70 backdrop-blur-xl border border-white/90 text-xs font-bold text-[#112625] focus:outline-none shadow-xs"
                  >
                    <option value="Discurso Público">Discurso Público</option>
                    <option value="Simposio">Simposio</option>
                    <option value="Asamblea Regional">Asamblea Regional</option>
                    <option value="Estudio Personal">Estudio Personal</option>
                    <option value="Asamblea de Circuito">
                      Asamblea de Circuito
                    </option>
                    <option value="Sección de Reunión Semanal">
                      Sección de Reunión Semanal
                    </option>
                    <option value="Cursos y Ministerio">
                      Cursos y Ministerio
                    </option>
                    <option value="Lectura de la Biblia">
                      Lectura de la Biblia
                    </option>
                    <option value="Otro">Otro</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-[#112625]/70">
                    Título de la Ficha
                  </label>
                  <input
                    type="text"
                    value={editingNote.title || ''}
                    onChange={(e) =>
                      setEditingNote((prev) => ({
                        ...prev,
                        title: e.target.value,
                      }))
                    }
                    placeholder="Título del discurso o nota..."
                    className="w-full py-2 px-3.5 rounded-2xl bg-white/70 backdrop-blur-xl border border-white/90 text-xl font-bold text-[#112625] focus:outline-none shadow-xs"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-[#112625]/70 flex items-center gap-1">
                      <User className="w-3 h-3 text-[#276160]" />
                      <span>Orador</span>
                    </label>
                    <input
                      type="text"
                      value={editingNote.speaker || ''}
                      onChange={(e) =>
                        setEditingNote((prev) => ({
                          ...prev,
                          speaker: e.target.value,
                        }))
                      }
                      placeholder="Hermano..."
                      className="w-full py-1.5 px-3 rounded-xl bg-white/60 border border-white/80 text-xs font-semibold text-[#112625] focus:outline-none"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-[#112625]/70 flex items-center gap-1">
                      <Users className="w-3 h-3 text-[#276160]" />
                      <span>Congregación</span>
                    </label>
                    <input
                      type="text"
                      value={editingNote.congregation || ''}
                      onChange={(e) =>
                        setEditingNote((prev) => ({
                          ...prev,
                          congregation: e.target.value,
                        }))
                      }
                      placeholder="Congregación..."
                      className="w-full py-1.5 px-3 rounded-xl bg-white/60 border border-white/80 text-xs font-semibold text-[#112625] focus:outline-none"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center justify-between">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-[#112625]/70 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-[#B78628]" />
                        <span>Ubicación</span>
                      </label>
                      <button
                        type="button"
                        onClick={handleAutoGps}
                        className="text-[9px] font-bold text-[#276160] hover:underline cursor-pointer"
                      >
                        Auto-GPS
                      </button>
                    </div>
                    <input
                      type="text"
                      value={editingNote.location || ''}
                      onChange={(e) =>
                        setEditingNote((prev) => ({
                          ...prev,
                          location: e.target.value,
                        }))
                      }
                      placeholder="Lugar del discurso..."
                      className="w-full py-1.5 px-3 rounded-xl bg-white/60 border border-white/80 text-xs font-semibold text-[#112625] focus:outline-none"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-[#112625]/70 flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-[#276160]" />
                      <span>Fecha</span>
                    </label>
                    <input
                      type="text"
                      value={editingNote.date || ''}
                      onChange={(e) =>
                        setEditingNote((prev) => ({
                          ...prev,
                          date: e.target.value,
                        }))
                      }
                      className="w-full py-1.5 px-3 rounded-xl bg-white/60 border border-white/80 text-xs font-semibold text-[#112625] focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="p-3.5 rounded-3xl bg-white/60 backdrop-blur-2xl border border-white/80 shadow-[0_4px_15px_rgba(235,182,52,0.12)] flex flex-col gap-2">
                <div className="flex items-center justify-between px-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#276160]">
                    Resaltadores Semánticos (10 Tonos)
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => {
                        setEditingNote((prev) => ({
                          ...prev,
                          content: (prev.content || '') + ' **texto**',
                        }));
                      }}
                      className="p-1 rounded-lg bg-white/60 hover:bg-white text-xs text-[#112625]"
                    >
                      <Bold className="w-3.5 h-3.5" strokeWidth={2.5} />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEditingNote((prev) => ({
                          ...prev,
                          content: (prev.content || '') + ' __texto__',
                        }));
                      }}
                      className="p-1 rounded-lg bg-white/60 hover:bg-white text-xs text-[#112625]"
                    >
                      <Underline className="w-3.5 h-3.5" strokeWidth={2.5} />
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-1.5 overflow-x-auto py-1 px-1 no-scrollbar">
                  {SEMANTIC_HIGHLIGHTERS.map((h) => (
                    <button
                      key={h.id}
                      type="button"
                      onClick={() => {
                        setActiveHighlighterTooltip(h.name);
                        setEditingNote((prev) => ({
                          ...prev,
                          content:
                            (prev.content || '') +
                            ` [${h.name.split(':')[0]}: ]`,
                        }));
                        setTimeout(
                          () => setActiveHighlighterTooltip(null),
                          2500
                        );
                      }}
                      onMouseEnter={() => setActiveHighlighterTooltip(h.name)}
                      onMouseLeave={() => setActiveHighlighterTooltip(null)}
                      title={h.name}
                      className="w-6 h-6 rounded-full transition-all flex items-center justify-center cursor-pointer hover:scale-125 active:scale-95 shadow-sm shrink-0"
                      style={{
                        backgroundColor: h.hex,
                        boxShadow: `0 0 10px ${h.hex}60`,
                      }}
                    >
                      <div className="w-1.5 h-1.5 rounded-full bg-white/70" />
                    </button>
                  ))}
                </div>

                {activeHighlighterTooltip && (
                  <motion.div
                    initial={{ opacity: 0, y: 3 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-[10px] font-bold text-[#276160] dark:text-[#A7C7C6] text-center pt-1"
                  >
                    {activeHighlighterTooltip}
                  </motion.div>
                )}
              </div>

              <div className="p-4 rounded-3xl bg-white/60 dark:bg-[#122827]/80 backdrop-blur-2xl border border-white/80 dark:border-white/20 shadow-sm flex flex-col gap-3">
                <label className="text-[10px] font-bold uppercase tracking-wider text-[#112625]/70 dark:text-[#F6F4EE]/70">
                  Cuerpo de la Nota y Bosquejo
                </label>
                <textarea
                  rows={6}
                  value={editingNote.content || ''}
                  onChange={(e) =>
                    setEditingNote((prev) => ({
                      ...prev,
                      content: e.target.value,
                    }))
                  }
                  placeholder="Escribe tus notas aquí. Los textos bíblicos se detectan automáticamente..."
                  className="w-full p-3.5 rounded-2xl bg-white/70 dark:bg-white/10 backdrop-blur-xl border border-white/90 dark:border-white/20 text-xs font-medium text-[#112625] dark:text-[#F6F4EE] leading-relaxed focus:outline-none"
                />

                <div className="flex flex-col gap-2 pt-1 border-t border-black/[0.05] dark:border-white/10">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#276160] dark:text-[#A7C7C6]">
                    Textos Bíblicos Detectados:
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {detectedScriptures.map((scrip) => (
                      <a
                        key={scrip.raw}
                        href={scrip.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="py-1.5 px-3 rounded-full bg-white/40 dark:bg-white/10 backdrop-blur-xl border border-[#276160]/40 dark:border-[#A7C7C6]/40 shadow-xs text-xs font-bold text-[#276160] dark:text-[#A7C7C6] flex items-center gap-1.5 hover:bg-white/70 dark:hover:bg-white/20 transition-all cursor-pointer"
                      >
                        <BookOpen
                          className="w-3.5 h-3.5 text-[#276160] dark:text-[#A7C7C6]"
                          strokeWidth={2}
                        />
                        <span>{scrip.raw}</span>
                        <ExternalLink className="w-3 h-3 text-[#276160]/70 dark:text-[#A7C7C6]/70" />
                      </a>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between gap-3 pt-2 pb-16">
                {editingNote.id && (
                  <button
                    type="button"
                    onClick={() => {
                      if (editingNote.id) {
                        onDeleteNote(editingNote.id);
                        setActiveTab('notes');
                      }
                    }}
                    className="py-2.5 px-4 rounded-2xl bg-white/30 backdrop-blur-xl border border-rose-300 text-rose-700 text-xs font-bold flex items-center gap-1.5 hover:bg-rose-50/50 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Eliminar</span>
                  </button>
                )}
                <div className="flex items-center gap-2 ml-auto">
                  <button
                    type="button"
                    onClick={() => setActiveTab('notes')}
                    className="py-2.5 px-4 rounded-2xl bg-white/30 backdrop-blur-xl border border-white/80 shadow-[0_4px_15px_rgba(235,182,52,0.15)] text-[#122B2A] text-xs font-bold hover:bg-white/50 cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={handleSave}
                    className="py-2.5 px-6 rounded-2xl bg-white/40 backdrop-blur-xl border border-white/90 shadow-[0_4px_18px_rgba(235,182,52,0.25)] text-[#122B2A] text-xs font-black flex items-center gap-1.5 hover:bg-white/60 active:scale-95 cursor-pointer"
                  >
                    <Check
                      className="w-4 h-4 text-[#276160]"
                      strokeWidth={2.5}
                    />
                    <span>Guardar Ficha</span>
                  </button>
                </div>
              </div>

              <AnimatePresence>
                {saveSuccessNotice && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 5 }}
                    className="p-3 rounded-2xl bg-white/80 backdrop-blur-xl border border-emerald-300 text-emerald-900 text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <Sparkles className="w-4 h-4 text-emerald-600" />
                    <span>¡Ficha guardada exitosamente en la biblioteca!</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
