import React from 'react';
import { motion } from 'motion/react';
import { Bookmark, ChevronRight } from 'lucide-react';

interface BibleRadarCardProps {
  percentage?: number; // default 63
  completedBooksCount?: number; // default 41
  currentBookName?: string; // default "Amós"
  currentBookPercentage?: number; // default 32
  currentChapter?: number; // e.g. 4
  currentVerse?: number; // e.g. 1
  isReadingMarkedToday?: boolean;
  onOpenBibleMatrix: () => void;
}

export const BibleRadarCard: React.FC<BibleRadarCardProps> = ({
  percentage = 63,
  completedBooksCount = 41,
  currentBookName = 'Amós',
  currentBookPercentage = 32,
  currentChapter = 4,
  currentVerse = 1,
  isReadingMarkedToday = false,
  onOpenBibleMatrix,
}) => {
  // Check if evening (after 6 PM) for gentle golden aura pulse
  const now = new Date();
  const currentHour = now.getHours();
  const isEvening = currentHour >= 18 || currentHour < 6;
  const shouldPulseAura = isEvening && !isReadingMarkedToday;

  // 5 Canonical Category Bars
  const categoryStats = [
    { name: 'Históricos', percent: 76 },
    { name: 'Proféticos', percent: 54 },
    { name: 'Poéticos', percent: 60 },
    { name: 'Evangelios', percent: 80 },
    { name: 'Cartas', percent: 52 },
  ];

  // SVG Ring Chart calculations
  const size = 128;
  const strokeWidth = 10;
  const center = size / 2;
  const radius = center - strokeWidth;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className="relative group cursor-pointer" onClick={onOpenBibleMatrix}>
      {/* Warm Golden Backlight Orb Radiating Behind Card */}
      <div
        className={`absolute -inset-2 rounded-[38px] blur-2xl transition-all duration-1000 -z-10 ${
          shouldPulseAura
            ? 'bg-gradient-to-tr from-[#EBB634]/50 via-[#F6D365]/35 to-[#276160]/20 animate-pulse-gold scale-105'
            : 'bg-gradient-to-tr from-[#EBB634]/35 via-[#F6D365]/20 to-transparent opacity-80'
        }`}
      />

      {/* Hero Glass Container */}
      <div className="relative bg-white/55 dark:bg-white/10 backdrop-blur-2xl backdrop-saturate-150 border border-white/95 dark:border-white/20 rounded-[30px] p-6 shadow-[0_18px_45px_-10px_rgba(235,182,52,0.22),inset_0_1px_2px_rgba(255,255,255,0.95)] active:scale-[0.99] transition-all">
        {/* Top Content Row: Left Ring + Right 5 Category Bars */}
        <div className="flex items-center justify-between gap-5">
          {/* Left Side: Whole Bible Ring Chart */}
          <div className="flex flex-col items-center shrink-0">
            <div className="relative w-32 h-32 flex items-center justify-center">
              <svg width={size} height={size} className="transform -rotate-90">
                <defs>
                  <linearGradient id="bibleRingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#EBB634" />
                    <stop offset="65%" stopColor="#F6D365" />
                    <stop offset="100%" stopColor="#276160" />
                  </linearGradient>
                </defs>

                {/* Track */}
                <circle
                  cx={center}
                  cy={center}
                  r={radius}
                  stroke="#EFEBE1"
                  strokeWidth={strokeWidth}
                  fill="transparent"
                  className="opacity-70 dark:opacity-20"
                />

                {/* Filled Gradient Arc */}
                <motion.circle
                  cx={center}
                  cy={center}
                  r={radius}
                  stroke="url(#bibleRingGrad)"
                  strokeWidth={strokeWidth}
                  strokeDasharray={circumference}
                  initial={{ strokeDashoffset: circumference }}
                  animate={{ strokeDashoffset }}
                  transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1] }}
                  strokeLinecap="round"
                  fill="transparent"
                />
              </svg>

              {/* Inner Center Text */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none px-2">
                <span className="text-3xl font-extrabold text-[#112625] dark:text-[#EBB634] leading-none tracking-tight">
                  {percentage}%
                </span>
                <span className="text-[10px] font-medium text-[#276160]/80 dark:text-[#A7C7C6] text-center leading-tight mt-1">
                  Has completado {completedBooksCount} libros
                </span>
              </div>
            </div>
          </div>

          {/* Right Side: 5 Canonical Category Bars */}
          <div className="flex-1 flex flex-col justify-center space-y-2.5">
            {categoryStats.map((cat) => (
              <div key={cat.name} className="flex flex-col gap-0.5">
                <div className="flex items-center justify-between text-[11px] font-medium text-[#112625]/85 dark:text-[#F6F4EE]/90">
                  <span>{cat.name}</span>
                  <span className="text-[10px] font-semibold text-[#276160] dark:text-[#A7C7C6]">
                    {cat.percent}%
                  </span>
                </div>
                <div className="w-full h-[5px] rounded-full bg-[#E8E4DA]/60 dark:bg-white/15 overflow-hidden relative">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${cat.percent}%` }}
                    transition={{ duration: 1.2, ease: 'easeOut' }}
                    className="h-full rounded-full bg-gradient-to-r from-[#EBB634] to-[#276160]"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Bar: Current Book Pill with Subtle Golden Liquid Fill */}
        <div className="mt-6 relative overflow-hidden py-3 px-4 rounded-2xl bg-white/75 dark:bg-white/10 border border-[#EBB634]/45 flex items-center justify-between shadow-sm">
          {/* Subtle Golden Liquid Fill Indicator */}
          <div
            className="absolute left-0 top-0 bottom-0 bg-gradient-to-r from-[#EBB634]/20 via-[#F6D365]/15 to-transparent pointer-events-none transition-all duration-700"
            style={{ width: `${currentBookPercentage}%` }}
          />

          <div className="relative z-10 flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-[#EBB634]/20 flex items-center justify-center">
              <Bookmark className="w-3.5 h-3.5 text-[#B78628] dark:text-[#EBB634]" strokeWidth={1.75} />
            </div>
            <span className="text-xs font-bold text-[#112625] dark:text-[#F6F4EE] tracking-tight">
              Actual: {currentBookName}{' '}
              <span className="font-medium text-[#276160]/80 dark:text-[#A7C7C6]">
                (Cap. {currentChapter}: {currentVerse})
              </span>
            </span>
          </div>

          <div className="relative z-10 flex items-center gap-1.5">
            <span className="text-xs font-extrabold text-[#B78628] dark:text-[#EBB634]">
              {currentBookPercentage}%
            </span>
            <ChevronRight className="w-4 h-4 text-[#276160]/60 dark:text-[#A7C7C6]" strokeWidth={1.75} />
          </div>
        </div>
      </div>
    </div>
  );
};
