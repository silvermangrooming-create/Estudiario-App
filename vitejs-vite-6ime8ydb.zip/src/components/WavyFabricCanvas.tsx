import React from 'react';
import { motion } from 'motion/react';

interface WavyFabricCanvasProps {
  theme?: 'light' | 'sunlight' | 'dark';
}

export const WavyFabricCanvas: React.FC<WavyFabricCanvasProps> = ({ theme = 'light' }) => {
  const isDark = theme === 'dark';
  const isSunlight = theme === 'sunlight';

  return (
    <div
      aria-hidden="true"
      className={`fixed inset-0 z-0 overflow-hidden pointer-events-none select-none transition-colors duration-700 ${
        isDark ? 'bg-[#0B1716]' : isSunlight ? 'bg-[#FFFDF7]' : 'bg-[#FAF7F0]'
      }`}
    >
      {/* Subtle Architectural Dot Grid */}
      <div
        className="absolute inset-0 opacity-[0.22]"
        style={{
          backgroundImage: `radial-gradient(${
            isDark ? 'rgba(235,182,52,0.2)' : 'rgba(39,97,96,0.18)'
          } 1px, transparent 1px)`,
          backgroundSize: '24px 24px',
        }}
      />

      {/* Floating Warm Golden Ambient Refraction Glow Orbs */}
      <motion.div
        animate={{
          x: [0, 30, -20, 0],
          y: [0, -30, 20, 0],
          scale: [1, 1.1, 0.95, 1],
        }}
        transition={{
          duration: 18,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute top-[10%] -left-16 w-[380px] h-[380px] rounded-full blur-[80px]"
        style={{
          background: isDark
            ? 'radial-gradient(circle, rgba(235,182,52,0.22) 0%, rgba(39,97,96,0.12) 50%, transparent 75%)'
            : 'radial-gradient(circle, rgba(246,211,101,0.35) 0%, rgba(235,182,52,0.18) 45%, transparent 75%)',
        }}
      />

      <motion.div
        animate={{
          x: [0, -30, 25, 0],
          y: [0, 35, -25, 0],
          scale: [1, 1.12, 0.92, 1],
        }}
        transition={{
          duration: 22,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute top-[48%] -right-20 w-[420px] h-[420px] rounded-full blur-[85px]"
        style={{
          background: isDark
            ? 'radial-gradient(circle, rgba(39,97,96,0.25) 0%, rgba(235,182,52,0.12) 50%, transparent 80%)'
            : 'radial-gradient(circle, rgba(107,167,141,0.3) 0%, rgba(235,182,52,0.22) 45%, transparent 80%)',
        }}
      />

      {/* ========================================================
          EMULATED FLOWING ORGANIC RIBBON WAVES (From User Video)
          Visibly rendered, silky, elegant, with parallel contour
          striations and luminous warm golden wave crests.
          ======================================================== */}
      <svg
        viewBox="0 0 1440 1024"
        preserveAspectRatio="none"
        className="absolute inset-0 w-full h-full pointer-events-none"
      >
        <defs>
          {/* Subtle Sage & Seafoam Gradients matching the video palette */}
          <linearGradient id="waveSageTop" x1="0%" y1="0%" x2="100%" y2="80%">
            <stop offset="0%" stopColor="#84C198" stopOpacity={isDark ? "0.22" : "0.38"} />
            <stop offset="50%" stopColor="#6BA78D" stopOpacity={isDark ? "0.18" : "0.30"} />
            <stop offset="100%" stopColor="#276160" stopOpacity={isDark ? "0.12" : "0.22"} />
          </linearGradient>

          <linearGradient id="waveTealMid" x1="0%" y1="20%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#276160" stopOpacity={isDark ? "0.28" : "0.36"} />
            <stop offset="40%" stopColor="#4BB5A5" stopOpacity={isDark ? "0.22" : "0.32"} />
            <stop offset="80%" stopColor="#84C198" stopOpacity={isDark ? "0.15" : "0.25"} />
            <stop offset="100%" stopColor="#FAF7F0" stopOpacity="0.05" />
          </linearGradient>

          <linearGradient id="waveMintLower" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#6BA78D" stopOpacity={isDark ? "0.24" : "0.34"} />
            <stop offset="60%" stopColor="#9BD4C3" stopOpacity={isDark ? "0.18" : "0.28"} />
            <stop offset="100%" stopColor="#276160" stopOpacity={isDark ? "0.10" : "0.18"} />
          </linearGradient>

          {/* Luminous Warm Golden Crest Rim Light (from the video's glowing wave edge) */}
          <linearGradient id="goldenCrestGlow" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#EBB634" stopOpacity="0.2" />
            <stop offset="25%" stopColor="#F6D365" stopOpacity="0.85" />
            <stop offset="60%" stopColor="#EBB634" stopOpacity="0.95" />
            <stop offset="85%" stopColor="#F6D365" stopOpacity="0.75" />
            <stop offset="100%" stopColor="#EBB634" stopOpacity="0.2" />
          </linearGradient>

          <linearGradient id="goldenCrestSecondary" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#EBB634" stopOpacity="0.1" />
            <stop offset="40%" stopColor="#F6D365" stopOpacity="0.65" />
            <stop offset="70%" stopColor="#EBB634" stopOpacity="0.55" />
            <stop offset="100%" stopColor="#EBB634" stopOpacity="0.1" />
          </linearGradient>

          <filter id="crestFilter" x="-10%" y="-10%" width="120%" height="120%">
            <feGaussianBlur stdDeviation="2" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* ----------------------------------------------------
            LAYER 1: Upper Rolling Sage Swell (Video 2 Background Wave)
            ---------------------------------------------------- */}
        <motion.path
          d="M0,170 C280,100 480,250 780,140 C1080,40 1280,210 1440,150 L1440,1024 L0,1024 Z"
          fill="url(#waveSageTop)"
          animate={{
            d: [
              "M0,170 C280,100 480,250 780,140 C1080,40 1280,210 1440,150 L1440,1024 L0,1024 Z",
              "M0,140 C320,220 540,90 840,190 C1140,290 1260,100 1440,170 L1440,1024 L0,1024 Z",
              "M0,190 C260,70 500,270 740,130 C1040,30 1300,230 1440,140 L1440,1024 L0,1024 Z",
              "M0,170 C280,100 480,250 780,140 C1080,40 1280,210 1440,150 L1440,1024 L0,1024 Z",
            ],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />

        {/* Upper Wave Contour Ridge */}
        <motion.path
          d="M0,185 C280,115 480,265 780,155 C1080,55 1280,225 1440,165"
          fill="none"
          stroke="#276160"
          strokeWidth="1.2"
          strokeOpacity={isDark ? "0.3" : "0.35"}
          animate={{
            d: [
              "M0,185 C280,115 480,265 780,155 C1080,55 1280,225 1440,165",
              "M0,155 C320,235 540,105 840,205 C1140,305 1260,115 1440,185",
              "M0,205 C260,85 500,285 740,145 C1040,45 1300,245 1440,155",
              "M0,185 C280,115 480,265 780,155 C1080,55 1280,225 1440,165",
            ],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: 'easeInOut' }}
        />

        {/* ----------------------------------------------------
            LAYER 2: Main Middle Flowing Ribbon Body (Teal / Sage Gradient)
            ---------------------------------------------------- */}
        <motion.path
          d="M0,330 C340,470 520,190 880,350 C1220,500 1320,250 1440,320 L1440,1024 L0,1024 Z"
          fill="url(#waveTealMid)"
          animate={{
            d: [
              "M0,330 C340,470 520,190 880,350 C1220,500 1320,250 1440,320 L1440,1024 L0,1024 Z",
              "M0,370 C300,230 580,490 920,270 C1200,130 1360,430 1440,350 L1440,1024 L0,1024 Z",
              "M0,300 C380,500 490,170 840,390 C1180,530 1290,220 1440,290 L1440,1024 L0,1024 Z",
              "M0,330 C340,470 520,190 880,350 C1220,500 1320,250 1440,320 L1440,1024 L0,1024 Z",
            ],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />

        {/* ----------------------------------------------------
            LAYER 3: Signature Parallel Contour Lines (From Video 2)
            Fine silk striations running along the wave slope
            ---------------------------------------------------- */}
        {/* Striation Line 1 */}
        <motion.path
          d="M0,345 C340,485 520,205 880,365 C1220,515 1320,265 1440,335"
          fill="none"
          stroke="#276160"
          strokeWidth="1.2"
          strokeOpacity={isDark ? "0.35" : "0.4"}
          animate={{
            d: [
              "M0,345 C340,485 520,205 880,365 C1220,515 1320,265 1440,335",
              "M0,385 C300,245 580,505 920,285 C1200,145 1360,445 1440,365",
              "M0,315 C380,515 490,185 840,405 C1180,545 1290,235 1440,305",
              "M0,345 C340,485 520,205 880,365 C1220,515 1320,265 1440,335",
            ],
          }}
          transition={{ duration: 25, repeat: Infinity, ease: 'easeInOut' }}
        />

        {/* Striation Line 2 */}
        <motion.path
          d="M0,365 C340,505 520,225 880,385 C1220,535 1320,285 1440,355"
          fill="none"
          stroke="#4BB5A5"
          strokeWidth="1.2"
          strokeOpacity={isDark ? "0.3" : "0.35"}
          animate={{
            d: [
              "M0,365 C340,505 520,225 880,385 C1220,535 1320,285 1440,355",
              "M0,405 C300,265 580,525 920,305 C1200,165 1360,465 1440,385",
              "M0,335 C380,535 490,205 840,425 C1180,565 1290,255 1440,325",
              "M0,365 C340,505 520,225 880,385 C1220,535 1320,285 1440,355",
            ],
          }}
          transition={{ duration: 25, repeat: Infinity, ease: 'easeInOut' }}
        />

        {/* Striation Line 3 */}
        <motion.path
          d="M0,385 C340,525 520,245 880,405 C1220,555 1320,305 1440,375"
          fill="none"
          stroke="#276160"
          strokeWidth="1.2"
          strokeOpacity={isDark ? "0.25" : "0.3"}
          animate={{
            d: [
              "M0,385 C340,525 520,245 880,405 C1220,555 1320,305 1440,375",
              "M0,425 C300,285 580,545 920,325 C1200,185 1360,485 1440,405",
              "M0,355 C380,555 490,225 840,445 C1180,585 1290,275 1440,345",
              "M0,385 C340,525 520,245 880,405 C1220,555 1320,305 1440,375",
            ],
          }}
          transition={{ duration: 25, repeat: Infinity, ease: 'easeInOut' }}
        />

        {/* ----------------------------------------------------
            LAYER 4: Glowing Warm Golden Crest Rim Light
            (Noticeable golden edge highlight along the wave crest from Video 2)
            ---------------------------------------------------- */}
        <motion.path
          d="M0,330 C340,470 520,190 880,350 C1220,500 1320,250 1440,320"
          fill="none"
          stroke="url(#goldenCrestGlow)"
          strokeWidth="2.8"
          strokeLinecap="round"
          filter="url(#crestFilter)"
          animate={{
            d: [
              "M0,330 C340,470 520,190 880,350 C1220,500 1320,250 1440,320",
              "M0,370 C300,230 580,490 920,270 C1200,130 1360,430 1440,350",
              "M0,300 C380,500 490,170 840,390 C1180,530 1290,220 1440,290",
              "M0,330 C340,470 520,190 880,350 C1220,500 1320,250 1440,320",
            ],
            opacity: [0.75, 1, 0.65, 0.75],
          }}
          transition={{
            d: { duration: 25, repeat: Infinity, ease: 'easeInOut' },
            opacity: { duration: 5, repeat: Infinity, ease: 'easeInOut' },
          }}
        />

        {/* ----------------------------------------------------
            LAYER 5: Lower Foreground Sweeping Wave (Mint / Jade)
            ---------------------------------------------------- */}
        <motion.path
          d="M0,600 C360,440 620,740 980,530 C1280,380 1380,640 1440,560 L1440,1024 L0,1024 Z"
          fill="url(#waveMintLower)"
          animate={{
            d: [
              "M0,600 C360,440 620,740 980,530 C1280,380 1380,640 1440,560 L1440,1024 L0,1024 Z",
              "M0,540 C420,680 580,410 920,640 C1220,760 1340,480 1440,610 L1440,1024 L0,1024 Z",
              "M0,640 C320,400 660,780 1020,480 C1240,330 1400,680 1440,530 L1440,1024 L0,1024 Z",
              "M0,600 C360,440 620,740 980,530 C1280,380 1380,640 1440,560 L1440,1024 L0,1024 Z",
            ],
          }}
          transition={{
            duration: 23,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />

        {/* Lower Wave Striation Contour */}
        <motion.path
          d="M0,618 C360,458 620,758 980,548 C1280,398 1380,658 1440,578"
          fill="none"
          stroke="#276160"
          strokeWidth="1.2"
          strokeOpacity={isDark ? "0.3" : "0.35"}
          animate={{
            d: [
              "M0,618 C360,458 620,758 980,548 C1280,398 1380,658 1440,578",
              "M0,558 C420,698 580,428 920,658 C1220,778 1340,498 1440,628",
              "M0,658 C320,418 660,798 1020,498 C1240,348 1400,698 1440,548",
              "M0,618 C360,458 620,758 980,548 C1280,398 1380,658 1440,578",
            ],
          }}
          transition={{ duration: 23, repeat: Infinity, ease: 'easeInOut' }}
        />

        {/* Lower Wave Secondary Golden Rim */}
        <motion.path
          d="M0,600 C360,440 620,740 980,530 C1280,380 1380,640 1440,560"
          fill="none"
          stroke="url(#goldenCrestSecondary)"
          strokeWidth="2"
          strokeLinecap="round"
          animate={{
            d: [
              "M0,600 C360,440 620,740 980,530 C1280,380 1380,640 1440,560",
              "M0,540 C420,680 580,410 920,640 C1220,760 1340,480 1440,610",
              "M0,640 C320,400 660,780 1020,480 C1240,330 1400,680 1440,530",
              "M0,600 C360,440 620,740 980,530 C1280,380 1380,640 1440,560",
            ],
          }}
          transition={{ duration: 23, repeat: Infinity, ease: 'easeInOut' }}
        />
      </svg>
    </div>
  );
};
