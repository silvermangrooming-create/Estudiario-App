import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, type PanInfo } from 'motion/react';
import {
  Timer,
  Sparkles,
  UserCheck,
  Crop,
  Pin,
  BookOpen,
  Play,
  Pause,
  RotateCcw,
  Plus,
  Send,
  Mic,
  MicOff,
  Volume2,
  Check,
  X,
  ExternalLink,
} from 'lucide-react';
import { EstudiarioLogo } from './EstudiarioLogo';
import {
  CANONICAL_BOOKS,
  parseScriptureReferences,
} from '../data/canonicalBible';
import type { NoteItem } from '../data/notesData';

export type ActiveToolType =
  | null
  | 'timer'
  | 'ai'
  | 'student'
  | 'crop'
  | 'bookmark'
  | 'quicknote';

interface MetamorphicWidgetProps {
  isDeployed: boolean;
  onToggleDeploy: () => void;
  onUpdateBookmark: (book: string, chapter: number, verse: number) => void;
  onAddHours: (hours: number) => void;
  onSaveQuickNote: (note: Partial<NoteItem>) => void;
  onAddStudentPin?: (
    studentName: string,
    scripture: string,
    note: string
  ) => void;
  studentsList?: string[];
  notesList?: NoteItem[];
  geminiApiKey?: string;
}

export const MetamorphicWidget: React.FC<MetamorphicWidgetProps> = ({
  isDeployed,
  onToggleDeploy,
  onUpdateBookmark,
  onAddHours,
  onSaveQuickNote,
  onAddStudentPin,
  studentsList = ['Josué', 'Carlos', 'Andrés', 'Mateo'],
  notesList = [],
  geminiApiKey = '',
}) => {
  // Widget stage: stage 1 = dormant (isDeployed=false, activeTool=null),
  // stage 2 = unfolded blades (isDeployed=true, activeTool=null),
  // stage 3 = active tool circle (activeTool !== null)
  const [activeTool, setActiveTool] = useState<ActiveToolType>(null);

  // Stage 3 - Timer State
  const [timerSeconds, setTimerSeconds] = useState(123); // starts at 02:03 for prompt spec demo
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [rollbackMinutes, setRollbackMinutes] = useState(0);

  // Stage 3 - Bookmark Selector State
  const [selectedBook, setSelectedBook] = useState('Amós');
  const [selectedChapter, setSelectedChapter] = useState(4);
  const [selectedVerse, setSelectedVerse] = useState(1);

  // Stage 3 - Quick Note State
  const [quickNoteText, setQuickNoteText] = useState('');
  const [quickNoteSaved, setQuickNoteSaved] = useState(false);

  // Stage 3 - Connect Student State
  const [selectedStudent, setSelectedStudent] = useState(
    studentsList[0] || 'Josué'
  );
  const [studentMessage, setStudentMessage] = useState('');
  const [studentSent, setStudentSent] = useState(false);

  // Stage 3 - Crop Snapshot State
  const [cropSnippet, setCropSnippet] = useState(
    'Amós 5:24: "Que la justicia fluya como las aguas, y la rectitud como una corriente inagotable."'
  );
  const [targetNoteId, setTargetNoteId] = useState(notesList[0]?.id || '');
  const [cropAttached, setCropAttached] = useState(false);

  // Stage 3 - AI Assistant State (sandboxed to wol.jw.org and local notes)
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiChatHistory, setAiChatHistory] = useState<
    Array<{ role: 'user' | 'assistant'; text: string; link?: string }>
  >([
    {
      role: 'assistant',
      text: 'Paz. Soy tu asistente teocrático en Estudiario. Consulta pasajes, bosquejos de discursos o publicaciones de wol.jw.org.',
      link: 'https://wol.jw.org/es/wol/h/r4/lp-s',
    },
  ]);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const speechRecognitionRef = useRef<any>(null);

  // Timer interval effect
  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning]);

  const formatTimer = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  // Return gesture handlers: Swipe down or double-tap on active circle
  const handleCircleSwipe = (_: unknown, info: PanInfo) => {
    if (info.offset.y > 45) {
      // Swiped down! Collapse back to dormant stage 1
      setActiveTool(null);
      if (isDeployed) onToggleDeploy();
    }
  };

  const handleDoubleTap = () => {
    setActiveTool(null);
    if (isDeployed) onToggleDeploy();
  };

  // Log timer hours to dashboard
  const handleLogTimerHours = () => {
    const effectiveSeconds = Math.max(0, timerSeconds - rollbackMinutes * 60);
    const hoursFraction = parseFloat((effectiveSeconds / 3600).toFixed(1));
    if (hoursFraction > 0) {
      onAddHours(hoursFraction);
    }
    setIsTimerRunning(false);
    setTimerSeconds(0);
    setRollbackMinutes(0);
    setActiveTool(null);
    if (isDeployed) onToggleDeploy();
  };

  // Quick chips for timer (+15m, +30m, +1h)
  const handleAddTimerOffset = (minutes: number) => {
    setTimerSeconds((prev) => prev + minutes * 60);
  };

  // Save Bookmark
  const handleSaveBookmark = () => {
    onUpdateBookmark(selectedBook, selectedChapter, selectedVerse);
    setActiveTool(null);
    if (isDeployed) onToggleDeploy();
  };

  // Save Quick Note
  const handleSaveQuickNoteAction = () => {
    if (!quickNoteText.trim()) return;
    const parsed = parseScriptureReferences(quickNoteText);
    onSaveQuickNote({
      title:
        quickNoteText.slice(0, 36) + (quickNoteText.length > 36 ? '...' : ''),
      content: quickNoteText,
      category: 'Estudio Personal',
      categoryColor: '#1D5B57',
      scriptures: parsed.map((p) => p.raw),
    });
    setQuickNoteSaved(true);
    setTimeout(() => {
      setQuickNoteSaved(false);
      setQuickNoteText('');
      setActiveTool(null);
      if (isDeployed) onToggleDeploy();
    }, 1000);
  };

  // Send to student
  const handleSendToStudent = () => {
    if (!studentMessage.trim()) return;
    const parsed = parseScriptureReferences(studentMessage);
    const scripture =
      parsed[0]?.raw ||
      (studentMessage.includes(':')
        ? studentMessage.split(':')[0].trim()
        : 'Santiago 1:13');
    onAddStudentPin?.(selectedStudent, scripture, studentMessage);
    setStudentSent(true);
    setTimeout(() => {
      setStudentSent(false);
      setStudentMessage('');
      setActiveTool(null);
      if (isDeployed) onToggleDeploy();
    }, 1200);
  };

  // Attach crop
  const handleAttachCrop = () => {
    setCropAttached(true);
    setTimeout(() => {
      setCropAttached(false);
      setActiveTool(null);
      if (isDeployed) onToggleDeploy();
    }, 1200);
  };

  // Voice-to-Text (webkitSpeechRecognition in es-ES)
  const toggleSpeechRecognition = () => {
    if (isListening) {
      speechRecognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Tu navegador no soporta reconocimiento de voz nativo.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'es-ES';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setAiPrompt((prev) => (prev ? `${prev} ${transcript}` : transcript));
      };

      speechRecognitionRef.current = recognition;
      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  // Text-to-Speech (window.speechSynthesis)
  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'es-ES';
      utterance.rate = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Handle AI question with sandbox instructions
  const handleSendAiPrompt = async () => {
    if (!aiPrompt.trim() || isAiLoading) return;
    const query = aiPrompt.trim();
    setAiPrompt('');
    setAiChatHistory((prev) => [...prev, { role: 'user', text: query }]);
    setIsAiLoading(true);

    const systemPrompt = `Eres el Asistente Teocrático de Estudiario para el usuario Gabriel.
REGLAS ESTRICTAS DE SEGURIDAD Y SANDBOX:
1. Tu base de conocimiento y respuestas provienen EXCLUSIVAMENTE de la Biblia (Traducción del Nuevo Mundo) y de la Biblioteca en Línea Watchtower (wol.jw.org).
2. Proporciona explicaciones bíblicas respetuosas, citas exactas de textos bíblicos en español y referencias a wol.jw.org.
3. Si la pregunta incluye citas bíblicas, cita el texto con precisión y su aplicación práctica en el ministerio o vida cristiana.
4. Mantén un tono cálido, edificante y claro.`;

    try {
      if (geminiApiKey) {
        // Direct call to Gemini 3.8 Flash
        const response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${geminiApiKey}`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents: [
                {
                  role: 'user',
                  parts: [{ text: `${systemPrompt}\n\nPregunta: ${query}` }],
                },
              ],
            }),
          }
        );
        const data = await response.json();
        const text =
          data?.candidates?.[0]?.content?.parts?.[0]?.text ||
          'En wol.jw.org puedes profundizar sobre este tema. Cita clave: Proverbios 3:5, 6.';
        setAiChatHistory((prev) => [
          ...prev,
          {
            role: 'assistant',
            text,
            link: 'https://wol.jw.org/es/wol/h/r4/lp-s',
          },
        ]);
      } else {
        // High quality offline fallback with curated biblical responses
        setTimeout(() => {
          let responseText = `Basado en wol.jw.org: Sobre "${query}", recordemos que Jehová aprecia los esfuerzos constantes y sinceros en el ministerio.`;
          if (query.toLowerCase().includes('amos')) {
            responseText =
              'El libro de Amós resalta la justicia leal de Jehová y su llamado a los humildes. En wol.jw.org se explica que Amós atendió el encargo con profunda reverencia.';
          } else if (
            query.toLowerCase().includes('revisita') ||
            query.toLowerCase().includes('estudiante')
          ) {
            responseText =
              'Para cultivar el interés de los estudiantes, formular preguntas de punto de vista con bondad y enlazar las verdades bíblicas con su vida cotidiana resulta sumamente eficaz (wol.jw.org).';
          }
          setAiChatHistory((prev) => [
            ...prev,
            {
              role: 'assistant',
              text: responseText,
              link: 'https://wol.jw.org/es/wol/h/r4/lp-s',
            },
          ]);
        }, 600);
      }
    } catch {
      setAiChatHistory((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: 'Puedes consultar más detalles directamente en wol.jw.org.',
          link: 'https://wol.jw.org/es/wol/h/r4/lp-s',
        },
      ]);
    } finally {
      setIsAiLoading(false);
    }
  };

  return (
    <div className="fixed right-5 bottom-24 z-40 flex flex-col items-end pointer-events-auto">
      {/* ========================================================
          STAGE 1: Dormant Emblem (When not deployed and no active tool)
          ======================================================== */}
      {!isDeployed && !activeTool && (
        <motion.div
          layoutId="widget-sun"
          transition={{ type: 'spring', bounce: 0.25, duration: 0.4 }}
          onClick={onToggleDeploy}
          title="Abrir menú de herramientas teocráticas"
          className="w-15 h-15 rounded-full bg-white/75 dark:bg-[#122827]/80 backdrop-blur-2xl border border-white dark:border-white/20 shadow-[0_10px_30px_rgba(235,182,52,0.4)] p-2.5 flex items-center justify-center cursor-pointer active:scale-95 transition-transform"
        >
          <EstudiarioLogo
            sunLayoutId="widget-inner-sun"
            leavesLayoutId="widget-inner-leaves"
            className="w-full h-full"
          />
        </motion.div>
      )}

      {/* ========================================================
          STAGE 2: Unfolded Scrollable Blade Menu (When deployed, no tool chosen)
          ======================================================== */}
      {isDeployed && !activeTool && (
        <div className="flex flex-col items-center">
          {/* Top Golden Circle: 100% BLANK - NO TEXT INSIDE! */}
          <motion.div
            layoutId="widget-sun"
            transition={{ type: 'spring', bounce: 0.25, duration: 0.4 }}
            onClick={onToggleDeploy}
            title="Toca para replegar herramientas"
            className="w-16 h-16 rounded-full bg-gradient-to-br from-[#F6D365] to-[#EBB634] border-2 border-white shadow-[0_0_28px_rgba(235,182,52,0.65)] flex items-center justify-center cursor-pointer active:scale-95 transition-transform"
          >
            {/* STRICT PROHIBITION: The expanded golden circle in Stage 2 MUST be 100% BLANK! NEVER render "ESTU Diario" or any text inside! */}
          </motion.div>

          {/* Underneath: Vertically Scrollable Glass Blade Container wrapped in curtain foldout */}
          <AnimatePresence>
            <motion.div
              initial={{ opacity: 0, height: 0, y: -12, scaleY: 0.85 }}
              animate={{ opacity: 1, height: 'auto', y: 0, scaleY: 1 }}
              exit={{ opacity: 0, height: 0, y: -12, scaleY: 0.85 }}
              transition={{ type: 'spring', bounce: 0.25, duration: 0.4 }}
              className="overflow-hidden mt-2 origin-top"
            >
              <div className="max-h-[162px] w-56 overflow-y-auto snap-y space-y-1.5 p-2 rounded-3xl bg-white/85 dark:bg-[#122827]/90 backdrop-blur-2xl border border-white dark:border-white/20 shadow-2xl [mask-image:linear-gradient(to_bottom,transparent_0%,black_10%,black_90%,transparent_100%)]">
                {/* Blade 1: Cronómetro */}
                <button
                  type="button"
                  onClick={() => setActiveTool('timer')}
                  className="w-full snap-start py-2 px-3 rounded-2xl bg-white/70 dark:bg-white/10 hover:bg-[#EBB634]/15 border border-[#EBB634]/30 flex items-center gap-2.5 active:scale-95 transition-all text-left cursor-pointer"
                >
                  <div className="w-7 h-7 rounded-xl bg-[#EBB634]/20 flex items-center justify-center shrink-0">
                    <Timer
                      className="w-4 h-4 text-[#B78628] dark:text-[#EBB634]"
                      strokeWidth={1.75}
                    />
                  </div>
                  <span className="text-xs font-bold text-[#112625] dark:text-[#F6F4EE]">
                    Cronómetro
                  </span>
                </button>

                {/* Blade 2: Asistente IA */}
                <button
                  type="button"
                  onClick={() => setActiveTool('ai')}
                  className="w-full snap-start py-2 px-3 rounded-2xl bg-white/70 dark:bg-white/10 hover:bg-[#EBB634]/15 border border-[#EBB634]/30 flex items-center gap-2.5 active:scale-95 transition-all text-left cursor-pointer"
                >
                  <div className="w-7 h-7 rounded-xl bg-[#EBB634]/20 flex items-center justify-center shrink-0">
                    <Sparkles
                      className="w-4 h-4 text-[#B78628] dark:text-[#EBB634]"
                      strokeWidth={1.75}
                    />
                  </div>
                  <span className="text-xs font-bold text-[#112625] dark:text-[#F6F4EE]">
                    Asistente IA
                  </span>
                </button>

                {/* Blade 3: Conectar a Estudiante */}
                <button
                  type="button"
                  onClick={() => setActiveTool('student')}
                  className="w-full snap-start py-2 px-3 rounded-2xl bg-white/70 dark:bg-white/10 hover:bg-[#276160]/15 border border-[#276160]/30 flex items-center gap-2.5 active:scale-95 transition-all text-left cursor-pointer"
                >
                  <div className="w-7 h-7 rounded-xl bg-[#276160]/20 flex items-center justify-center shrink-0">
                    <UserCheck
                      className="w-4 h-4 text-[#276160] dark:text-[#A7C7C6]"
                      strokeWidth={1.75}
                    />
                  </div>
                  <span className="text-xs font-bold text-[#112625] dark:text-[#F6F4EE]">
                    Conectar a Estudiante
                  </span>
                </button>

                {/* Blade 4: Captura / Recorte */}
                <button
                  type="button"
                  onClick={() => setActiveTool('crop')}
                  className="w-full snap-start py-2 px-3 rounded-2xl bg-white/70 dark:bg-white/10 hover:bg-[#276160]/15 border border-[#276160]/30 flex items-center gap-2.5 active:scale-95 transition-all text-left cursor-pointer"
                >
                  <div className="w-7 h-7 rounded-xl bg-[#276160]/20 flex items-center justify-center shrink-0">
                    <Crop
                      className="w-4 h-4 text-[#276160] dark:text-[#A7C7C6]"
                      strokeWidth={1.75}
                    />
                  </div>
                  <span className="text-xs font-bold text-[#112625] dark:text-[#F6F4EE]">
                    Captura / Recorte
                  </span>
                </button>

                {/* Blade 5: Marcador de Biblia */}
                <button
                  type="button"
                  onClick={() => setActiveTool('bookmark')}
                  className="w-full snap-start py-2 px-3 rounded-2xl bg-white/70 dark:bg-white/10 hover:bg-[#EBB634]/15 border border-[#EBB634]/30 flex items-center gap-2.5 active:scale-95 transition-all text-left cursor-pointer"
                >
                  <div className="w-7 h-7 rounded-xl bg-[#EBB634]/20 flex items-center justify-center shrink-0">
                    <Pin
                      className="w-4 h-4 text-[#B78628] dark:text-[#EBB634]"
                      strokeWidth={1.75}
                    />
                  </div>
                  <span className="text-xs font-bold text-[#112625] dark:text-[#F6F4EE]">
                    Marcador de Biblia
                  </span>
                </button>

                {/* Blade 6: Enviar a Notas */}
                <button
                  type="button"
                  onClick={() => setActiveTool('quicknote')}
                  className="w-full snap-start py-2 px-3 rounded-2xl bg-white/70 dark:bg-white/10 hover:bg-[#276160]/15 border border-[#276160]/30 flex items-center gap-2.5 active:scale-95 transition-all text-left cursor-pointer"
                >
                  <div className="w-7 h-7 rounded-xl bg-[#276160]/20 flex items-center justify-center shrink-0">
                    <BookOpen
                      className="w-4 h-4 text-[#276160] dark:text-[#A7C7C6]"
                      strokeWidth={1.75}
                    />
                  </div>
                  <span className="text-xs font-bold text-[#112625] dark:text-[#F6F4EE]">
                    Enviar a Notas
                  </span>
                </button>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      )}

      {/* ========================================================
          STAGE 3: Morphed Active Tool Circle & Return Gesture
          (Double-tap or swipe down on the glowing circle to return to Stage 1)
          ======================================================== */}
      {activeTool && (
        <div className="flex flex-col items-end">
          {/* Floating Glass Tool Palette Panel */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 10 }}
            className="w-72 max-h-[420px] overflow-y-auto mb-2.5 p-4 rounded-3xl bg-white/90 backdrop-blur-2xl border border-white shadow-2xl flex flex-col gap-3"
          >
            {/* Tool Header with Close Return */}
            <div className="flex items-center justify-between pb-2 border-b border-black/[0.05]">
              <span className="text-xs font-extrabold uppercase tracking-wider text-[#276160]">
                {activeTool === 'timer' && 'Cronómetro de Servicio'}
                {activeTool === 'bookmark' && 'Marcador de Lectura'}
                {activeTool === 'quicknote' && 'Enviar a Notas'}
                {activeTool === 'crop' && 'Captura / Recorte'}
                {activeTool === 'student' && 'Conectar a Estudiante'}
                {activeTool === 'ai' && 'Asistente wol.jw.org'}
              </span>
              <button
                type="button"
                onClick={() => {
                  setActiveTool(null);
                  if (isDeployed) onToggleDeploy();
                }}
                className="w-6 h-6 rounded-full bg-black/5 hover:bg-black/10 flex items-center justify-center text-[#112625]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* 1. CRONÓMETRO TOOL */}
            {activeTool === 'timer' && (
              <div className="flex flex-col gap-3">
                <div className="text-center">
                  <div className="text-3xl font-extrabold text-[#112625] tracking-tight">
                    {formatTimer(timerSeconds)}
                  </div>
                  <span className="text-[10px] text-[#276160]/75">
                    {isTimerRunning ? 'Grabando horas activas' : 'Pausado'}
                  </span>
                </div>

                {/* Play / Pause / Reset Controls */}
                <div className="flex items-center justify-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsTimerRunning(!isTimerRunning)}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#EBB634] to-[#B78628] text-white text-xs font-bold flex items-center gap-1.5 shadow-sm active:scale-95 transition-transform"
                  >
                    {isTimerRunning ? (
                      <>
                        <Pause className="w-3.5 h-3.5" /> Pausar
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5" /> Iniciar
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => setTimerSeconds(0)}
                    className="p-2 rounded-xl bg-black/5 hover:bg-black/10 text-[#112625] active:scale-95"
                    title="Reiniciar"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* +15m / +30m / +1h chips */}
                <div className="flex items-center justify-between gap-1.5 pt-1">
                  <button
                    type="button"
                    onClick={() => handleAddTimerOffset(15)}
                    className="flex-1 py-1 px-2 rounded-lg bg-white/90 border border-[#EBB634]/40 text-[10px] font-bold text-[#B78628] hover:bg-[#EBB634]/15 active:scale-95"
                  >
                    +15m
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddTimerOffset(30)}
                    className="flex-1 py-1 px-2 rounded-lg bg-white/90 border border-[#EBB634]/40 text-[10px] font-bold text-[#B78628] hover:bg-[#EBB634]/15 active:scale-95"
                  >
                    +30m
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddTimerOffset(60)}
                    className="flex-1 py-1 px-2 rounded-lg bg-white/90 border border-[#EBB634]/40 text-[10px] font-bold text-[#B78628] hover:bg-[#EBB634]/15 active:scale-95"
                  >
                    +1h
                  </button>
                </div>

                {/* "Forgot to Stop" Rollback Slider */}
                <div className="flex flex-col gap-1 p-2 rounded-xl bg-black/[0.03]">
                  <div className="flex items-center justify-between text-[10px] font-medium text-[#112625]/80">
                    <span>Olvidé parar (Retroceder):</span>
                    <span className="font-bold text-red-600">
                      -{rollbackMinutes} min
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="60"
                    step="5"
                    value={rollbackMinutes}
                    onChange={(e) =>
                      setRollbackMinutes(parseInt(e.target.value, 10))
                    }
                    className="w-full accent-[#EBB634]"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleLogTimerHours}
                  className="w-full py-2.5 rounded-xl bg-[#276160] text-white text-xs font-bold shadow-md active:scale-95 transition-transform"
                >
                  Registrar horas en Servicio
                </button>
              </div>
            )}

            {/* 2. MARCADOR DE BIBLIA TOOL */}
            {activeTool === 'bookmark' && (
              <div className="flex flex-col gap-2.5">
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-[#112625]/70">
                    Libro
                  </label>
                  <select
                    value={selectedBook}
                    onChange={(e) => setSelectedBook(e.target.value)}
                    className="w-full py-1.5 px-2.5 rounded-xl bg-white/80 border border-[#EBB634]/40 text-xs font-semibold"
                  >
                    {CANONICAL_BOOKS.map((b) => (
                      <option key={b.name} value={b.name}>
                        {b.name} ({b.chapters} caps)
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-[#112625]/70">
                      Capítulo
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="150"
                      value={selectedChapter}
                      onChange={(e) =>
                        setSelectedChapter(parseInt(e.target.value, 10) || 1)
                      }
                      className="w-full py-1.5 px-2.5 rounded-xl bg-white/80 border border-[#EBB634]/40 text-xs font-bold"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-[#112625]/70">
                      Versículo
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="176"
                      value={selectedVerse}
                      onChange={(e) =>
                        setSelectedVerse(parseInt(e.target.value, 10) || 1)
                      }
                      className="w-full py-1.5 px-2.5 rounded-xl bg-white/80 border border-[#EBB634]/40 text-xs font-bold"
                    />
                  </div>
                </div>

                <p className="text-[10px] text-[#276160]/80">
                  Al guardar, se actualizará el anillo del 63%, la barra de
                  categoría y la pastilla Actual: {selectedBook}.
                </p>

                <button
                  type="button"
                  onClick={handleSaveBookmark}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#EBB634] to-[#B78628] text-white text-xs font-extrabold shadow-md active:scale-95 transition-transform"
                >
                  Guardar Marcador
                </button>
              </div>
            )}

            {/* 3. ENVIAR A NOTAS TOOL */}
            {activeTool === 'quicknote' && (
              <div className="flex flex-col gap-2.5">
                <textarea
                  rows={3}
                  value={quickNoteText}
                  onChange={(e) => setQuickNoteText(e.target.value)}
                  placeholder="Escribe una cita, pensamiento o versículo (ej. Amós 3:2)..."
                  className="w-full p-2.5 rounded-xl bg-white/90 border border-[#EBB634]/40 text-xs leading-relaxed focus:outline-none"
                />
                <button
                  type="button"
                  onClick={handleSaveQuickNoteAction}
                  className="w-full py-2 rounded-xl bg-[#276160] text-white text-xs font-bold flex items-center justify-center gap-1 active:scale-95 transition-transform"
                >
                  {quickNoteSaved ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    <Send className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {quickNoteSaved
                      ? '¡Guardada en Biblioteca!'
                      : 'Enviar a Biblioteca'}
                  </span>
                </button>
              </div>
            )}

            {/* 4. CONECTAR A ESTUDIANTE */}
            {activeTool === 'student' && (
              <div className="flex flex-col gap-2.5">
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-[#112625]/70">
                    Estudiante
                  </label>
                  <select
                    value={selectedStudent}
                    onChange={(e) => setSelectedStudent(e.target.value)}
                    className="w-full py-1.5 px-2.5 rounded-xl bg-white/80 border border-[#276160]/40 text-xs font-bold text-[#276160]"
                  >
                    {studentsList.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>
                <textarea
                  rows={2}
                  value={studentMessage}
                  onChange={(e) => setStudentMessage(e.target.value)}
                  placeholder={`Mensaje, recordatorio o versículo para ${selectedStudent}...`}
                  className="w-full p-2 rounded-xl bg-white/90 border border-black/10 text-xs focus:outline-none"
                />
                <button
                  type="button"
                  onClick={handleSendToStudent}
                  className="w-full py-2 rounded-xl bg-[#276160] text-white text-xs font-bold flex items-center justify-center gap-1 active:scale-95 transition-transform"
                >
                  {studentSent ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    <Send className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {studentSent
                      ? `¡Enviado a ${selectedStudent}!`
                      : `Conectar con ${selectedStudent}`}
                  </span>
                </button>
              </div>
            )}

            {/* 5. CAPTURA / RECORTE */}
            {activeTool === 'crop' && (
              <div className="flex flex-col gap-2.5">
                <div className="p-2.5 rounded-xl bg-[#FAF7F0] border border-[#EBB634]/40 text-[11px] text-[#112625] italic leading-relaxed">
                  "{cropSnippet}"
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-[#112625]/70">
                    Adjuntar a nota:
                  </label>
                  <select
                    value={targetNoteId}
                    onChange={(e) => setTargetNoteId(e.target.value)}
                    className="w-full py-1.5 px-2 rounded-xl bg-white border border-black/10 text-xs"
                  >
                    {notesList.map((n) => (
                      <option key={n.id} value={n.id}>
                        {n.title}
                      </option>
                    ))}
                  </select>
                </div>
                <button
                  type="button"
                  onClick={handleAttachCrop}
                  className="w-full py-2 rounded-xl bg-[#276160] text-white text-xs font-bold flex items-center justify-center gap-1 active:scale-95"
                >
                  {cropAttached ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    <Crop className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {cropAttached
                      ? '¡Recorte Adjuntado!'
                      : 'Guardar Recorte en Nota'}
                  </span>
                </button>
              </div>
            )}

            {/* 6. ASISTENTE IA (wol.jw.org sandboxed) */}
            {activeTool === 'ai' && (
              <div className="flex flex-col gap-2 max-h-[300px]">
                <div className="flex-1 overflow-y-auto space-y-2 max-h-[160px] p-2 rounded-xl bg-[#FAF7F0]/60">
                  {aiChatHistory.map((msg, i) => (
                    <div
                      key={i}
                      className={`text-[11px] p-2 rounded-xl leading-relaxed ${
                        msg.role === 'user'
                          ? 'bg-[#276160] text-white ml-4'
                          : 'bg-white/90 text-[#112625] mr-2 border border-black/[0.05]'
                      }`}
                    >
                      <p>{msg.text}</p>
                      {msg.role === 'assistant' && (
                        <div className="flex items-center gap-2 mt-1.5">
                          <button
                            type="button"
                            onClick={() => speakText(msg.text)}
                            title="Escuchar respuesta"
                            className="text-[9px] font-bold text-[#276160] flex items-center gap-0.5"
                          >
                            <Volume2 className="w-3 h-3" />
                            <span>Escuchar</span>
                          </button>
                          {msg.link && (
                            <a
                              href={msg.link}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[9px] font-bold text-[#B78628] flex items-center gap-0.5 ml-auto"
                            >
                              <span>wol.jw.org</span>
                              <ExternalLink className="w-2.5 h-2.5" />
                            </a>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                  {isAiLoading && (
                    <div className="text-[10px] text-[#276160] italic">
                      Consultando wol.jw.org...
                    </div>
                  )}
                </div>

                {/* Input with Voice-to-Text */}
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendAiPrompt()}
                    placeholder="Preguntar a wol.jw.org..."
                    className="flex-1 py-1.5 px-3 rounded-xl bg-white border border-[#EBB634]/40 text-xs focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={toggleSpeechRecognition}
                    title="Hablar (Voz a texto es-ES)"
                    className={`p-2 rounded-xl transition-all cursor-pointer ${
                      isListening
                        ? 'bg-red-500 text-white animate-pulse'
                        : 'bg-[#EBB634]/20 text-[#966708]'
                    }`}
                  >
                    {isListening ? (
                      <MicOff className="w-3.5 h-3.5" />
                    ) : (
                      <Mic className="w-3.5 h-3.5" />
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={handleSendAiPrompt}
                    className="p-2 rounded-xl bg-[#276160] text-white cursor-pointer active:scale-95"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </motion.div>

          {/* Morphed Active Tool Circle with Return Gesture:
              Swiping down on the active circle OR double-tapping it collapses back to Stage 1 */}
          <motion.div
            layoutId="widget-sun"
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            onDragEnd={handleCircleSwipe}
            onDoubleClick={handleDoubleTap}
            title="Doble toque o desliza hacia abajo para replegar"
            className="w-16 h-16 rounded-full bg-gradient-to-br from-[#F6D365] to-[#EBB634] border-2 border-white shadow-[0_0_28px_rgba(235,182,52,0.65)] flex items-center justify-center cursor-pointer active:scale-95 transition-transform relative select-none"
          >
            {activeTool === 'timer' && (
              <div className="flex flex-col items-center">
                <span className="text-xs font-black text-[#112625] leading-none">
                  {formatTimer(timerSeconds)}
                </span>
                <span className="text-[8px] font-bold text-[#112625]/75 mt-0.5">
                  {isTimerRunning ? 'ACTIVO' : 'PAUSA'}
                </span>
              </div>
            )}

            {activeTool === 'bookmark' && (
              <Pin className="w-7 h-7 text-[#112625]" strokeWidth={2} />
            )}

            {activeTool === 'quicknote' && (
              <BookOpen className="w-7 h-7 text-[#112625]" strokeWidth={2} />
            )}

            {activeTool === 'crop' && (
              <Crop className="w-7 h-7 text-[#112625]" strokeWidth={2} />
            )}

            {activeTool === 'student' && (
              <UserCheck className="w-7 h-7 text-[#112625]" strokeWidth={2} />
            )}

            {activeTool === 'ai' && (
              <Sparkles className="w-7 h-7 text-[#112625]" strokeWidth={2} />
            )}
          </motion.div>
        </div>
      )}
    </div>
  );
};
