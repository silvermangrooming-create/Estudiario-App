import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence, type PanInfo } from 'motion/react';
import {
  Plus,
  Search,
  BookOpen,
  Clock,
  Calendar as CalendarIcon,
  Tag,
  Sparkles,
  AlertCircle,
} from 'lucide-react';
import { INITIAL_NOTES, type NoteItem } from '../data/notesData';

// Tipos extraídos de notesData.ts para evitar errores de importación circular
export type NoteCategory =
  | 'Sermón'
  | 'Estudio Personal'
  | 'Reunión'
  | 'Investigación'
  | 'Inspiración'
  | 'Devocional';
export type NoteTag =
  | 'Doctrina'
  | 'Profecía'
  | 'Consejo'
  | 'Historia'
  | 'Promesa'
  | 'Ministerio';

interface CoverflowLibraryProps {
  isOpen: boolean;
  onClose: () => void;
  savedNotes?: NoteItem[];
}

export const CoverflowLibrary: React.FC<CoverflowLibraryProps> = ({
  isOpen,
  onClose,
  savedNotes = INITIAL_NOTES,
}) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  // Filtrado de notas
  const filteredNotes = savedNotes.filter(
    (note) =>
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.theme.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.reference.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.tags.some((tag) =>
        tag.toLowerCase().includes(searchQuery.toLowerCase())
      )
  );

  useEffect(() => {
    // Scroll handling para el efecto carrusel (Snap a los elementos centrales)
    const handleScroll = () => {
      if (!scrollRef.current) return;

      const scrollLeft = scrollRef.current.scrollLeft;
      const itemWidth = 280; // Ancho aproximado de la tarjeta + margen
      const newIndex = Math.round(scrollLeft / itemWidth);

      if (
        newIndex !== activeIndex &&
        newIndex >= 0 &&
        newIndex < filteredNotes.length
      ) {
        setActiveIndex(newIndex);
      }
    };

    const scrollContainer = scrollRef.current;
    if (scrollContainer) {
      scrollContainer.addEventListener('scroll', handleScroll, {
        passive: true,
      });
    }

    return () => {
      if (scrollContainer) {
        scrollContainer.removeEventListener('scroll', handleScroll);
      }
    };
  }, [activeIndex, filteredNotes.length]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex flex-col bg-[#112625]/95 backdrop-blur-3xl">
      {/* Background Decor */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-[#EBB634]/10 blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-emerald-500/10 blur-[120px]" />
      </div>

      {/* Header Fijo */}
      <div className="relative z-10 pt-12 pb-6 px-6 flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-black text-[#F6F4EE] tracking-tight">
              Estudiario
            </h2>
            <p className="text-sm text-[#A7C7C6] font-medium mt-1">
              Tu biblioteca de conocimiento
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white active:scale-95 transition-all shadow-lg"
          >
            <motion.div whileTap={{ rotate: 90 }}>
              <Plus className="w-5 h-5 rotate-45" />
            </motion.div>
          </button>
        </div>

        {/* Buscador */}
        <div className="relative">
          <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
            <Search className="w-4 h-4 text-[#A7C7C6]" />
          </div>
          <input
            type="text"
            placeholder="Buscar por título, tema o etiqueta..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-black/20 border border-white/10 rounded-2xl py-3.5 pl-11 pr-4 text-sm text-[#F6F4EE] placeholder:text-[#A7C7C6]/60 focus:outline-none focus:border-[#EBB634]/50 focus:ring-1 focus:ring-[#EBB634]/50 transition-all shadow-inner"
          />
        </div>
      </div>

      {/* Área del Carrusel (Coverflow) */}
      <div className="relative flex-1 w-full overflow-hidden flex items-center justify-center pb-20">
        {filteredNotes.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center gap-4 text-center px-8"
          >
            <div className="w-20 h-20 rounded-full bg-white/5 border border-white/10 flex items-center justify-center">
              <AlertCircle className="w-8 h-8 text-[#A7C7C6]/50" />
            </div>
            <div>
              <p className="text-lg font-bold text-[#F6F4EE]">
                No hay notas encontradas
              </p>
              <p className="text-sm text-[#A7C7C6] mt-1">
                Intenta con otros términos de búsqueda o crea una nota nueva.
              </p>
            </div>
          </motion.div>
        ) : (
          <div
            ref={scrollRef}
            className="w-full flex gap-6 overflow-x-auto snap-x snap-mandatory px-[calc(50vw-140px)] pb-12 pt-8 no-scrollbar"
            style={{ scrollBehavior: 'smooth' }}
          >
            {filteredNotes.map((note, index) => {
              const isActive = index === activeIndex;

              return (
                <motion.div
                  key={note.id}
                  className="snap-center shrink-0 w-[280px]"
                  animate={{
                    scale: isActive ? 1 : 0.85,
                    opacity: isActive ? 1 : 0.4,
                    y: isActive ? 0 : 20,
                    rotateY: isActive ? 0 : index < activeIndex ? 15 : -15,
                    zIndex: isActive ? 10 : 0,
                  }}
                  transition={{ type: 'spring', damping: 20, stiffness: 200 }}
                  style={{ perspective: 1000 }}
                >
                  <div className="h-[400px] w-full rounded-[32px] bg-white border border-white/20 p-6 flex flex-col relative overflow-hidden shadow-[0_20px_40px_rgba(0,0,0,0.4)]">
                    {/* Tarjeta de decoración superior */}
                    <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-br from-[#122B2A] to-[#1a3d3c] opacity-5 pointer-events-none" />

                    {/* Categoría y Fecha */}
                    <div className="flex items-center justify-between mb-4 relative z-10">
                      <span className="text-[10px] font-black uppercase tracking-widest text-[#EBB634] bg-[#EBB634]/10 px-3 py-1.5 rounded-full">
                        {note.category}
                      </span>
                      <span className="text-[11px] font-semibold text-[#112625]/40 flex items-center gap-1.5">
                        <CalendarIcon className="w-3 h-3" />
                        {new Date(note.date).toLocaleDateString('es-ES', {
                          day: '2-digit',
                          month: 'short',
                        })}
                      </span>
                    </div>

                    {/* Título y Tema */}
                    <div className="mb-5 relative z-10">
                      <h3 className="text-xl font-extrabold text-[#112625] leading-tight mb-2 line-clamp-2">
                        {note.title}
                      </h3>
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-[#276160]">
                        <BookOpen className="w-3.5 h-3.5" />
                        <span className="truncate">{note.theme}</span>
                      </div>
                    </div>

                    {/* Cita Principal */}
                    <div className="relative flex-1 bg-[#FAF7F0] rounded-2xl p-4 mb-4 border border-black/5 shadow-inner">
                      <div className="absolute top-3 right-3 text-[#EBB634]/20">
                        <svg
                          width="24"
                          height="24"
                          viewBox="0 0 24 24"
                          fill="currentColor"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path d="M10 11L8 15H11V19H5V15L7 11H5V7H11V11H10ZM21 11L19 15H22V19H16V15L18 11H16V7H22V11H21Z" />
                        </svg>
                      </div>
                      <p className="text-sm text-[#112625]/80 font-medium italic line-clamp-4 leading-relaxed relative z-10">
                        "{note.content}"
                      </p>
                      <p className="text-[10px] font-bold text-[#276160] mt-3 uppercase tracking-wider relative z-10">
                        — {note.reference}
                      </p>
                    </div>

                    {/* Footer (Etiquetas y Tiempo) */}
                    <div className="flex flex-col gap-3 mt-auto pt-2 border-t border-black/5 relative z-10">
                      {note.tags.length > 0 && (
                        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
                          <Tag className="w-3 h-3 text-[#112625]/30 shrink-0" />
                          {note.tags.map((tag, idx) => (
                            <span
                              key={idx}
                              className="text-[9px] font-bold text-[#112625]/60 bg-[#112625]/5 px-2 py-1 rounded-md shrink-0"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      )}

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 text-[10px] font-bold text-[#112625]/40 uppercase tracking-widest">
                          <Clock className="w-3 h-3" />
                          {note.estimatedReadingTime} min
                        </div>
                        <button className="w-8 h-8 rounded-full bg-[#112625] text-white flex items-center justify-center shadow-md active:scale-95 transition-transform">
                          <motion.div whileTap={{ scale: 0.8 }}>
                            <Sparkles className="w-3.5 h-3.5" />
                          </motion.div>
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Botón Flotante para nueva nota (Aparece abajo centrado) */}
      <motion.div
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30, delay: 0.2 }}
        className="absolute bottom-8 left-0 right-0 flex justify-center z-20 pointer-events-none"
      >
        <button className="pointer-events-auto h-14 px-8 rounded-full bg-gradient-to-r from-[#EBB634] to-[#B78628] text-white shadow-[0_8px_30px_rgba(235,182,52,0.4)] flex items-center gap-2 active:scale-95 transition-transform hover:shadow-[0_12px_40px_rgba(235,182,52,0.6)]">
          <Plus className="w-5 h-5" strokeWidth={2.5} />
          <span className="font-bold tracking-wide">Nueva Nota</span>
        </button>
      </motion.div>
    </div>
  );
};
