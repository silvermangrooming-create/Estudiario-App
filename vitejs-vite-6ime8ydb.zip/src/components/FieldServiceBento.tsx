import React from 'react';
import { motion } from 'motion/react';

interface FieldServiceBentoProps {
  hoursLogged?: number; // default 30
  monthlyGoal?: number; // default 50
  revisitas?: string[]; // default ["Luis", "Alberto"]
  cursos?: string[]; // default ["Josué", "Carlos", "Andrés", "Mateo"]
  onOpenCard?: (cardType: 'hours' | 'revisitas' | 'cursos') => void;
}

export const FieldServiceBento: React.FC<FieldServiceBentoProps> = ({
  hoursLogged = 30,
  monthlyGoal = 50,
  revisitas = ['Luis', 'Alberto'],
  cursos = ['Josué', 'Carlos', 'Andrés', 'Mateo'],
  onOpenCard,
}) => {
  const remainingHours = monthlyGoal - hoursLogged;

  // Monthly pace calculation (based on 16th day of 31-day month)
  const todayDay = 16;
  const daysInMonth = 31;
  const expectedPaceHours = (todayDay / daysInMonth) * monthlyGoal;
  const paceDiff = hoursLogged - expectedPaceHours;

  let paceColor = '#10B981'; // Emerald Green (On Track ±1h)
  let paceStatus = 'En ritmo';

  if (paceDiff > 1) {
    paceColor = '#0EA5E9'; // Bright Electric Blue (> +1h)
    paceStatus = 'Adelantado';
  } else if (paceDiff >= -1) {
    paceColor = '#10B981'; // Emerald Green (±1h)
    paceStatus = 'Al día';
  } else if (paceDiff >= -3) {
    paceColor = '#F59E0B'; // Warm Amber (-1h to -3h)
    paceStatus = 'Ligero retraso';
  } else {
    paceColor = '#EF4444'; // Coral Red (< -3h)
    paceStatus = 'Requiere atención';
  }

  return (
    <section className="w-full flex flex-col">
      {/* Section Header */}
      <h2 className="text-xs font-bold tracking-wider uppercase text-[#112625]/80 dark:text-[#F6F4EE]/90 mb-3 px-1 select-none">
        SERVICIO DEL CAMPO
      </h2>

      {/* 3-Column Bento Grid */}
      <div className="grid grid-cols-3 gap-3">
        {/* Card 1: Hours & 4-State Reactive Pace Graph */}
        <div
          onClick={() => onOpenCard?.('hours')}
          title="Toca para gestionar horas y cronómetro"
          className="p-4 rounded-[26px] min-h-[160px] flex flex-col justify-between relative overflow-hidden bg-white/60 dark:bg-white/10 backdrop-blur-2xl border border-white/95 dark:border-white/20 shadow-[0_14px_30px_-8px_rgba(235,182,52,0.18)] cursor-pointer active:scale-95 transition-all select-none hover:shadow-[0_18px_35px_-6px_rgba(235,182,52,0.28)]"
        >
          <div>
            <div className="text-2xl font-extrabold text-[#112625] dark:text-[#EBB634] leading-none tracking-tight">
              {hoursLogged} hrs
            </div>
            <div className="h-[1px] w-full bg-[#E5E0D5]/70 dark:bg-white/15 my-2" />
            <div className="text-[11px] font-medium text-[#276160]/80 dark:text-[#A7C7C6]/90">
              -{remainingHours} horas
            </div>
          </div>

          {/* Bottom: Frameless SVG spline curve + glowing endpoint dot */}
          <div className="w-full h-11 relative flex items-end overflow-hidden">
            <svg viewBox="0 0 100 45" className="w-full h-full overflow-hidden">
              <defs>
                <linearGradient id="splineGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor={paceColor} stopOpacity="0.25" />
                  <stop offset="100%" stopColor={paceColor} stopOpacity="0.95" />
                </linearGradient>
              </defs>

              {/* Spline Path */}
              <path
                d="M 5,36 Q 30,32 50,22 T 80,14"
                fill="none"
                stroke="url(#splineGrad)"
                strokeWidth="2.5"
                strokeLinecap="round"
              />

              {/* Endpoint Glowing Dot (Animating radius safely without scale-origin glitches) */}
              <circle cx="80" cy="14" r="3.5" fill={paceColor} />
              <motion.circle
                cx="80"
                cy="14"
                r={3.5}
                animate={{
                  r: [3.5, 6, 3.5],
                  opacity: [0.65, 0.15, 0.65],
                }}
                transition={{
                  duration: 2.2,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }}
                fill={paceColor}
              />
            </svg>
          </div>
        </div>

        {/* Card 2: Revisitas */}
        <div
          onClick={() => onOpenCard?.('revisitas')}
          title="Toca para ver revisitas"
          className="p-4 rounded-[26px] min-h-[160px] flex flex-col justify-between relative overflow-hidden bg-white/60 dark:bg-white/10 backdrop-blur-2xl border border-white/95 dark:border-white/20 shadow-[0_14px_30px_-8px_rgba(235,182,52,0.18)] cursor-pointer active:scale-95 transition-all select-none hover:shadow-[0_18px_35px_-6px_rgba(235,182,52,0.28)]"
        >
          <div>
            <div className="text-2xl font-extrabold text-[#112625] dark:text-[#EBB634] leading-none tracking-tight">
              {revisitas.length}
            </div>
            <div className="text-[10px] font-bold tracking-wider uppercase text-[#276160]/80 dark:text-[#A7C7C6] mt-1">
              REVISITAS
            </div>
          </div>

          <div className="h-[1px] w-full bg-[#E5E0D5]/70 dark:bg-white/15" />

          {/* Below divider: Clean list showing Luis and Alberto with tiny glowing status dots */}
          <div className="flex flex-col gap-1.5 pb-1">
            {revisitas.slice(0, 2).map((person, idx) => (
              <div key={person} className="flex items-center gap-1.5">
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    idx === 0
                      ? 'bg-[#10B981] shadow-[0_0_6px_rgba(16,185,129,0.8)]'
                      : 'bg-[#EBB634] shadow-[0_0_6px_rgba(235,182,52,0.8)]'
                  }`}
                />
                <span className="text-xs font-semibold text-[#112625] dark:text-[#F6F4EE] truncate">
                  {person}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Card 3: Cursos */}
        <div
          onClick={() => onOpenCard?.('cursos')}
          title="Toca para ver cursos bíblicos"
          className="p-4 rounded-[26px] min-h-[160px] flex flex-col justify-between relative overflow-hidden bg-white/60 dark:bg-white/10 backdrop-blur-2xl border border-white/95 dark:border-white/20 shadow-[0_14px_30px_-8px_rgba(235,182,52,0.18)] cursor-pointer active:scale-95 transition-all select-none hover:shadow-[0_18px_35px_-6px_rgba(235,182,52,0.28)]"
        >
          <div>
            <div className="text-2xl font-extrabold text-[#112625] dark:text-[#EBB634] leading-none tracking-tight">
              {cursos.length}
            </div>
            <div className="text-[10px] font-bold tracking-wider uppercase text-[#276160]/80 dark:text-[#A7C7C6] mt-1">
              CURSOS
            </div>
          </div>

          <div className="h-[1px] w-full bg-[#E5E0D5]/70 dark:bg-white/15" />

          {/* Below divider: Clean vertical list of first names ONLY (Josué, Carlos, Andrés, Mateo) */}
          <div className="flex flex-col gap-1 pb-0.5">
            {cursos.slice(0, 4).map((name) => (
              <div
                key={name}
                className="text-xs font-semibold text-[#112625] dark:text-[#F6F4EE] truncate leading-tight"
              >
                {name}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
