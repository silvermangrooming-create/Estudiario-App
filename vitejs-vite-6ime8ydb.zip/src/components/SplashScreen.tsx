import React from 'react';
import { motion } from 'motion/react';
import { EstudiarioLogo } from './EstudiarioLogo';

interface SplashScreenProps {
  onFinish?: () => void;
  userName?: string;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ userName = 'Gabriel' }) => {
  return (
    <motion.div
      key="splash-screen"
      initial={{ opacity: 1 }}
      exit={{
        opacity: 0,
        transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] },
      }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#FAF7F0] overflow-hidden"
    >
      {/* Background Expanding Warm Sun Gold Light Rings */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <motion.div
          initial={{ scale: 0.3, opacity: 0 }}
          animate={{
            scale: [0.6, 1.35, 1.8],
            opacity: [0, 0.45, 0],
          }}
          transition={{
            duration: 2.2,
            repeat: Infinity,
            ease: 'easeOut',
          }}
          className="absolute w-80 h-80 rounded-full border border-[#EBB634]/40 bg-[#EBB634]/15 blur-sm"
        />
        <motion.div
          initial={{ scale: 0.2, opacity: 0 }}
          animate={{
            scale: [0.4, 1.1, 1.5],
            opacity: [0, 0.35, 0],
          }}
          transition={{
            duration: 2.2,
            delay: 0.4,
            repeat: Infinity,
            ease: 'easeOut',
          }}
          className="absolute w-96 h-96 rounded-full border border-[#F6D365]/35 bg-[#F6D365]/10 blur-md"
        />

        {/* Floating Bokeh Orbs */}
        <motion.div
          animate={{
            y: [-15, 15, -15],
            x: [-10, 10, -10],
            opacity: [0.3, 0.65, 0.3],
          }}
          transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -top-16 -left-12 w-36 h-36 rounded-full bg-[#EBB634]/25 blur-2xl"
        />
        <motion.div
          animate={{
            y: [15, -15, 15],
            x: [12, -12, 12],
            opacity: [0.2, 0.5, 0.2],
          }}
          transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute bottom-10 right-8 w-44 h-44 rounded-full bg-[#276160]/15 blur-2xl"
        />
      </div>

      {/* Center Brand Emblem with Spring Physics */}
      <div className="relative z-10 flex flex-col items-center">
        <div className="relative flex items-center justify-center">
          {/* Subtle Backlight Aura */}
          <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-[#EBB634]/30 to-[#F6D365]/20 blur-xl scale-125 -z-10 pointer-events-none" />

          <motion.div
            layoutId="brand-emblem"
            transition={{
              type: 'spring',
              stiffness: 200,
              damping: 25,
              mass: 0.8,
            }}
            className="shrink-0 flex items-center justify-center cursor-default"
          >
            <EstudiarioLogo
              className="w-28 h-28 drop-shadow-[0_12px_35px_rgba(235,182,52,0.5)]"
            />
          </motion.div>
        </div>

        {/* Sleek Welcome Text Fade-In */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.55, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="mt-7 text-center"
        >
          <h2 className="text-2xl font-bold tracking-tight text-[#122A29]">
            Bienvenido, {userName}
          </h2>
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ delay: 0.8, duration: 0.8, ease: 'easeOut' }}
            className="h-[2px] w-14 mx-auto mt-2.5 bg-gradient-to-r from-transparent via-[#EBB634] to-transparent"
          />
        </motion.div>
      </div>
    </motion.div>
  );
};
