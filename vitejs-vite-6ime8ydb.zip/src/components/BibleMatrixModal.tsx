import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  CheckCircle2,
  Bookmark,
  ExternalLink,
  Pin,
  Plus,
  Minus,
  Sparkles,
} from 'lucide-react';
import {
  CANONICAL_BOOKS,
  type BibleBookInfo,
  buildJwLibraryUrl,
} from '../data/canonicalBible';

interface BibleMatrixModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentBook: string;
  currentChapter: number;
  currentVerse: number;
  onUpdateBookmark: (bookName: string, chapter: number, verse: number) => void;
}

export const BibleMatrixModal: React.FC<BibleMatrixModalProps> = ({
  isOpen,
  onClose,
  currentBook,
  currentChapter,
  currentVerse,
  onUpdateBookmark,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('Todos');

  // Currently opened book for the Chapter Selector Action Sheet
  const [selectedBookForSheet, setSelectedBookForSheet] =
    useState<BibleBookInfo | null>(null);
  const [sheetChapter, setSheetChapter] = useState(currentChapter);
  const [sheetVerse, setSheetVerse] = useState(currentVerse);
  const [savedBookmarkNotice, setSavedBookmarkNotice] = useState(false);

  // 41 completed books pre-marked for demonstration
  const [completedBooks, setCompletedBooks] = useState<Set<number>>(() => {
    const initial = new Set<number>();
    for (let i = 1; i <= 29; i++) initial.add(i); // Genesis to Joel
    for (let i = 40; i <= 51; i++) initial.add(i); // Matthew to Colossians
    return initial;
  });

  const categories = [
    'Todos',
    'Históricos',
    'Proféticos',
    'Poéticos',
    'Evangelios',
    'Cartas',
  ];

  const filteredBooks =
    selectedCategory === 'Todos'
      ? CANONICAL_BOOKS
      : CANONICAL_BOOKS.filter((b) => b.category === selectedCategory);

  const handleTileClick = (book: BibleBookInfo) => {
    setSelectedBookForSheet(book);
    setSheetChapter(book.name === currentBook ? currentChapter : 1);
    setSheetVerse(book.name === currentBook ? currentVerse : 1);
  };

  const handleApplyBookmark = () => {
    if (selectedBookForSheet) {
      onUpdateBookmark(selectedBookForSheet.name, sheetChapter, sheetVerse);
      setSavedBookmarkNotice(true);
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate(50);
      }
      setTimeout(() => {
        setSavedBookmarkNotice(false);
        setSelectedBookForSheet(null);
      }, 900);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Translucent Backdrop letting background waves shine */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/20 backdrop-blur-xs"
      />

      {/* Full-Screen Glass Modal Sliding Up From Bottom */}
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 28, stiffness: 300 }}
        className="fixed inset-0 z-50 bg-[#FAF7F0]/90 dark:bg-[#0B1716]/95 backdrop-blur-3xl overflow-y-auto px-5 py-8 flex flex-col justify-start"
      >
        <div className="w-full max-w-md mx-auto flex flex-col gap-6">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-black/[0.06] dark:border-white/10 pb-3">
            <div>
              <h2 className="text-sm font-extrabold text-[#112625] dark:text-[#F6F4EE] uppercase tracking-wider">
                MATRIZ CANÓNICA DE LA BIBLIA
              </h2>
              <span className="text-[11px] font-medium text-[#276160] dark:text-[#A7C7C6]">
                {completedBooks.size} de 66 libros completados (
                {Math.round((completedBooks.size / 66) * 100)}%)
              </span>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="Cerrar modal"
              className="w-9 h-9 rounded-full bg-white/40 dark:bg-white/10 backdrop-blur-xl border border-white/90 dark:border-white/20 shadow-[0_4px_15px_rgba(235,182,52,0.15)] flex items-center justify-center text-[#112625] dark:text-[#F6F4EE] active:scale-95 transition-transform cursor-pointer"
            >
              <X className="w-4 h-4" strokeWidth={1.75} />
            </button>
          </div>

          {/* Category Filter Tabs: Scrollable horizontal row of translucent glass pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {categories.map((cat) => {
              const isActive = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`text-xs font-bold px-3.5 py-2 rounded-full whitespace-nowrap transition-all cursor-pointer ${
                    isActive
                      ? 'bg-white/60 backdrop-blur-xl border border-white/90 shadow-[0_4px_15px_rgba(235,182,52,0.25)] text-[#122B2A]'
                      : 'bg-white/30 backdrop-blur-lg border border-white/60 text-[#122B2A]/60 hover:bg-white/50'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>

          {/* The Book Grid: Clean 3-column grid (grid-cols-3 gap-3) */}
          <div className="grid grid-cols-3 gap-3 pb-24">
            {filteredBooks.map((book) => {
              const isCompleted = completedBooks.has(book.id);
              const isActiveReading = book.name === currentBook;

              return (
                <motion.div
                  key={book.id}
                  layout
                  onClick={() => handleTileClick(book)}
                  className={`p-3 rounded-2xl flex flex-col justify-between min-h-[82px] relative transition-all cursor-pointer active:scale-95 ${
                    isActiveReading
                      ? 'bg-white/60 dark:bg-[#122827]/90 backdrop-blur-2xl border-2 border-[#EBB634] shadow-[0_0_22px_rgba(235,182,52,0.45)] ring-2 ring-[#EBB634]/40 animate-pulse'
                      : isCompleted
                      ? 'bg-white/50 dark:bg-white/10 backdrop-blur-xl border border-emerald-300/70 dark:border-emerald-500/40 shadow-[0_2px_14px_rgba(16,185,129,0.2)]'
                      : 'bg-white/40 dark:bg-white/5 backdrop-blur-lg border border-white/80 dark:border-white/10 hover:bg-white/60 shadow-xs'
                  }`}
                >
                  {/* Subtle inner warm backlight for active book */}
                  {isActiveReading && (
                    <div className="absolute inset-0 bg-[#EBB634]/20 rounded-2xl blur-xs -z-10 pointer-events-none" />
                  )}

                  {/* Top corner indicator: CheckCircle2 for completed */}
                  <div className="flex items-center justify-between w-full">
                    <span className="text-[10px] font-bold text-[#112625]/45 dark:text-[#F6F4EE]/40">
                      {book.code}
                    </span>
                    {isCompleted && (
                      <CheckCircle2
                        className="w-3.5 h-3.5 text-[#10B981] drop-shadow-xs"
                        strokeWidth={2}
                      />
                    )}
                  </div>

                  {/* Book Title & chapters */}
                  <div className="mt-1">
                    <span className="text-xs font-bold text-[#112625] dark:text-[#F6F4EE] truncate block leading-snug">
                      {book.name}
                    </span>
                    <span className="text-[9px] font-medium text-[#276160]/75 dark:text-[#A7C7C6] block">
                      {book.chapters} caps
                    </span>
                  </div>

                  {/* Active reading pill badge */}
                  {isActiveReading && (
                    <div className="mt-1 self-start">
                      <span className="text-[8px] font-black uppercase px-1.5 py-0.5 rounded-full bg-gradient-to-r from-[#EBB634] to-[#B78628] text-white">
                        Actual
                      </span>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>
      </motion.div>

      {/* ========================================================
          CHAPTER SELECTOR ACTION SHEET
          Slides up when a book tile is tapped
          ======================================================== */}
      <AnimatePresence>
        {selectedBookForSheet && (
          <div className="fixed inset-0 z-[60] flex items-end justify-center pointer-events-auto">
            {/* Sheet backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedBookForSheet(null)}
              className="fixed inset-0 bg-black/25 backdrop-blur-xs"
            />

            {/* Sliding sheet */}
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 26, stiffness: 280 }}
              className="relative w-full max-w-md bg-white/90 dark:bg-[#0E201F]/95 backdrop-blur-3xl rounded-t-[40px] p-6 shadow-[0_-20px_40px_rgba(235,182,52,0.18)] z-[60] flex flex-col gap-5 border-t border-white dark:border-white/20"
            >
              {/* Sheet handle & title */}
              <div className="flex flex-col items-center gap-1.5 pb-1 border-b border-black/[0.05] dark:border-white/10">
                <div className="w-12 h-1 rounded-full bg-black/20 dark:bg-white/20" />
                <div className="flex items-center justify-between w-full pt-1">
                  <div>
                    <h3 className="text-base font-extrabold text-[#112625] dark:text-[#F6F4EE] leading-none">
                      {selectedBookForSheet.name}
                    </h3>
                    <span className="text-[10px] text-[#276160] dark:text-[#A7C7C6] font-medium mt-1 block">
                      {selectedBookForSheet.chapters} capítulos en total
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <a
                      href={buildJwLibraryUrl(
                        selectedBookForSheet.id,
                        sheetChapter,
                        sheetVerse
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[11px] font-bold px-2.5 py-1 rounded-xl bg-white/60 dark:bg-white/10 border border-white/80 dark:border-white/20 shadow-xs text-[#276160] dark:text-[#A7C7C6] flex items-center gap-1 hover:bg-white dark:hover:bg-white/20"
                    >
                      <span>JW Library</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>

                    <button
                      type="button"
                      onClick={() => setSelectedBookForSheet(null)}
                      className="p-1.5 rounded-full text-black/40 dark:text-white/40 hover:text-black dark:hover:text-white cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Clean + / - Steppers for Capítulo and Versículo */}
              <div className="grid grid-cols-2 gap-3">
                {/* Capítulo Stepper */}
                <div className="p-3.5 rounded-2xl bg-white/60 dark:bg-white/10 border border-white/80 dark:border-white/20 shadow-xs flex flex-col gap-1.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#276160] dark:text-[#A7C7C6]">
                    Capítulo
                  </span>

                  <div className="flex items-center justify-between pt-1">
                    <button
                      type="button"
                      onClick={() => setSheetChapter((c) => Math.max(1, c - 1))}
                      className="w-8 h-8 rounded-full bg-white/80 dark:bg-white/20 border border-white dark:border-white/30 shadow-xs flex items-center justify-center text-[#112625] dark:text-[#F6F4EE] active:scale-95 cursor-pointer"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>

                    <span className="text-lg font-extrabold text-[#112625] dark:text-[#F6F4EE]">
                      {sheetChapter}
                    </span>

                    <button
                      type="button"
                      onClick={() =>
                        setSheetChapter((c) =>
                          Math.min(selectedBookForSheet.chapters, c + 1)
                        )
                      }
                      className="w-8 h-8 rounded-full bg-white/80 dark:bg-white/20 border border-white dark:border-white/30 shadow-xs flex items-center justify-center text-[#112625] dark:text-[#F6F4EE] active:scale-95 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Versículo Stepper */}
                <div className="p-3.5 rounded-2xl bg-white/60 dark:bg-white/10 border border-white/80 dark:border-white/20 shadow-xs flex flex-col gap-1.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#276160] dark:text-[#A7C7C6]">
                    Versículo
                  </span>

                  <div className="flex items-center justify-between pt-1">
                    <button
                      type="button"
                      onClick={() => setSheetVerse((v) => Math.max(1, v - 1))}
                      className="w-8 h-8 rounded-full bg-white/80 dark:bg-white/20 border border-white dark:border-white/30 shadow-xs flex items-center justify-center text-[#112625] dark:text-[#F6F4EE] active:scale-95 cursor-pointer"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>

                    <span className="text-lg font-extrabold text-[#112625] dark:text-[#F6F4EE]">
                      {sheetVerse}
                    </span>

                    <button
                      type="button"
                      onClick={() => setSheetVerse((v) => v + 1)}
                      className="w-8 h-8 rounded-full bg-white/80 dark:bg-white/20 border border-white dark:border-white/30 shadow-xs flex items-center justify-center text-[#112625] dark:text-[#F6F4EE] active:scale-95 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
              {/* Primary Backlit Glass Button: <Pin /> Fijar Marcador */}
              <button
                type="button"
                onClick={handleApplyBookmark}
                className="w-full py-3.5 rounded-2xl bg-white/40 dark:bg-white/15 backdrop-blur-xl border border-white/90 dark:border-white/20 shadow-[0_4px_18px_rgba(235,182,52,0.25)] text-[#122B2A] dark:text-[#F6F4EE] text-xs font-black flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer hover:bg-white/60 dark:hover:bg-white/25"
              >
                <Pin className="w-4 h-4 text-[#B78628]" strokeWidth={2} />
                <span>
                  Fijar Marcador en {selectedBookForSheet.name} {sheetChapter}:
                  {sheetVerse}
                </span>
              </button>

              {/* Success celebration indicator */}
              <AnimatePresence>
                {savedBookmarkNotice && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 5 }}
                    className="p-2.5 rounded-xl bg-white/80 backdrop-blur-xl border border-emerald-300 text-emerald-900 text-xs font-bold flex items-center justify-center gap-1.5"
                  >
                    <Sparkles className="w-4 h-4 text-emerald-600" />
                    <span>¡Marcador fijado y tablero actualizado!</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
